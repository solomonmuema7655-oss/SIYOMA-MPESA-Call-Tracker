package com.siyoma.mpesa.calltracker;

import org.junit.Test;
import static org.junit.Assert.*;

public class MpesaParserTest {
    private static final String SAMPLE="UK9LC1RH1Y Confirmed. Ksh50.00 paid to Caroline Ndinda Mwanthi. on 9/11/26 at 6:03 PM.New M-PESA balance is Ksh16.44. Transaction cost, Ksh0.00.";
    @Test public void identifiesConfirmationAndReceipt() {
        assertTrue(MpesaParser.isMpesa(SAMPLE));
        assertEquals("UK9LC1RH1Y",MpesaParser.reference(SAMPLE));
    }
    @Test public void extractsAmountAndBalance() {
        assertEquals("50.00",MpesaParser.amount(SAMPLE));
        assertEquals("16.44",MpesaParser.balance(SAMPLE));
    }
    @Test public void categorizesSentPayments() {
        assertEquals("SENT",MpesaParser.category(SAMPLE));
    }
    @Test public void categorizesReceivedFromAnySourceAsReceived() {
        assertEquals("RECEIVED",MpesaParser.category("M-PESA Ksh100.00 received from ABC BANK. New M-PESA balance is Ksh500.00."));
        assertEquals("RECEIVED",MpesaParser.category("M-PESA Ksh250.00 received from Jane Company LTD. New M-PESA balance is Ksh750.00."));
    }
    @Test public void categorizesAirtimeAndBundlesAsAirtime() {
        assertEquals("AIRTIME",MpesaParser.category("M-PESA Ksh50.00 airtime bought. New M-PESA balance is Ksh100.00."));
        assertEquals("AIRTIME",MpesaParser.category("You bought a Safaricom bundle for Ksh100.00. New M-PESA balance is Ksh200.00."));
    }
    @Test public void publicLabelsNeverExposeFeesOrCombinedSentAirtime() {
        assertEquals("SENT",MpesaParser.category("M-PESA transaction cost, Ksh2.60. New M-PESA balance is Ksh10.00."));
    }
    @Test public void feeAndZiidiMessagesArePubliclyAccountedAsSent() {
        String fee="M-PESA transaction cost, Ksh2.60. New M-PESA balance is Ksh10.00.";
        assertEquals("SENT",MpesaParser.category(fee));
        assertEquals("2.60",MpesaParser.amount(fee));
    }
    @Test public void rejectsUnrelatedText() {
        assertFalse(MpesaParser.isMpesa("Your account has been updated. Ksh50 available."));
    }
    @Test public void receiptFingerprintDoesNotDependOnSmsTimestamp() {
        String first="UK9LC1RH1Y Confirmed. Ksh3.00 received from A. New M-PESA balance is Ksh19.44.";
        String second="UK9LC1RH1Y Confirmed. Ksh3.00 received from A. New M-PESA balance is Ksh19.44.";
        assertEquals(MpesaParser.fingerprint("MPESA",first,1000L),MpesaParser.fingerprint("MPESA",second,9000L));
    }
    @Test public void feeAmountIsActualStatedFeeNotBalance() {
        String fee="M-PESA transaction cost, Ksh2.60. New M-PESA balance is Ksh10.00.";
        assertEquals("2.60", MpesaParser.amount(fee));
    }
    @Test public void categorizesReversals() {
        assertEquals("REVERSAL",MpesaParser.category("Transaction reversed. M-PESA"));
    }
}
