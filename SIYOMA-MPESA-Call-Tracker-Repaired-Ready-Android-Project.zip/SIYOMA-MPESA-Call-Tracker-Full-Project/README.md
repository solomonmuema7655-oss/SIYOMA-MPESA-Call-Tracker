# SIYOMA M-PESA & Call Tracker

A branded, local-first Android application for capturing M-PESA confirmation SMS records and reviewing the device call log. The project is built with Java 17, Android Gradle Plugin 8.6.1, Gradle 8.7 and Android SDK 35 (minimum Android 8.0 / API 26).

## Included functionality

- Historical M-PESA Inbox scanning and live M-PESA SMS receiver.
- Receipt reference, transaction amount, balance, category, sender, original SMS and timestamp extraction.
- Complete call-log import with number/contact, call type, duration and timestamp.
- Local SQLite persistence and duplicate prevention.
- Launch/resume, phone-state idle, reboot and app-replacement synchronization.
- Search, All / 7 / 30 / 90 day filters and tap-to-view record details.
- M-PESA CSV, call-history CSV and PDF activity report.
- User-controlled database backup and integrity-checked restore.
- SIYOMA logo, launcher artwork and branded dashboard.

## Build in GitHub Actions

The included workflow runs on `ubuntu-22.04`, sets up Java 17 and Gradle 8.7, installs Android SDK 35, runs parser tests, builds DEBUG and RELEASE APKs, and uploads both APK artifacts.

If the repository contains the Android project at its root, the workflow builds it there. If the project is stored as a ZIP, name the ZIP exactly:

`SIYOMA-MPESA-Call-Tracker-Complete-Android-Project.zip`

and commit it to the repository. The workflow extracts and builds that archive.

## Permissions and privacy

The app requests SMS, call-log and phone-state permissions for its core functions. Records are stored locally. No call audio is recorded, no calls are placed, and no cloud upload is implemented. Permission denial disables the related feature rather than bypassing Android controls.

SMS and call-log permissions are restricted/sensitive under Google Play policy. Confirm policy eligibility before attempting Play Store publication. The included release APK is unsigned; use a separately secured signing process for a production-signed release.

## Verification

See `BUILD_STATUS.md` for implemented features, what has and has not been verified, and the target-device acceptance checklist. A successful source build is not a substitute for testing SMS delivery, call-log access, reboot behavior, backup/restore and export sharing on a real phone.

Developer identity: SiyomaCodingPrograms / SIYOMA TECH DESIGNS.
