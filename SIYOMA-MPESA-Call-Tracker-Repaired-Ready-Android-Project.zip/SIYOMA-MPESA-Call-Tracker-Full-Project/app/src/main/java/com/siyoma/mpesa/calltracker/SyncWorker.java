package com.siyoma.mpesa.calltracker;

import android.content.Context;
import android.content.pm.PackageManager;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class SyncWorker extends Worker {
    public SyncWorker(@NonNull Context c,@NonNull WorkerParameters p) { super(c,p); }
    @NonNull @Override public Result doWork() {
        Context c=getApplicationContext();
        try {
            if(c.checkSelfPermission(android.Manifest.permission.READ_CALL_LOG)==PackageManager.PERMISSION_GRANTED)
                SyncEngine.syncCalls(c);
            if(c.checkSelfPermission(android.Manifest.permission.READ_SMS)==PackageManager.PERMISSION_GRANTED)
                SyncEngine.syncMpesa(c);
            return Result.success();
        } catch(RuntimeException e) {
            return Result.retry();
        }
    }
}
