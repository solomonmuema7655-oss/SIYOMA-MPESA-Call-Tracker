package com.siyoma.mpesa.calltracker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

public class PhoneStateReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent) {
        if(!TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(intent.getAction())) return;
        if(TelephonyManager.EXTRA_STATE_IDLE.equals(intent.getStringExtra(TelephonyManager.EXTRA_STATE))) {
            WorkManager.getInstance(context).enqueueUniqueWork("siyoma_history_sync",ExistingWorkPolicy.KEEP,
                new OneTimeWorkRequest.Builder(SyncWorker.class).build());
        }
    }
}
