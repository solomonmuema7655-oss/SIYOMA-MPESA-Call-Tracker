package com.siyoma.mpesa.calltracker;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
public class PhoneStateReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i) {
  if(!TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(i.getAction())) return;
  if(TelephonyManager.EXTRA_STATE_IDLE.equals(i.getStringExtra(TelephonyManager.EXTRA_STATE)))
   WorkManager.getInstance(c).enqueue(new OneTimeWorkRequest.Builder(SyncWorker.class).build());
 }
}
