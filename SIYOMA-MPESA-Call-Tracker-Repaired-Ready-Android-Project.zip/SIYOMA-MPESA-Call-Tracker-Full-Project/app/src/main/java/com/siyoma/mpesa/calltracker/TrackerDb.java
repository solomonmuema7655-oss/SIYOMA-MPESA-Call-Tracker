package com.siyoma.mpesa.calltracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class TrackerDb extends SQLiteOpenHelper {
    private static final String DB="siyoma_tracker.db";
    public TrackerDb(Context c) { super(c, DB, null, 2); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE mpesa (_id INTEGER PRIMARY KEY AUTOINCREMENT, fingerprint TEXT UNIQUE, reference TEXT, amount TEXT, balance TEXT, category TEXT, sender TEXT, body TEXT, time INTEGER)");
        db.execSQL("CREATE TABLE calls (_id INTEGER PRIMARY KEY AUTOINCREMENT, source_id INTEGER UNIQUE, number TEXT, contact TEXT, type INTEGER, duration INTEGER, time INTEGER)");
        db.execSQL("CREATE INDEX idx_mpesa_time ON mpesa(time)");
        db.execSQL("CREATE INDEX idx_calls_time ON calls(time)");
        db.execSQL("CREATE INDEX idx_mpesa_category ON mpesa(category)");
        db.execSQL("CREATE INDEX idx_calls_type ON calls(type)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV) {
        if (oldV < 2) {
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_mpesa_category ON mpesa(category)");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_calls_type ON calls(type)");
        }
    }
    public synchronized boolean addMpesa(String fingerprint,String ref,String amount,String balance,String category,String sender,String body,long time) {
        ContentValues v=new ContentValues(); v.put("fingerprint",fingerprint); v.put("reference",ref);
        v.put("amount",amount); v.put("balance",balance); v.put("category",category);
        v.put("sender",sender); v.put("body",body); v.put("time",time);
        return getWritableDatabase().insertWithOnConflict("mpesa",null,v,SQLiteDatabase.CONFLICT_IGNORE)!=-1;
    }
    public synchronized boolean addCall(long sourceId,String number,String contact,int type,long duration,long time) {
        ContentValues v=new ContentValues(); v.put("source_id",sourceId); v.put("number",number);
        v.put("contact",contact); v.put("type",type); v.put("duration",duration); v.put("time",time);
        return getWritableDatabase().insertWithOnConflict("calls",null,v,SQLiteDatabase.CONFLICT_IGNORE)!=-1;
    }
    public int count(String table) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null)) { return c.moveToFirst()?c.getInt(0):0; }
    }
    public double sumMpesa() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT SUM(CAST(amount AS REAL)) FROM mpesa",null)) { return c.moveToFirst()?c.getDouble(0):0; }
    }
    public List<Record> records(boolean calls,String query) { return records(calls,query,0L,Long.MAX_VALUE); }
    public List<Record> records(boolean calls,String query,long startInclusive,long endExclusive) {
        List<Record> out=new ArrayList<>();
        String sql;
        String[] args;
        String q="%"+(query==null?"":query.trim())+"%";
        if(calls) {
            sql="SELECT _id,number,contact,type,duration,time FROM calls WHERE (number LIKE ? OR contact LIKE ?) AND time>=? AND time<? ORDER BY time DESC";
            args=new String[]{q,q,String.valueOf(startInclusive),String.valueOf(endExclusive)};
        } else {
            sql="SELECT _id,reference,amount,balance,category,sender,body,time FROM mpesa WHERE (body LIKE ? OR reference LIKE ? OR category LIKE ? OR sender LIKE ?) AND time>=? AND time<? ORDER BY time DESC";
            args=new String[]{q,q,q,q,String.valueOf(startInclusive),String.valueOf(endExclusive)};
        }
        try(Cursor c=getReadableDatabase().rawQuery(sql,args)) {
            while(c.moveToNext()) {
                if(calls) out.add(new Record(c.getLong(0),c.getLong(5),
                    c.getString(2)==null||c.getString(2).isEmpty()?c.getString(1):c.getString(2),
                    c.getString(1),"", "",callType(c.getInt(3)),"",
                    c.getInt(3),c.getLong(4),true));
                else out.add(new Record(c.getLong(0),c.getLong(7),
                    "KSh "+(c.getString(2)==null?"—":c.getString(2)),
                    c.getString(5)==null?"":c.getString(5),
                    c.getString(6),c.getString(1),c.getString(4),c.getString(3),0,0,false));
            }
        }
        return out;
    }
    public double sumMpesa(long startInclusive,long endExclusive) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT SUM(CAST(amount AS REAL)) FROM mpesa WHERE time>=? AND time<?",new String[]{String.valueOf(startInclusive),String.valueOf(endExclusive)})) {
            return c.moveToFirst()?c.getDouble(0):0;
        }
    }
    public int count(String table,long startInclusive,long endExclusive) {
        if (!"mpesa".equals(table) && !"calls".equals(table)) throw new IllegalArgumentException("Unsupported table");
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table+" WHERE time>=? AND time<?",new String[]{String.valueOf(startInclusive),String.valueOf(endExclusive)})) {
            return c.moveToFirst()?c.getInt(0):0;
        }
    }
    public List<Record> allMpesa() { return records(false,""); }
    public List<Record> allCalls() { return records(true,""); }
    public static String callType(int t) {
        switch(t) {
            case 1:return "INCOMING";
            case 2:return "OUTGOING";
            case 3:return "MISSED";
            case 4:return "VOICEMAIL";
            case 5:return "REJECTED";
            case 6:return "BLOCKED";
            case 7:return "ANSWERED EXTERNALLY";
            default:return "OTHER / UNKNOWN";
        }
    }
}
