# Source package change log

## Complete implementation pass

- Replaced the simplistic transaction parser with a stricter M-PESA confirmation parser and receipt-first reference extraction.
- Added parser unit tests for the supplied Kenyan M-PESA message format, amount, balance, category and false-positive rejection.
- Combined multipart live SMS payloads before parsing and stored them asynchronously from the SMS broadcast receiver.
- Kept historical inbox scans and full call-log scans idempotent through database uniqueness constraints.
- Added safe database version migration indexes.
- Added All / 7 / 30 / 90 day filters and broader search across M-PESA sender/body/reference/category.
- Added tap-to-open details for M-PESA SMS and call records.
- Added voicemail and externally answered call labels where Android exposes those types.
- Hardened CSV output with UTF-8 BOM, CRLF rows, quoting and spreadsheet formula-injection mitigation.
- Expanded PDF reporting to include recent M-PESA and call activity over multiple pages.
- Improved backup checkpointing, schema validation, integrity checking, staged restore and rollback protection.
- Prevented overlapping history sync operations and coalesced duplicate background sync requests.
- Improved background worker retry handling and surfaced permission states on the dashboard.
- Removed an unused contacts permission.
- Replaced the bundled CI workflow with a Java 17 / Gradle 8.7 / Android SDK 35 workflow that runs tests and uploads both APK variants.

The Android build and physical-device acceptance tests remain external verification gates. See `BUILD_STATUS.md`.
