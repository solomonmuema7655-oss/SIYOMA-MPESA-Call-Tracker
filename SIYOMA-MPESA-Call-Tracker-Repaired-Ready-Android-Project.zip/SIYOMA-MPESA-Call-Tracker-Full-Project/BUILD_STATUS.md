# SIYOMA M-PESA & Call Tracker — implementation and verification status

## Implemented in this source package

- Local-first SQLite storage for M-PESA confirmations and device call-log entries.
- Historical M-PESA inbox scan and complete call-log scan when the relevant Android permissions are granted.
- Live `SMS_RECEIVED` processing for matching M-PESA confirmation messages.
- M-PESA parser for receipt reference, first transaction amount, new M-PESA balance, sender, category, original SMS and message timestamp.
- SHA-256 fingerprint deduplication for M-PESA SMS and Android call-log row-ID deduplication for calls.
- Automatic synchronization on app launch/resume, after phone-state idle transitions, after reboot and after app replacement.
- Search across M-PESA body/reference/category/sender and call number/contact.
- All-time, 7-day, 30-day and 90-day record filters.
- Tap-to-open record details for both transaction SMS and calls.
- Call types including incoming, outgoing, missed, voicemail, rejected and blocked where the Android call-log provider exposes them.
- M-PESA CSV, call-history CSV and multi-page PDF activity summary exports.
- Spreadsheet-formula-safe CSV text quoting.
- Explicit local database backup and validated restore, with a pre-restore safety copy during replacement.
- Approved SIYOMA logo, launcher icons, branded dashboard and navigation.
- Gradle 8.7 / Java 17 / Android SDK 35 GitHub Actions workflow, parser unit tests, and DEBUG + RELEASE APK artifact upload.

## Verification status — do not misrepresent

- Source-level changes and archive structure have been checked.
- Parser unit tests are included in the project and are run by GitHub Actions.
- This execution environment does not have the Android SDK or Gradle installed, so an Android APK build has **not** been performed here.
- No physical Android device is attached here; live SMS delivery, permissions, call-log imports, reboot behavior, backup/restore and export sharing still require device validation.
- The release APK produced by this workflow is unsigned. A separately managed signing key is required for a distributable signed release / Play Store AAB.
- Android SMS and call-log permissions are sensitive and Google Play restricts their use. Play Store publication eligibility must be checked against current policy; sideloading a test APK does not guarantee Play approval.

## Important behavior and limitations

- The app does not record call audio, place calls, replace the default dialer, or upload personal records to a cloud service.
- Historical M-PESA import scans the SMS Inbox provider. SMS access depends on Android permission grant and device/vendor behavior.
- Live SMS capture depends on Android delivering the protected SMS_RECEIVED broadcast and the app retaining the required permission.
- Call history includes only records exposed by the Android Call Log provider. Some OEMs or Android versions may omit or classify call types differently.
- “Sum of captured transaction amounts” is a sum of parsed SMS amounts, not an M-PESA wallet balance or official reconciliation. Reversals and other transaction categories may be included.
- Backup/restore is a user-initiated local file operation. Keep an independent copy of important backups.

## Required acceptance test on the target phone

1. Install DEBUG APK and grant only the permissions the user wants to enable.
2. Sync historical M-PESA messages and compare a sample against the phone inbox.
3. Sync call history and compare counts / representative incoming, outgoing and missed calls against the device call log.
4. Send/receive a real M-PESA transaction SMS and verify live capture, receipt, amount, balance, category and timestamp.
5. Trigger repeated sync and verify that no duplicate rows are created.
6. Search records and test All / 7 days / 30 days / 90 days filters.
7. Open record details and verify the original SMS and call details.
8. Export both CSV files and the PDF; open them from a sharing target.
9. Create a database backup, add a test record, restore the backup, and verify the database returns to the backed-up state.
10. Reboot the phone and verify synchronization resumes after boot / unlock.
11. Repeat on the intended Android version and at least one other supported device before calling the app production-validated.
