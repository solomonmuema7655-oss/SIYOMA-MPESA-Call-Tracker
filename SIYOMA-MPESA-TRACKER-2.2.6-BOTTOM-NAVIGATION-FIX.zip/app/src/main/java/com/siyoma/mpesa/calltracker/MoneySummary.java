package com.siyoma.mpesa.calltracker;

import java.math.BigDecimal;

/** Exact decimal accounting for one rolling Insight window. */
public final class MoneySummary {
    private BigDecimal received = BigDecimal.ZERO;
    private BigDecimal sent = BigDecimal.ZERO;
    private BigDecimal airtime = BigDecimal.ZERO;
    private BigDecimal captured = BigDecimal.ZERO;

    public void add(String category, String rawAmount) {
        if (category == null || rawAmount == null || rawAmount.trim().isEmpty()) return;
        final BigDecimal amount;
        try { amount = new BigDecimal(rawAmount.replace(",", "").trim()); }
        catch (NumberFormatException ignored) { return; }
        if ("RECEIVED".equals(category) || "DEPOSIT".equals(category)) {
            captured = captured.add(amount);
            received = received.add(amount);
        } else if ("AIRTIME".equals(category)) {
            captured = captured.add(amount);
            sent = sent.add(amount);
            airtime = airtime.add(amount);
        } else if ("SENT".equals(category)) {
            captured = captured.add(amount);
            sent = sent.add(amount);
        }
        // REVERSAL, OTHER, FULIZA and any unknown/internal categories do not enter totals.
    }

    public BigDecimal received() { return received; }
    public BigDecimal sent() { return sent; }
    public BigDecimal airtime() { return airtime; }
    public BigDecimal profitLoss() { return received.subtract(sent); }
    public BigDecimal captured() { return captured; }
    public double[] asDoubles() { return new double[]{received.doubleValue(), sent.doubleValue(), airtime.doubleValue(), profitLoss().doubleValue()}; }
}
