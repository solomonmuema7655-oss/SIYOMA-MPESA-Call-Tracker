package com.siyoma.mpesa.calltracker;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parser for common Safaricom M-PESA confirmation SMS formats. */
public final class MpesaParser {
    private MpesaParser() {}
    private static final Pattern REF = Pattern.compile("(?i)^\\s*([A-Z0-9]{8,12})\\s+(?=(?:confirmed|reversed|received|cancelled|canceled))");
    private static final Pattern AMOUNT = Pattern.compile("(?i)Ksh\\.?\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)");
    private static final Pattern BALANCE = Pattern.compile("(?i)(?:new\\s+)?M-PESA\\s+balance\\s+is\\s+Ksh\\.?\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)");
    public static boolean isMpesa(String body) {
        if (body == null || body.trim().isEmpty()) return false;
        String s=body.toLowerCase(Locale.ROOT);
        boolean hasAmount=AMOUNT.matcher(body).find();
        boolean transactionLanguage=s.contains("confirmed")||s.contains("reversed")||s.contains("received")||s.contains("sent to")||s.contains("paid to")||s.contains("withdraw")||s.contains("deposit")||s.contains("buy goods")||s.contains("paybill")||s.contains("airtime")||s.contains("charged")||s.contains("deducted")||s.contains("ziidi");
        return hasAmount && transactionLanguage && (s.contains("m-pesa")||s.contains("mpesa"));
    }
    public static String reference(String body) {
        Matcher m=REF.matcher(body == null ? "" : body);
        return m.find()?m.group(1).toUpperCase(Locale.ROOT):"";
    }
    public static String amount(String body) {
        return amount(body, category(body));
    }

    /** Extract the accounting amount from the transaction itself. */
    public static String amount(String body, String category) {
        String b = body == null ? "" : body;
        String lower = b.toLowerCase(Locale.ROOT);

        // Automatic fee/Ziidi messages may contain several KSh values. These are
        // separate SENT events and must use the actual fee stated in the message.
        boolean feeLike = "FEE".equals(category)
                || lower.contains("transaction cost")
                || lower.contains("transaction fee")
                || lower.contains("service fee")
                || lower.matches("(?s).*\\b(?:fee|charge|charged)\\b.*");

        if (feeLike && !lower.contains("paid to") && !lower.contains("sent to")
                && !lower.contains("buy goods") && !lower.contains("paybill")) {
            Pattern[] feePatterns = {
                Pattern.compile("(?i)transaction\\s+cost\\s*(?:,|:)?\\s*Ksh\\.?\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)"),
                Pattern.compile("(?i)(?:transaction\\s+fee|service\\s+fee|fee|charge|charged)\\s*(?:,|is|of|:)?\\s*Ksh\\.?\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)")
            };
            for (Pattern pattern : feePatterns) {
                Matcher fm = pattern.matcher(b);
                if (fm.find()) return fm.group(1).replace(",", "");
            }
        }

        // The first KSh amount in a normal M-PESA confirmation is the actual
        // transaction amount; the later KSh amount is normally the new balance.
        Matcher m = AMOUNT.matcher(b);
        return m.find() ? m.group(1).replace(",", "") : "";
    }

    public static String balance(String body) {
        Matcher m=BALANCE.matcher(body == null ? "" : body);
        return m.find()?m.group(1).replace(",",""):"";
    }
    public static String fingerprint(String sender, String body, long timestamp) {
        try {
            String ref=reference(body);
            String raw;
            if(!ref.isEmpty()) {
                raw="MPESA-REF|"+ref.toUpperCase(Locale.ROOT);
            } else {
                // For messages without a receipt reference (for example some automatic
                // fee/airtime notifications), keep a stable event key while allowing
                // genuinely separate transactions to coexist.
                String normalized=(body==null?"":body.trim().replaceAll("\\s+"," ").toLowerCase(Locale.ROOT))
                    .replaceAll("(?i)m-pesa balance is ksh\\.?[0-9,]+(?:\\.[0-9]{1,2})?", "m-pesa balance is ksh")
                    .replaceAll("(?i)new m-pesa balance is ksh\\.?[0-9,]+(?:\\.[0-9]{1,2})?", "new m-pesa balance is ksh");
                long minute=(timestamp/60000L);
                raw=(sender==null?"":sender.trim().toLowerCase(Locale.ROOT))+"|"+minute+"|"+normalized;
            }
            byte[] digest=MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8));
            StringBuilder out=new StringBuilder();
            for(byte b:digest) out.append(String.format(Locale.ROOT,"%02x",b));
            return out.toString();
        } catch(Exception e) { return String.valueOf(timestamp)+"|"+(body==null?"":body); }
    }
    public static String category(String body) {
        String s = body == null ? "" : body.toLowerCase(Locale.ROOT);

        if (s.contains("reversal") || s.contains("reversed")) return "REVERSAL";

        // Incoming money takes precedence over sender-name keywords such as
        // "Safaricom", because a company/bank can legitimately send money.
        if (s.contains("received") || s.contains("credited") || s.contains("deposit")
                || s.contains("money received") || s.contains("received from")) {
            return "RECEIVED";
        }

        // Airtime/bundle purchases are spending, never income.
        if (s.contains("you bought") || s.contains("airtime") || s.contains("bundle")
                || s.contains("bundles") || (s.contains("safaricom")
                && !s.contains("balance") && !s.contains("m-pesa balance"))) {
            return "AIRTIME";
        }

        // Every recognizable outgoing/payment/charge event is SENT. This is the
        // only public label used for fees, withdrawals, payments and transfers.
        if (s.contains("sent to") || s.contains("paid to") || s.contains("paid ")
                || s.contains("payment") || s.contains("purchase") || s.contains("transfer to")
                || s.contains("buy goods") || s.contains("till number") || s.contains("paybill")
                || s.contains("account number") || s.contains("withdraw") || s.contains("withdrawn")
                || s.contains("transaction cost") || s.contains("transaction fee")
                || s.contains("service fee") || s.contains("fee") || s.contains("charge")
                || s.contains("charged") || s.contains("deducted") || s.contains("debit")) {
            return "SENT";
        }

        if (s.contains("fuliza")) return "FULIZA";
        return "OTHER";
    }

}
