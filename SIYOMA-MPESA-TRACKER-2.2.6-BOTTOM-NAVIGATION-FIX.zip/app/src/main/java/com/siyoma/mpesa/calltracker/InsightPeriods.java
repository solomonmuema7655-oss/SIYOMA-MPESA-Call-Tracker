package com.siyoma.mpesa.calltracker;

/** Pure rolling Insight-window calculations. All windows end at the supplied now value. */
public final class InsightPeriods {
    private InsightPeriods() {}
    public static final long HOUR_MS = 60L * 60L * 1000L;
    public static final long DAY_MS = 24L * HOUR_MS;

    public static long[] bounds(String period, long nowMillis) {
        if (nowMillis < 0L) throw new IllegalArgumentException("nowMillis must be non-negative");
        final long duration;
        if ("DAILY".equals(period)) duration = DAY_MS;
        else if ("WEEKLY".equals(period)) duration = 7L * DAY_MS;
        else if ("MONTHLY".equals(period)) duration = 30L * DAY_MS;
        else if ("YEARLY".equals(period)) {
            java.util.Calendar c = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));
            c.setTimeInMillis(nowMillis);
            int year = c.get(java.util.Calendar.YEAR);
            boolean leap = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
            duration = (leap ? 366L : 365L) * DAY_MS;
        } else throw new IllegalArgumentException("Unknown Insight period: " + period);
        return new long[]{nowMillis - duration, nowMillis};
    }
}
