package com.siyoma.mpesa.calltracker;

import org.junit.Test;
import java.math.BigDecimal;
import static org.junit.Assert.*;

public class MoneySummaryTest {
    @Test public void exactAccountingMatchesReceivedSentAirtimeAndProfitLoss() {
        MoneySummary s = new MoneySummary();
        s.add("RECEIVED", "3.00");
        s.add("RECEIVED", "2.00");
        s.add("SENT", "5.00");
        s.add("SENT", "2.60");
        s.add("AIRTIME", "4.40");
        s.add("REVERSAL", "999999.99");
        s.add("OTHER", "888888.88");
        assertEquals(new BigDecimal("5.00"), s.received());
        assertEquals(new BigDecimal("12.00"), s.sent());
        assertEquals(new BigDecimal("4.40"), s.airtime());
        assertEquals(new BigDecimal("-7.00"), s.profitLoss());
        assertEquals(new BigDecimal("17.00"), s.captured());
    }

    @Test public void decimalAdditionDoesNotUseBinaryFloatingPoint() {
        MoneySummary s = new MoneySummary();
        s.add("RECEIVED", "0.10");
        s.add("RECEIVED", "0.20");
        s.add("RECEIVED", "0.30");
        assertEquals(new BigDecimal("0.60"), s.received());
    }

    @Test public void invalidAmountsDoNotCorruptTotals() {
        MoneySummary s = new MoneySummary();
        s.add("SENT", "not-a-number");
        s.add("SENT", "");
        s.add("SENT", "1.25");
        assertEquals(new BigDecimal("1.25"), s.sent());
    }
}
