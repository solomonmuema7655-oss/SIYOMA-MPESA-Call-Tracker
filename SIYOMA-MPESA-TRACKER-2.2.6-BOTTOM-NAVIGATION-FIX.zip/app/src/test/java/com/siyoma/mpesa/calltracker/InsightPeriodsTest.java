package com.siyoma.mpesa.calltracker;

import org.junit.Test;
import java.util.Calendar;
import java.util.TimeZone;
import static org.junit.Assert.*;

public class InsightPeriodsTest {
    private static final long NOW = 1_800_000_000_000L;

    @Test public void dailyIsExactly24Hours() {
        long[] b=InsightPeriods.bounds("DAILY", NOW);
        assertEquals(InsightPeriods.DAY_MS, b[1]-b[0]);
        assertEquals(NOW, b[1]);
    }
    @Test public void weeklyIsExactlySevenDays() {
        long[] b=InsightPeriods.bounds("WEEKLY", NOW);
        assertEquals(7L*InsightPeriods.DAY_MS, b[1]-b[0]);
    }
    @Test public void monthlyIsExactlyThirtyDays() {
        long[] b=InsightPeriods.bounds("MONTHLY", NOW);
        assertEquals(30L*InsightPeriods.DAY_MS, b[1]-b[0]);
    }
    @Test public void yearlyUses365DaysInNonLeapYear() {
        Calendar c=Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear(); c.set(2027, Calendar.JUNE, 1, 12, 0, 0);
        long now=c.getTimeInMillis();
        long[] b=InsightPeriods.bounds("YEARLY", now);
        assertEquals(365L*InsightPeriods.DAY_MS, b[1]-b[0]);
    }
    @Test public void yearlyUses366DaysInLeapYear() {
        Calendar c=Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear(); c.set(2028, Calendar.JUNE, 1, 12, 0, 0);
        long now=c.getTimeInMillis();
        long[] b=InsightPeriods.bounds("YEARLY", now);
        assertEquals(366L*InsightPeriods.DAY_MS, b[1]-b[0]);
    }
    @Test public void exactBoundaryIsStartInclusiveAndEndExclusive() {
        long[] b=InsightPeriods.bounds("DAILY", NOW);
        assertTrue(b[0] < b[1]);
    }
}
