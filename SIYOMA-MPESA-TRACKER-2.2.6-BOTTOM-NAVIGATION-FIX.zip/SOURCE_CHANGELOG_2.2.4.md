# SIYOMA MPESA TRACKER 2.2.4 — M-PESA Classification, Insights & Home Reconciliation Repair

## M-PESA tab
- Public transaction labels are limited to `RECEIVED`, `SENT`, and `AIRTIME`.
- Legacy `FEE`, `DEPOSIT`, `BUY GOODS`, `PAYBILL`, and `WITHDRAWAL` labels are no longer exposed in the M-PESA tab.
- Incoming transactions are classified as `RECEIVED` when the SMS identifies money as received/from an incoming source, including people, banks and companies.
- Outgoing payments and charges are classified as `SENT`.
- Airtime/bundle purchases are classified as `AIRTIME` using purchase/airtime/bundle/Safaricom wording with incoming/outgoing safeguards.
- Stored legacy records are re-derived from their original SMS bodies during database upgrade.
- New records are also re-derived at database insertion so callers cannot introduce inconsistent categories.
- Fee/Ziidi-style automatic deductions use the actual fee amount stated by the SMS; no fixed fee amount is hard-coded.

## Insights
- Daily = rolling last 24 hours from the current time.
- Weekly = rolling last 7 × 24 hours from the current time.
- Monthly = rolling last 30 × 24 hours from the current time.
- Yearly = rolling last 365 or 366 × 24 hours from the current time, according to the current calendar year.
- Transaction timestamps are normalized to Android milliseconds, including legacy rows during upgrade.
- Period totals are calculated from the exact stored transaction rows inside the requested window.
- Summary arithmetic uses `BigDecimal` accumulation rather than SQLite REAL summation.
- A counted-transaction total and exact window are shown in Insights for auditability.
- Reversals and unclassified transactions remain excluded from money totals.

## Home
- Latest M-PESA balance is refreshed from the newest captured balance.
- Live money flow uses the same rolling 24-hour accounting window as Daily Insights.
- Home refreshes on the live M-PESA data-change broadcast and on a periodic live refresh.

## Validation performed here
- `MpesaParser.java` compiled independently with `javac`.
- Representative RECEIVED, AIRTIME, SENT/payment and transaction-cost SMS cases were exercised successfully.
- Full Android/Gradle compilation was not performed in this environment because the uploaded project does not contain a Gradle wrapper and a system Gradle installation is not available here. The supplied GitHub Actions workflow remains configured for Gradle 8.7, Java 17 and Ubuntu 22.04.
