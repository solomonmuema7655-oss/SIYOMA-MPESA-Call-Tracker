# SIYOMA MPESA TRACKER 2.2.6 — Bottom Navigation / System Navigation Fix

## Problem fixed
On devices where the Android system navigation buttons/gesture area overlaps the app window, the phone navigation controls could cover the lower part of SIYOMA MPESA TRACKER's custom HOME / MPESA / INSIGHTS / REPORTS / SETTINGS navigation bar. This made lower app buttons difficult or impossible to access.

## Implementation
- Added AndroidX WindowInsets handling to `MainActivity`.
- The custom bottom navigation now receives the actual system-bar and display-cutout insets.
- The system navigation-bar height is added as bottom padding inside the SIYOMA navigation container.
- Left/right system insets are also respected for landscape and unusual device configurations.
- The five existing app navigation buttons remain in the app navigation bar and are not removed or replaced.
- Applies to gesture navigation and 3-button navigation, and remains compatible with older Android versions.

## Version
- versionCode: 10
- versionName: 2.2.6

## Build note
The source was revised and statically checked in this environment. A complete Android Gradle/device build is not claimed unless GitHub Actions or a real device build confirms it.
