# SIYOMA MPESA TRACKER 2.2.5 — Deep Accounting Repair

This release is a deeper revision of the 2.2.4 accounting repair. It separates the rolling-window calculation and decimal accounting into pure Java components so those rules can be tested independently of Android UI/database code.

## Implemented

- Daily Insight = exact rolling 24 hours ending at the calculation time.
- Weekly Insight = exact rolling 7 x 24 hours ending at the calculation time.
- Monthly Insight = exact rolling 30 x 24 hours ending at the calculation time.
- Yearly Insight = exact rolling 365 x 24 hours, or 366 x 24 hours when the current year is leap.
- Money totals are accumulated with `BigDecimal`; SQLite `SUM(CAST(... AS REAL))` is no longer used by Insights.
- Reversals and unclassified/internal categories are excluded from money totals.
- Actual transaction-fee amounts are extracted from the fee SMS instead of using a fixed fee amount.
- New records are canonicalized from their original SMS body before storage, so caller-provided legacy categories cannot contaminate accounting.
- Database upgrade v10 performs another duplicate cleanup for receipt references/fingerprints and retains one canonical row.
- Incoming wording has priority over sender-name keywords, so money received from Safaricom or another company is RECEIVED rather than AIRTIME.
- Outgoing/payment/charge wording is normalized to SENT; public UI continues to expose only RECEIVED, SENT, and AIRTIME.
- Home and Insights continue to use the same rolling accounting engine.

## Verification performed before packaging

Pure-Java tests were run for:
- parser categories and fee extraction;
- bank/company/Safaricom incoming messages;
- airtime/bundle classification;
- outgoing payment/transfer classification;
- exact decimal addition;
- reversal/unclassified exclusion;
- 24h / 7d / 30d rolling windows;
- 365-day and 366-day yearly windows.

The complete Android Gradle build was not run in this environment because the project does not contain a Gradle wrapper and no system Gradle/Android SDK is installed here. The supplied GitHub Actions workflow remains the authoritative Android build path (Ubuntu 22.04, Java 17, Gradle 8.7, Android SDK 35).
