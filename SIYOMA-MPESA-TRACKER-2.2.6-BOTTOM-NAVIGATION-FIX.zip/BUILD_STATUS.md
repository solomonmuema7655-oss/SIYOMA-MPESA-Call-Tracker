# SIYOMA MPESA TRACKER 2.2.5 Build Status

Source revision: 2.2.5 Deep Accounting Repair.

Verified locally:
- ZIP/source integrity after packaging
- Pure-Java parser tests
- Pure-Java rolling-window tests
- Pure-Java BigDecimal accounting tests
- 365/366-day yearly-window behavior
- incoming/outgoing/airtime/fee classification edge cases

Not claimed as locally verified:
- Android Gradle compilation
- APK installation on a physical Android device
- runtime SMS-provider behavior on a physical phone

Reason: this environment has no Gradle wrapper, system Gradle installation, or Android SDK. GitHub Actions is configured to perform the full Android unit-test and debug/release build on Ubuntu 22.04 with Java 17, Gradle 8.7, and Android SDK 35.
