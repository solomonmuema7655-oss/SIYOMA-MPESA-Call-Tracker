package com.siyoma.mpesa.calltracker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Telephony;
import android.telephony.SmsMessage;

public class MpesaSmsReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent) {
        if(!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        for(SmsMessage sms:Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
            if(sms==null) continue;
            String body=sms.getMessageBody();
            if(!MpesaParser.isMpesa(body)) continue;
            String ref=MpesaParser.reference(body);
            String fingerprint=MpesaParser.fingerprint(sms.getOriginatingAddress(),body,sms.getTimestampMillis());
            TrackerDb db=new TrackerDb(context);
            db.addMpesa(fingerprint,ref,MpesaParser.amount(body),MpesaParser.balance(body),
                MpesaParser.category(body),sms.getOriginatingAddress(),body,sms.getTimestampMillis());
            db.close();
        }
    }
}
