package com.siyoma.mpesa.calltracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;\nimport androidx.core.content.FileProvider;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private LinearLayout content;
    private TrackerDb db;
    private String page="HOME", search="";
    private TextView syncStatus;
    private final String[] perms={Manifest.permission.READ_SMS,Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_CALL_LOG,Manifest.permission.READ_PHONE_STATE};
    private ActivityResultLauncher<String[]> permissionLauncher;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        content=findViewById(R.id.content); db=new TrackerDb(this);
        permissionLauncher=registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
            renderHome(); syncIfAllowed();
        });
        findViewById(R.id.nav_home).setOnClickListener(v->show("HOME"));
        findViewById(R.id.nav_mpesa).setOnClickListener(v->show("MPESA"));
        findViewById(R.id.nav_calls).setOnClickListener(v->show("CALLS"));
        findViewById(R.id.nav_reports).setOnClickListener(v->show("REPORTS"));
        if(!has(Manifest.permission.READ_SMS)||!has(Manifest.permission.READ_CALL_LOG)) permissionLauncher.launch(perms);
        show("HOME");
    }
    @Override protected void onResume(){super.onResume(); if(db!=null) syncIfAllowed();}
    private boolean has(String p){return ContextCompat.checkSelfPermission(this,p)==PackageManager.PERMISSION_GRANTED;}
    private void syncIfAllowed(){
        if(has(Manifest.permission.READ_SMS)||has(Manifest.permission.READ_CALL_LOG)){
            new Thread(()->{
                int m=has(Manifest.permission.READ_SMS)?SyncEngine.syncMpesa(this):0;
                int c=has(Manifest.permission.READ_CALL_LOG)?SyncEngine.syncCalls(this):0;
                runOnUiThread(()->{if(syncStatus!=null)syncStatus.setText("Last sync: "+m+" new M-PESA • "+c+" new calls"); if(page.equals("HOME"))renderHome();});
            }).start();
        }
    }
    private void show(String p){page=p; search=""; if(p.equals("HOME"))renderHome(); else if(p.equals("MPESA"))renderRecords(false); else if(p.equals("CALLS"))renderRecords(true); else renderReports();}
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(null,1);t.setPadding(0,6,0,6);return t;
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}
    private LinearLayout card(){
        LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(dp(16),dp(12),dp(16),dp(12));
        x.setBackgroundResource(R.drawable.bg_card);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(7),0,dp(7));x.setLayoutParams(lp);return x;
    }
    private void renderHome(){
        content.removeAllViews();
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.siyoma_mpesa_call_tracker_logo);
        logo.setAdjustViewBounds(true);logo.setMaxHeight(dp(210));logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        content.addView(logo,new LinearLayout.LayoutParams(-1,dp(190)));
        LinearLayout head=card();head.setBackgroundResource(R.drawable.bg_header);
        TextView hello=text("BUSINESS ACTIVITY OVERVIEW",18,0xffffffff,true);head.addView(hello);
        head.addView(text("Your records stay on this device first. Internet is not required for SMS capture or local history.",13,0xffe7f2ff,false));
        content.addView(head);
        LinearLayout stats=card();
        stats.addView(text("M-PESA TRANSACTIONS",12,0xff0757a6,true));
        stats.addView(text(String.valueOf(db.count("mpesa")),30,0xff10243e,true));
        stats.addView(text("Recorded amounts total: KSh "+String.format(Locale.US,"%.2f",db.sumMpesa()),14,0xff10243e,false));
        content.addView(stats);
        LinearLayout calls=card();calls.addView(text("PHONE CALL HISTORY",12,0xff0757a6,true));
        calls.addView(text(String.valueOf(db.count("calls"))+" records stored",25,0xff10243e,true));
        content.addView(calls);
        syncStatus=text("Syncing records…",13,0xff0757a6,false);content.addView(syncStatus);
        Button sync=button("SYNC ALL HISTORY");sync.setOnClickListener(v->{
            if(!has(Manifest.permission.READ_SMS)||!has(Manifest.permission.READ_CALL_LOG)) permissionLauncher.launch(perms);
            else {syncStatus.setText("Synchronizing…");syncIfAllowed();}
        });content.addView(sync);
        Button perm=button("MANAGE PERMISSIONS");perm.setOnClickListener(v->permissionLauncher.launch(perms));content.addView(perm);
        content.addView(text("Privacy note: M-PESA and call records are stored locally. No calls are recorded and the app does not place calls.",12,0xff52647a,false));
    }
    private Button button(String label){Button b=new Button(this);b.setText(label);b.setAllCaps(false);return b;}
    private void renderRecords(boolean calls){
        content.removeAllViews();
        content.addView(text(calls?"CALL HISTORY":"M-PESA TRANSACTIONS",22,0xff061b3a,true));
        EditText find=new EditText(this);find.setSingleLine(true);find.setHint(calls?"Search number or contact":"Search receipt, category or SMS text");content.addView(find);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        Runnable refresh=()->{
            list.removeAllViews();List<Record> rows=db.records(calls,search);
            if(rows.isEmpty())list.addView(text("No matching records. Grant the required permission and sync history.",14,0xff52647a,false));
            for(Record r:rows){
                LinearLayout c=card();c.addView(text(r.title,17,0xff10243e,true));
                c.addView(text(r.subtitle+" • "+date(r.timestamp),12,0xff0757a6,true));
                if(calls)c.addView(text("Duration: "+duration(r.duration),13,0xff52647a,false));
                else {
                    c.addView(text("Category: "+r.category+"  |  Balance: KSh "+(r.amount==null?"—":r.amount),12,0xff52647a,false));
                    c.addView(text(r.body,12,0xff52647a,false));
                }
                list.addView(c);
            }
        };
        find.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int count,int after){}
            public void onTextChanged(CharSequence s,int st,int before,int count){search=s.toString();refresh.run();}
            public void afterTextChanged(Editable e){}
        });
        refresh.run();
        Button sync=button("REFRESH HISTORY");sync.setOnClickListener(v->{syncIfAllowed();Toast.makeText(this,"History sync requested",Toast.LENGTH_SHORT).show();});content.addView(sync);
    }
    private void renderReports(){
        content.removeAllViews();
        content.addView(text("REPORTS & EXPORTS",22,0xff061b3a,true));
        LinearLayout a=card();a.addView(text("M-PESA RECORDS",13,0xff0757a6,true));
        a.addView(text("Total entries: "+db.count("mpesa"),20,0xff10243e,true));
        a.addView(text("Sum of captured transaction amounts: KSh "+String.format(Locale.US,"%.2f",db.sumMpesa()),14,0xff10243e,false));
        content.addView(a);
        LinearLayout b=card();b.addView(text("CALL ACTIVITY",13,0xff0757a6,true));
        b.addView(text("Total calls: "+db.count("calls"),20,0xff10243e,true));content.addView(b);
        Button m=button("EXPORT M-PESA CSV");m.setOnClickListener(v->exportCsv(false));content.addView(m);
        Button c=button("EXPORT CALL HISTORY CSV");c.setOnClickListener(v->exportCsv(true));content.addView(c);
        Button pdf=button("GENERATE PDF SUMMARY");pdf.setOnClickListener(v->{
            try{share(ExportManager.pdf(this,db),"application/pdf");}catch(Exception e){toast("PDF export failed: "+e.getMessage());}
        });content.addView(pdf);
        content.addView(text("CSV files contain transaction/call records captured on this device. The PDF is a local summary, not an official Safaricom statement.",12,0xff52647a,false));
    }
    private void exportCsv(boolean calls){
        try{share(ExportManager.csv(this,db,calls),"text/csv");}
        catch(Exception e){toast("CSV export failed: "+e.getMessage());}
    }
    private void share(File f,String type){
        Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_STREAM,FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try{startActivity(Intent.createChooser(i,"Share SIYOMA export"));}catch(Exception e){toast("Could not open sharing app");}
    }
    private String date(long t){return new SimpleDateFormat("dd MMM yyyy, HH:mm",Locale.getDefault()).format(new Date(t));}
    private String duration(long sec){return String.format(Locale.getDefault(),"%02d:%02d",sec/60,sec%60);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
