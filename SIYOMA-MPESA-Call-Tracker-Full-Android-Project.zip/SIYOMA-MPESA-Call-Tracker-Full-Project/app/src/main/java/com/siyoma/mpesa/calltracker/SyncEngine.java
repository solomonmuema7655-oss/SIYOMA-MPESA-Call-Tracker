package com.siyoma.mpesa.calltracker;

import android.content.Context;
import android.database.Cursor;
import android.provider.CallLog;
import android.provider.Telephony;

public final class SyncEngine {
    private SyncEngine() {}
    public static int syncMpesa(Context context) {
        int inserted=0;
        String[] p={Telephony.Sms._ID,Telephony.Sms.ADDRESS,Telephony.Sms.BODY,Telephony.Sms.DATE};
        try(Cursor c=context.getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI,p,null,null,Telephony.Sms.DATE+" ASC")) {
            if(c==null) return 0;
            int ixId=c.getColumnIndexOrThrow(Telephony.Sms._ID), ixA=c.getColumnIndexOrThrow(Telephony.Sms.ADDRESS),
                ixB=c.getColumnIndexOrThrow(Telephony.Sms.BODY), ixD=c.getColumnIndexOrThrow(Telephony.Sms.DATE);
            TrackerDb db=new TrackerDb(context);
            while(c.moveToNext()) {
                String body=c.getString(ixB);
                if(!MpesaParser.isMpesa(body)) continue;
                long date=c.getLong(ixD);
                String ref=MpesaParser.reference(body);
                String fingerprint=MpesaParser.fingerprint(c.getString(ixA),body,date);
                if(db.addMpesa(fingerprint,ref,MpesaParser.amount(body),MpesaParser.balance(body),
                    MpesaParser.category(body),c.getString(ixA),body,date)) inserted++;
            }
            db.close();
        } catch(SecurityException ignored) {}
        return inserted;
    }
    public static int syncCalls(Context context) {
        int inserted=0;
        String[] p={CallLog.Calls._ID,CallLog.Calls.NUMBER,CallLog.Calls.CACHED_NAME,
            CallLog.Calls.TYPE,CallLog.Calls.DURATION,CallLog.Calls.DATE};
        try(Cursor c=context.getContentResolver().query(CallLog.Calls.CONTENT_URI,p,null,null,CallLog.Calls.DATE+" ASC")) {
            if(c==null) return 0;
            TrackerDb db=new TrackerDb(context);
            while(c.moveToNext()) {
                if(db.addCall(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getLong(4),c.getLong(5))) inserted++;
            }
            db.close();
        } catch(SecurityException ignored) {}
        return inserted;
    }
}
