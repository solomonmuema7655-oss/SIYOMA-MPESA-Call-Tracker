package com.siyoma.mpesa.calltracker;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;\nimport java.security.MessageDigest;\nimport java.nio.charset.StandardCharsets;

public final class MpesaParser {
    private MpesaParser() {}
    private static final Pattern REF = Pattern.compile("\\b([A-Z0-9]{8,12})\\b");
    private static final Pattern AMOUNT = Pattern.compile("(?i)Ksh\\s*([0-9,]+(?:\\.[0-9]{1,2})?)");
    private static final Pattern BALANCE = Pattern.compile("(?i)(?:new\\s+)?M-PESA\\s+balance\\s+is\\s+Ksh\\s*([0-9,]+(?:\\.[0-9]{1,2})?)");
    public static boolean isMpesa(String body) {
        if (body == null) return false;
        String s=body.toLowerCase(Locale.ROOT);
        return s.contains("m-pesa") || (s.contains("confirmed") && s.contains("ksh"));
    }
    public static String reference(String body) {
        Matcher m=REF.matcher(body == null ? "" : body.toUpperCase(Locale.ROOT));
        return m.find()?m.group(1):"";
    }
    public static String amount(String body) {
        Matcher m=AMOUNT.matcher(body == null ? "" : body);
        return m.find()?m.group(1).replace(",",""):"";
    }
    public static String balance(String body) {
        Matcher m=BALANCE.matcher(body == null ? "" : body);
        return m.find()?m.group(1).replace(",",""):"";
    }

    public static String fingerprint(String sender, String body, long timestamp) {
        try {
            String raw=(sender==null?"":sender)+"|"+timestamp+"|"+(body==null?"":body.trim());
            byte[] digest=MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8));
            StringBuilder out=new StringBuilder();
            for(byte b:digest) out.append(String.format(Locale.ROOT,"%02x",b));
            return out.toString();
        } catch(Exception e) { return String.valueOf(timestamp)+"|"+(body==null?"":body); }
    }
    public static String category(String body) {
        String s=body == null ? "" : body.toLowerCase(Locale.ROOT);
        if (s.contains("reversal") || s.contains("reversed")) return "REVERSAL";
        if (s.contains("received") || s.contains("from ")) return "RECEIVED";
        if (s.contains("paybill")) return "PAYBILL";
        if (s.contains("buy goods") || s.contains("till number")) return "BUY GOODS";
        if (s.contains("airtime")) return "AIRTIME";
        if (s.contains("withdraw")) return "WITHDRAWAL";
        if (s.contains("deposit")) return "DEPOSIT";
        if (s.contains("sent to") || s.contains("paid to")) return "SENT";
        return "OTHER";
    }
}
