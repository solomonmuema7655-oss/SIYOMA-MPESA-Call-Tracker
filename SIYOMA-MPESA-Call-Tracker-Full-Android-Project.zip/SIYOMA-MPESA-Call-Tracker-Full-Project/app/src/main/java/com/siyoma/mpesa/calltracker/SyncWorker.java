package com.siyoma.mpesa.calltracker;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class SyncWorker extends Worker {
    public SyncWorker(@NonNull Context c,@NonNull WorkerParameters p) { super(c,p); }
    @NonNull @Override public Result doWork() {
        Context c=getApplicationContext();
        if(c.checkSelfPermission(android.Manifest.permission.READ_CALL_LOG)==android.content.pm.PackageManager.PERMISSION_GRANTED)
            SyncEngine.syncCalls(c);
        if(c.checkSelfPermission(android.Manifest.permission.READ_SMS)==android.content.pm.PackageManager.PERMISSION_GRANTED)
            SyncEngine.syncMpesa(c);
        return Result.success();
    }
}
