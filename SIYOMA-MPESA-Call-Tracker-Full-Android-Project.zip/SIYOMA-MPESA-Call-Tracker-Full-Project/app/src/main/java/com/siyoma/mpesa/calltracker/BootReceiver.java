package com.siyoma.mpesa.calltracker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent) {
        if(Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) ||
           Intent.ACTION_MY_PACKAGE_REPLACED.equals(intent.getAction())) {
            WorkManager.getInstance(context).enqueue(new OneTimeWorkRequest.Builder(SyncWorker.class).build());
        }
    }
}
