package com.siyoma.mpesa.calltracker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Environment;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class ExportManager {
    private ExportManager() {}
    public static File csv(Context c,TrackerDb db,boolean calls) throws Exception {
        File dir=new File(c.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"SIYOMA-Exports");
        if(!dir.exists()) dir.mkdirs();
        File f=new File(dir,(calls?"call-history":"mpesa-transactions")+"-"+System.currentTimeMillis()+".csv");
        try(OutputStreamWriter w=new OutputStreamWriter(new FileOutputStream(f),"UTF-8")) {
            if(calls) {
                w.write("Date,Contact,Number,Call type,Duration seconds\n");
                for(Record r:db.allCalls()) w.write(q(date(r.timestamp))+","+q(r.title)+","+q(r.subtitle)+","+q(r.category)+","+r.duration+"\n");
            } else {
                w.write("Date,Reference,Category,Amount KES,Balance KES,Sender,Original SMS\n");
                for(Record r:db.allMpesa()) w.write(q(date(r.timestamp))+","+q(r.reference)+","+q(r.category)+","+q(r.title.replace("KSh ",""))+","+q(r.amount)+","+q(r.subtitle)+","+q(r.body)+"\n");
            }
        }
        return f;
    }
    public static File pdf(Context c,TrackerDb db) throws Exception {
        File dir=new File(c.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"SIYOMA-Exports");
        if(!dir.exists()) dir.mkdirs();
        File f=new File(dir,"SIYOMA-summary-"+System.currentTimeMillis()+".pdf");
        PdfDocument pdf=new PdfDocument();
        PdfDocument.Page page=pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());
        Canvas canvas=page.getCanvas(); Paint p=new Paint(3);
        p.setColor(0xff061b3a); p.setTextSize(24); canvas.drawText("SIYOMA",40,55,p);
        p.setTextSize(15); canvas.drawText("M-PESA & CALL TRACKER — SUMMARY",40,82,p);
        p.setColor(0xff0757a6); p.setTextSize(12);
        canvas.drawText("Generated: "+date(System.currentTimeMillis()),40,115,p);
        p.setColor(0xff10243e); p.setTextSize(14);
        canvas.drawText("M-PESA records: "+db.count("mpesa"),40,160,p);
        canvas.drawText("Call history records: "+db.count("calls"),40,190,p);
        canvas.drawText("Recorded transaction amounts total: KSh "+String.format(Locale.US,"%.2f",db.sumMpesa()),40,220,p);
        p.setTextSize(10); canvas.drawText("This report reflects M-PESA SMS records available to the app.",40,270,p);
        canvas.drawText("It is not an official Safaricom statement or bank reconciliation.",40,290,p);
        pdf.finishPage(page);
        try(FileOutputStream out=new FileOutputStream(f)){pdf.writeTo(out);}
        pdf.close(); return f;
    }
    private static String q(String s){return "\""+(s==null?"":s.replace("\"","\"\"").replace("\n"," "))+"\"";}
    private static String date(long t){return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault()).format(new Date(t));}
}
