# Build and verification status

This is a substantially expanded Android source project with the branded app artwork and core local tracking workflows.

Not yet verified in this environment:
- Gradle compilation.
- Installation and runtime behavior on a physical Android phone.
- SMS delivery behavior across device vendors and Android releases.
- Call-log permission approval / Google Play policy eligibility.
- CSV/PDF share flow on the target device.

A successful GitHub Actions build is the next gate. After that, install the generated APK on the target phone and verify:
1. permission grant/deny paths,
2. import of the complete existing call log,
3. import of existing M-PESA inbox history,
4. live M-PESA SMS reception,
5. duplicate prevention on repeated sync,
6. reboot resynchronization,
7. CSV/PDF export and file sharing.
