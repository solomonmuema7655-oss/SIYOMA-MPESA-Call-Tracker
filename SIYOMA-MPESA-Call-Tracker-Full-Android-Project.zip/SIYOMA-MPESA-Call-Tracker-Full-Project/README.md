# SIYOMA M-PESA & Call Tracker — Full Android Project

Official SIYOMA TECH DESIGNS application project. The approved SIYOMA M-PESA & Call Tracker artwork is included as the in-app brand image and Android launcher icon in all standard densities.

## Implemented application scope
- Local SQLite persistence for M-PESA and call-history records.
- Historical M-PESA inbox scan, filtering messages to M-PESA-related SMS only.
- Real-time SMS_RECEIVED receiver for M-PESA notifications.
- Receipt/reference, amount, balance, category, sender and original message capture.
- Full call-log query ordered chronologically, with source call IDs used for duplicate prevention.
- Incoming, outgoing, missed, rejected and blocked type labels where Android exposes those call types.
- Local-first operation; no internet is required for receiving SMS or reading device history.
- Dashboard counts and captured amount total.
- Searchable M-PESA and call-history screens.
- CSV exports for M-PESA and call history, plus PDF summary export.
- Boot and app-replacement resynchronization through WorkManager.
- User-granted runtime permission flow.
- No call audio recording, no dialer replacement, and no placing calls.

## Build
The GitHub Actions workflow installs Gradle 8.7, uses Ubuntu 22.04 and Java 17, and produces Debug and Release APK artifacts.

## Important platform / policy notes
- Android SMS and Call Log permissions are sensitive. Google Play distribution requires the app's use case to meet current policy and pass review; inclusion in the manifest does not guarantee approval.
- Android and device manufacturers may restrict SMS/call-log access. Test on the intended Android versions and real devices.
- The transaction total is the sum of parsed amounts present in M-PESA SMS messages; it is not an authoritative account balance. The app does not connect to Safaricom or verify transactions with Daraja.
- Records are stored locally. Cloud backup/synchronization is not implemented in this project.
- Export sharing uses Android's system share sheet; test with the target Android version and installed share targets.
- This source package has not yet been compiled or device-tested in this environment. The CI workflow is provided to compile it; do not treat the APK as verified until a successful workflow and real-device test have been completed.

Developer: SIYOMA TECH DESIGNS
Copyright © 2026 SiyomaCodingPrograms.
