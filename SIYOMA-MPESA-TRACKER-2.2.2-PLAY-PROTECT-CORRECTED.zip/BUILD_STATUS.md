# Build status — Option A policy redesign

## Implemented in this source package
- Removed `READ_CALL_LOG`, `READ_PHONE_STATE`, all CallLog provider queries, and phone-state broadcast receiver.
- Removed background call-log synchronization.
- Calls section now supports user-entered call activity only; it does not read the device call history.
- Database upgrade clears prior automatically imported call-log rows. New manual call entries are retained locally.
- Retained `READ_SMS` and `RECEIVE_SMS` solely for the disclosed M-PESA SMS money-management feature.
- Added prominent in-app disclosure and consent before runtime SMS permission request.
- Retained M-PESA historical inbox scan, incoming SMS receiver, local storage, deduplication, reports, CSV/PDF export, backup/restore, and SIYOMA branding.
- Added Play Console submission checklist and privacy-policy draft.

## Policy status
SMS-based money management is an eligible Google Play exception use case subject to review and approval. This package has not been approved by Google. The SMS permissions can still trigger Play Protect blocking when an APK is installed from an internet sideloading source. Google Play distribution and permission declaration review are the intended route.

## Verification status
Source-level checks: manifest parsed; restricted call-log and phone-state permissions/provider references absent from app source; obsolete phone-state receiver removed; project ZIP integrity will be checked after packaging.

Not yet verified: Android Gradle compilation, APK installation, Google Play SMS permission approval, live M-PESA SMS behavior on a physical device, backup/restore on device, or Play Protect classification. Do not describe this build as production-certified until those tests pass.


## 2.2.2 Play Protect / Debug identity correction
- Debug build no longer appends `.debug` to the application ID.
- GitHub Actions verifies the generated DEBUG APK with Android `apksigner`.
- No Play Protect bypass or security weakening was added.
