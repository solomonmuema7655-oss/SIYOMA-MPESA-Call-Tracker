package com.siyoma.mpesa.calltracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class TrackerDb extends SQLiteOpenHelper {
    private static final String DB="siyoma_mpesa_tracker.db";
    public static final int VERSION=4;
    public TrackerDb(Context c) { super(c, DB, null, VERSION); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE mpesa (_id INTEGER PRIMARY KEY AUTOINCREMENT, fingerprint TEXT UNIQUE, reference TEXT, amount TEXT, balance TEXT, category TEXT, sender TEXT, body TEXT, time INTEGER)");
        db.execSQL("CREATE INDEX idx_mpesa_time ON mpesa(time)");
        db.execSQL("CREATE INDEX idx_mpesa_category ON mpesa(category)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV) {
        if (oldV < 2) db.execSQL("CREATE INDEX IF NOT EXISTS idx_mpesa_category ON mpesa(category)");
        if (oldV < 3) { try { db.execSQL("DROP TABLE IF EXISTS calls"); } catch(Exception ignored) {} }
        if (oldV < 4) { try { db.execSQL("DROP TABLE IF EXISTS calls"); } catch(Exception ignored) {} }
    }
    public synchronized boolean addMpesa(String fingerprint,String ref,String amount,String balance,String category,String sender,String body,long time) {
        ContentValues v=new ContentValues(); v.put("fingerprint",fingerprint); v.put("reference",ref);
        v.put("amount",amount); v.put("balance",balance); v.put("category",category);
        v.put("sender",sender); v.put("body",body); v.put("time",time);
        return getWritableDatabase().insertWithOnConflict("mpesa",null,v,SQLiteDatabase.CONFLICT_IGNORE)!=-1;
    }
    public int count() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM mpesa",null)) { return c.moveToFirst()?c.getInt(0):0; }
    }
    public double sumMpesa() { return sumMpesa(0L,Long.MAX_VALUE); }
    public double sumMpesa(long startInclusive,long endExclusive) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(CAST(amount AS REAL)),0) FROM mpesa WHERE time>=? AND time<?",new String[]{String.valueOf(startInclusive),String.valueOf(endExclusive)})) { return c.moveToFirst()?c.getDouble(0):0; }
    }
    public double latestBalance() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT balance FROM mpesa WHERE balance IS NOT NULL AND TRIM(balance)<>'' ORDER BY time DESC LIMIT 1",null)) {
            if(!c.moveToFirst()) return Double.NaN;
            try{return Double.parseDouble(c.getString(0).replace(",",""));}catch(Exception e){return Double.NaN;}
        }
    }
    public double[] summary(long startInclusive,long endExclusive) {
        double received=0, sent=0, airtime=0;
        String sql="SELECT category, COALESCE(SUM(CAST(amount AS REAL)),0) FROM mpesa WHERE time>=? AND time<? GROUP BY category";
        try(Cursor c=getReadableDatabase().rawQuery(sql,new String[]{String.valueOf(startInclusive),String.valueOf(endExclusive)})) {
            while(c.moveToNext()) {
                String cat=c.getString(0); double v=c.getDouble(1);
                if("RECEIVED".equals(cat)||"DEPOSIT".equals(cat)) received+=v;
                else if("AIRTIME".equals(cat)) { sent+=v; airtime+=v; }
                else if("SENT".equals(cat)||"BUY GOODS".equals(cat)||"PAYBILL".equals(cat)||"WITHDRAWAL".equals(cat)) sent+=v;
            }
        }
        return new double[]{received,sent,airtime,received-sent};
    }
    public List<Record> records(String query) { return records(query,0L,Long.MAX_VALUE); }
    public List<Record> records(String query,long startInclusive,long endExclusive) {
        List<Record> out=new ArrayList<>(); String q="%"+(query==null?"":query.trim())+"%";
        String sql="SELECT _id,reference,amount,balance,category,sender,body,time FROM mpesa WHERE (body LIKE ? OR reference LIKE ? OR category LIKE ? OR sender LIKE ?) AND time>=? AND time<? ORDER BY time DESC";
        String[] args={q,q,q,q,String.valueOf(startInclusive),String.valueOf(endExclusive)};
        try(Cursor c=getReadableDatabase().rawQuery(sql,args)) {
            while(c.moveToNext()) out.add(new Record(c.getLong(0),c.getLong(7),"KSh "+(c.getString(2)==null?"—":c.getString(2)),c.getString(5)==null?"":c.getString(5),c.getString(6),c.getString(1),c.getString(4),c.getString(3),0,0,false));
        }
        return out;
    }
    public List<Record> allMpesa(){return records("");}
}
