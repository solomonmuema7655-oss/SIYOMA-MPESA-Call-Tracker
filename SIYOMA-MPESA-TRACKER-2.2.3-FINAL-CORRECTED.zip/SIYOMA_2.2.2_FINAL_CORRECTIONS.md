# SIYOMA MPESA TRACKER — FINAL CORRECTIONS

- Legacy FEE records migrate to SENT.
- Fee/Ziidi messages are classified as SENT and fee amount extraction is preserved.
- M-PESA tab exposes only RECEIVED or SENT + AIRTIME.
- Dashboard money flow is explicitly the rolling last 24 hours and refreshes from live SMS events plus periodic refresh.
- Insights use strict rolling windows: 24h, 7d, 30d, 365/366d.
- Existing backup/restore, CSV/PDF reports, privacy/PIN, dark mode, biometric unlock, SMS sync, boot receiver and SIYOMA branding are preserved.
