# SIYOMA MPESA TRACKER 2.2.2 — DEBUG BUILD NOTE

The DEBUG APK is a genuine development build and is not a Play Store release.

This project does **not** disable, bypass, or weaken Google Play Protect. No source ZIP can
guarantee that a sideloaded APK requesting SMS permissions will never trigger a Play Protect
warning. Android/Google may evaluate the APK, its signing identity, installation source, and
sensitive permissions independently of the source code.

The debug build uses the normal SIYOMA application ID (`com.siyoma.mpesa.calltracker`) rather
than a separate `.debug` application ID. The GitHub Actions workflow also verifies the APK with
Android's `apksigner` before publishing the artifact.

For public distribution, use a properly signed release build and the appropriate Google Play
SMS-permission approval/policy path. Do not disable Play Protect to install the application.
