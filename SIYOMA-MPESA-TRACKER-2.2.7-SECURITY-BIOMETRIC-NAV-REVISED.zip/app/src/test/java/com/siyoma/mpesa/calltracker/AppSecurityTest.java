package com.siyoma.mpesa.calltracker;

import org.junit.Test;
import static org.junit.Assert.*;

public class AppSecurityTest {
    @Test public void normalizesAndValidatesRecoveryEmail() {
        assertEquals("user@example.com", AppSecurity.normalizeEmail("  USER@Example.COM "));
        assertTrue(AppSecurity.isValidEmail("user@example.com"));
        assertFalse(AppSecurity.isValidEmail("not-an-email"));
    }

    @Test public void pinHashVerifiesOnlyTheCorrectPin() {
        String salt="test-salt";
        String hash=AppSecurity.hashPin("123456",salt);
        assertTrue(AppSecurity.verifyPin("123456",salt,hash));
        assertFalse(AppSecurity.verifyPin("123457",salt,hash));
        assertFalse(AppSecurity.verifyPin("",salt,hash));
    }
}
