package com.siyoma.mpesa.calltracker;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

/** Pure local security helpers used by the app PIN and recovery-email flow. */
public final class AppSecurity {
    private AppSecurity() {}

    public static String normalizeEmail(String email) {
        return email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
    }

    public static boolean isValidEmail(String email) {
        return normalizeEmail(email).matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");
    }

    public static String hashPin(String pin, String salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest((salt + ":" + pin).getBytes(StandardCharsets.UTF_8));
            StringBuilder s = new StringBuilder();
            for (byte x : b) s.append(String.format(Locale.ROOT, "%02x", x));
            return s.toString();
        } catch (Exception e) {
            throw new IllegalStateException("SHA-256 unavailable", e);
        }
    }

    public static boolean verifyPin(String pin, String salt, String storedHash) {
        if (pin == null || pin.isEmpty() || salt == null || storedHash == null || storedHash.isEmpty()) return false;
        return hashPin(pin, salt).equals(storedHash);
    }
}
