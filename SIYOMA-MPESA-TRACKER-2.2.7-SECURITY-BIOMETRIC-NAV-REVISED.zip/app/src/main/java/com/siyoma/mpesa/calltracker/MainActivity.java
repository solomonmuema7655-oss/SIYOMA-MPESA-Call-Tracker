package com.siyoma.mpesa.calltracker;

import android.Manifest;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends AppCompatActivity {
    public static final String ACTION_MONEY_DATA_CHANGED="com.siyoma.mpesa.calltracker.MONEY_DATA_CHANGED";
    private LinearLayout content;
    private TextView balanceSummary;
    private boolean dataReceiverRegistered=false;
    private final BroadcastReceiver moneyDataReceiver=new BroadcastReceiver(){
        @Override public void onReceive(android.content.Context context,Intent intent){
            runOnUiThread(()->{
                if(page.equals("HOME")) updateHomeLive();
                else if(page.equals("MPESA")) renderMpesa();
                else if(page.equals("INSIGHTS")) renderInsights();
                else if(page.equals("REPORTS")) renderReports();
            });
        }
    };
    private TrackerDb db;
    private String page="HOME", search="";
    private TextView liveClock, liveSummary, syncStatus;
    private long rangeStart=0L, rangeEnd=Long.MAX_VALUE;
    private String insightPeriod="DAILY";
    private final AtomicBoolean syncing=new AtomicBoolean(false);
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final String[] perms={Manifest.permission.READ_SMS,Manifest.permission.RECEIVE_SMS};
    private ActivityResultLauncher<String[]> permissionLauncher;
    private ActivityResultLauncher<String> backupLauncher;
    private ActivityResultLauncher<String[]> restoreLauncher;
    private SharedPreferences prefs;
    private FrameLayout activityContainer;
    private View lockOverlay;
    private boolean appLocked=false;
    private boolean authenticationInProgress=false;
    private boolean launchedOnce=false;
    private final Runnable liveTicker = new Runnable() {
        @Override public void run() {
            updateLiveClock();
            if(page.equals("HOME") || page.equals("INSIGHTS")) {
                if(page.equals("HOME")) updateHomeLive(); else renderInsights();
            }
            handler.postDelayed(this,5000);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("siyoma_settings",MODE_PRIVATE);
        AppCompatDelegate.setDefaultNightMode(prefs.getBoolean("dark_mode",false)?AppCompatDelegate.MODE_NIGHT_YES:AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(R.layout.activity_main);
        activityContainer=findViewById(android.R.id.content);
        content=findViewById(R.id.content); db=new TrackerDb(this);
        installSystemBarInsetsProtection();
        applySurfaceTheme();
        permissionLauncher=registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> { renderHome(); syncIfAllowed(); });
        backupLauncher=registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"), uri -> { if(uri!=null) writeBackup(uri); });
        restoreLauncher=registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> { if(uri!=null) restoreBackup(uri); });
        findViewById(R.id.nav_home).setOnClickListener(v->show("HOME"));
        findViewById(R.id.nav_mpesa).setOnClickListener(v->show("MPESA"));
        findViewById(R.id.nav_insights).setOnClickListener(v->show("INSIGHTS"));
        findViewById(R.id.nav_reports).setOnClickListener(v->show("REPORTS"));
        findViewById(R.id.nav_settings).setOnClickListener(v->show("SETTINGS"));
        configureBottomNavigation();
        show("HOME");
        launchedOnce=true;
        if(hasAppPin()) showAppLock();
        if((!has(Manifest.permission.READ_SMS)||!has(Manifest.permission.RECEIVE_SMS)) && !prefs.getBoolean("sms_disclosure_shown",false)) {
            prefs.edit().putBoolean("sms_disclosure_shown",true).apply(); showSmsDisclosure();
        }
    }
    @Override protected void onResume(){super.onResume();
        if(!dataReceiverRegistered){ContextCompat.registerReceiver(this,moneyDataReceiver,new IntentFilter(ACTION_MONEY_DATA_CHANGED),ContextCompat.RECEIVER_NOT_EXPORTED);dataReceiverRegistered=true;}
        handler.removeCallbacks(liveTicker); handler.post(liveTicker); if(db!=null) syncIfAllowed();
    }
    @Override protected void onPause(){super.onPause();handler.removeCallbacks(liveTicker);if(dataReceiverRegistered){unregisterReceiver(moneyDataReceiver);dataReceiverRegistered=false;}}
    private boolean has(String p){return ContextCompat.checkSelfPermission(this,p)==PackageManager.PERMISSION_GRANTED;}
    private void syncIfAllowed(){
        // History synchronization only requires READ_SMS. RECEIVE_SMS is needed for
        // future automatic capture, but must never prevent the user from importing
        // the M-PESA history already present on the device.
        if(!has(Manifest.permission.READ_SMS)){
            showSmsDisclosure();
            return;
        }
        if(syncing.get()){
            if(syncStatus!=null) syncStatus.setText("Synchronizing M-PESA history…");
            return;
        }
        if(!syncing.compareAndSet(false,true)) return;
        if(syncStatus!=null) syncStatus.setText("Synchronizing M-PESA history…");
        new Thread(()->{
            int inserted=0; String status;
            try {
                inserted=SyncEngine.syncMpesa(this);
                status=inserted>0 ? "M-PESA data synchronized • "+inserted+" new transaction"+(inserted==1?"":"s") : "Already synchronized to real-time M-PESA data";
            } catch(Exception e){
                status="Synchronization paused: "+(e.getMessage()==null?"permission or SMS provider issue":e.getMessage());
            } finally { syncing.set(false); }
            final String finalStatus=status;
            runOnUiThread(()->{
                if(syncStatus!=null) syncStatus.setText(finalStatus);
                if(page.equals("HOME")) updateHomeLive();
                else if(page.equals("MPESA")) renderMpesa();
                else if(page.equals("INSIGHTS")) renderInsights();
                else if(page.equals("REPORTS")) renderReports();
            });
        },"SIYOMA-mpesa-sync").start();
    }
    private void show(String p){
        if(appLocked) return;
        page=p;search="";rangeStart=0;rangeEnd=Long.MAX_VALUE;
        if(p.equals("HOME"))renderHome();
        else if(p.equals("MPESA"))renderMpesa();
        else if(p.equals("INSIGHTS"))renderInsights();
        else if(p.equals("REPORTS"))renderReports();
        else renderSettings();
        applySurfaceTheme();
        updateBottomNavigationState();
    }
    private void configureBottomNavigation(){
        int[] ids={R.id.nav_home,R.id.nav_mpesa,R.id.nav_insights,R.id.nav_reports,R.id.nav_settings};
        String[] labels={"HOME","MPESA","INSIGHTS","REPORTS","SETTINGS"};
        for(int i=0;i<ids.length;i++){
            Button b=findViewById(ids[i]);
            if(b==null) continue;
            b.setText(labels[i]);
            b.setAllCaps(false);
            b.setTextSize(10.5f);
            b.setMinHeight(dp(52));
            b.setMinWidth(0);
            b.setGravity(android.view.Gravity.CENTER);
            b.setContentDescription(labels[i]+" tab");
            b.setSingleLine(true);
            b.setIncludeFontPadding(false);
            b.setOnFocusChangeListener((v,hasFocus)->{ if(hasFocus) v.setAlpha(1f); });
        }
        updateBottomNavigationState();
    }

    private void updateBottomNavigationState(){
        int[] ids={R.id.nav_home,R.id.nav_mpesa,R.id.nav_insights,R.id.nav_reports,R.id.nav_settings};
        String[] pages={"HOME","MPESA","INSIGHTS","REPORTS","SETTINGS"};
        for(int i=0;i<ids.length;i++){
            Button b=findViewById(ids[i]);
            if(b==null) continue;
            boolean selected=page.equals(pages[i]);
            GradientDrawable bg=new GradientDrawable();
            bg.setCornerRadius(dp(12));
            bg.setColor(darkMode()?(selected?0xff172d45:0xff050505):(selected?0xffffffff:0xff061b3a));
            if(selected) bg.setStroke(dp(1),darkMode()?0xff73c9ff:0xff5b9bd5);
            b.setBackground(bg);
            b.setTextColor(darkMode()?0xfff5f7fa:(selected?0xff061b3a:0xffffffff));
            b.setAlpha(selected?1f:0.9f);
        }
    }

    /**
     * Android 15 / target SDK 35 uses edge-to-edge layouts. The phone's own
     * navigation bar can therefore overlap a custom bottom navigation view.
     * Reserve the real system navigation inset inside our app navigation bar
     * so all five SIYOMA buttons remain visible and tappable on both gesture
     * and 3-button navigation modes.
     */
    private void installSystemBarInsetsProtection(){
        final View nav=findViewById(R.id.navigation);
        if(nav==null) return;
        final int baseTop=dp(6), baseBottom=dp(6);
        ViewCompat.setOnApplyWindowInsetsListener(nav,(v,insets)->{
            androidx.core.graphics.Insets bars=insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(
                    Math.max(0,bars.left),
                    baseTop,
                    Math.max(0,bars.right),
                    baseBottom + Math.max(0,bars.bottom)
            );
            return insets;
        });
        ViewCompat.requestApplyInsets(nav);
    }

    private boolean darkMode(){return prefs!=null && prefs.getBoolean("dark_mode",false);}
    private int themedTextColor(int original){
        if(!darkMode()) return original;
        if(original==Color.WHITE || original==0xffffffff || original==0xffe7f2ff) return original;
        if(original==0xff0757a6 || original==0xff061b3a) return 0xff73c9ff;
        if(original==0xff52647a || original==0xff10243e) return 0xffe2e8f0;
        return original;
    }
    private void applySurfaceTheme(){
        int bg=darkMode()?0xff000000:0xfff4f7fb;
        View appRoot=findViewById(android.R.id.content); if(appRoot!=null) appRoot.setBackgroundColor(bg);
        View root=findViewById(R.id.scroll); if(root!=null) root.setBackgroundColor(bg);
        View nav=findViewById(R.id.navigation); if(nav!=null) nav.setBackgroundColor(darkMode()?0xff050505:0xff061b3a);
        if(content!=null) content.setBackgroundColor(bg);
        getWindow().setStatusBarColor(darkMode()?0xff000000:0xff061b3a);
        getWindow().setNavigationBarColor(darkMode()?0xff000000:0xff061b3a);
        getWindow().getDecorView().setSystemUiVisibility(darkMode()?0:0);
        if(content!=null){
            for(int i=0;i<content.getChildCount();i++) themeView(content.getChildAt(i));
        }
        updateBottomNavigationState();
    }
    private void themeView(View v){
        if(v instanceof EditText){
            EditText e=(EditText)v; e.setTextColor(darkMode()?0xfff5f7fa:0xff10243e); e.setHintTextColor(darkMode()?0xff9aa7b8:0xff6b7280);
            e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(darkMode()?0xff73c9ff:0xff0757a6));
        } else if(v instanceof Button){
            Button b=(Button)v; b.setTextColor(darkMode()?0xfff5f7fa:0xff061b3a);
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(darkMode()?0xff172235:0xffffffff));
        }
        if(v instanceof android.view.ViewGroup){
            android.view.ViewGroup g=(android.view.ViewGroup)v; for(int i=0;i<g.getChildCount();i++) themeView(g.getChildAt(i));
        }
    }
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(themedTextColor(color));if(bold)t.setTypeface(null,1);t.setPadding(0,dp(6),0,dp(6));return t;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private LinearLayout card(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(dp(16),dp(12),dp(16),dp(12));
        if(darkMode()){GradientDrawable shape=new GradientDrawable();shape.setColor(0xff111111);shape.setCornerRadius(dp(18));shape.setStroke(dp(1),0xff27303a);x.setBackground(shape);}else x.setBackgroundResource(R.drawable.bg_card);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(7),0,dp(7));x.setLayoutParams(lp);return x;}
    private Button button(String label){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(darkMode()?0xfff5f7fa:0xff061b3a);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(darkMode()?0xff172235:0xffffffff));return b;}
    private void renderHome(){
        content.removeAllViews();
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.siyoma_mpesa_call_tracker_logo);logo.setAdjustViewBounds(true);logo.setMaxHeight(dp(210));logo.setScaleType(ImageView.ScaleType.FIT_CENTER);content.addView(logo,new LinearLayout.LayoutParams(-1,dp(190)));
        LinearLayout head=card();
        if(darkMode()){GradientDrawable hd=new GradientDrawable();hd.setColor(0xff050505);hd.setCornerRadius(dp(22));hd.setStroke(dp(1),0xff27303a);head.setBackground(hd);}else head.setBackgroundResource(R.drawable.bg_header);
        head.addView(text("SIYOMA MPESA TRACKER",20,0xffffffff,true));liveClock=text("LIVE • --:--:-- EAT",13,0xffe7f2ff,true);head.addView(liveClock);head.addView(text("Real-time M-PESA money-management overview from captured M-PESA SMS.",13,0xffe7f2ff,false));content.addView(head);
        LinearLayout live=card();live.addView(text("LIVE MONEY FLOW — TODAY • LAST 24 HOURS",12,0xff0757a6,true));liveSummary=text("Loading…",14,0xff10243e,true);live.addView(liveSummary);content.addView(live);
        LinearLayout balance=card();balance.addView(text("LATEST M-PESA BALANCE",12,0xff0757a6,true));double bal=db.latestBalance();balanceSummary=text(Double.isNaN(bal)?"Not available":"KSh "+money(bal),28,0xff10243e,true);balance.addView(balanceSummary);balance.addView(text("Taken from the most recent captured M-PESA SMS that contains a balance.",12,0xff52647a,false));content.addView(balance);
        LinearLayout access=card();access.addView(text("M-PESA SMS ACCESS",12,0xff0757a6,true));access.addView(text(has(Manifest.permission.READ_SMS)&&has(Manifest.permission.RECEIVE_SMS)?"Enabled":"Permission needed",13,0xff10243e,false));content.addView(access);
        LinearLayout stats=card();stats.addView(text("TRACKED M-PESA SMS",12,0xff0757a6,true));stats.addView(text(String.valueOf(db.count()),30,0xff10243e,true));stats.addView(text("Transactions stored locally on this device.",13,0xff10243e,false));content.addView(stats);
        syncStatus=text(syncing.get()?"Synchronizing M-PESA history…":"M-PESA data is synchronized",12,0xff52647a,false);content.addView(syncStatus);
        Button sync=button("SYNC M-PESA HISTORY NOW");sync.setOnClickListener(v->syncIfAllowed());content.addView(sync);
        Button insights=button("OPEN MONEY INSIGHTS");insights.setOnClickListener(v->show("INSIGHTS"));content.addView(insights);
        content.addView(text("SIYOMA does not replace your SMS app, read call logs, record calls, or place calls. This app is focused exclusively on M-PESA SMS transaction tracking and money-flow analysis.",12,0xff52647a,false));
        updateLiveClock();updateHomeLive();
    }
    private void updateLiveClock(){if(liveClock!=null){liveClock.setText("LIVE • "+new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date())+" EAT");}}
    private void updateHomeLive(){if(db==null)return;
        if(balanceSummary!=null){double bal=db.latestBalance();balanceSummary.setText(Double.isNaN(bal)?"Not available":"KSh "+money(bal));}
        if(liveSummary!=null){long[] r=periodBounds("DAILY");double[] s=db.summary(r[0],r[1]);liveSummary.setText("Received: KSh "+money(s[0])+"\nSent + Airtime: KSh "+money(s[1])+"\nProfit/Loss: "+(s[3]>=0?"+":"-")+"KSh "+money(Math.abs(s[3])));}
    }
    private void showSmsDisclosure(){new AlertDialog.Builder(this).setTitle("M-PESA SMS access").setMessage("SIYOMA MPESA TRACKER uses SMS access only to identify and store M-PESA transaction messages for your personal money-management records. It does not send SMS, replace your SMS app, read call logs, or share your message content for advertising. Captured data is stored locally on this device. You can decline, but automatic M-PESA capture and inbox import will remain unavailable. Google Play approval is required before public distribution with these permissions.").setNegativeButton("NOT NOW",null).setPositiveButton("I AGREE — CONTINUE",(d,w)->permissionLauncher.launch(perms)).show();}
    private void renderMpesa(){
        content.removeAllViews();content.addView(text("M-PESA",22,0xff061b3a,true));content.addView(text("Live M-PESA history • RECEIVED and SENT + AIRTIME.",13,0xff52647a,false));
        EditText find=new EditText(this);find.setSingleLine(true);find.setHint("Search receipt, sender or SMS text");content.addView(find);
        LinearLayout filters=new LinearLayout(this);filters.setOrientation(LinearLayout.HORIZONTAL);content.addView(filters);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        Runnable refresh=()->{list.removeAllViews();List<Record> rows=db.records(search,rangeStart,rangeEnd);if(rows.isEmpty())list.addView(text("No matching M-PESA records. Enable SMS access and sync your inbox.",14,0xff52647a,false));for(Record r:rows){LinearLayout c=card();c.addView(text(r.title,17,0xff10243e,true));c.addView(text(displayCategory(r.category)+" • "+date(r.timestamp),12,0xff0757a6,true));c.addView(text("Balance: KSh "+(r.balance==null||r.balance.isEmpty()?"—":r.balance),12,0xff52647a,false));c.addView(text(r.body,12,0xff52647a,false));c.setOnClickListener(v->showRecordDetails(r));list.addView(c);}};
        find.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){search=s.toString();refresh.run();}public void afterTextChanged(Editable e){}});
        addRangeFilter(filters,"All",0,Long.MAX_VALUE,refresh);addRangeFilter(filters,"7d",System.currentTimeMillis()-7L*86400000L,Long.MAX_VALUE,refresh);addRangeFilter(filters,"30d",System.currentTimeMillis()-30L*86400000L,Long.MAX_VALUE,refresh);addRangeFilter(filters,"90d",System.currentTimeMillis()-90L*86400000L,Long.MAX_VALUE,refresh);refresh.run();
        syncStatus=text(syncing.get()?"Synchronizing M-PESA history…":"M-PESA data is synchronized",12,0xff52647a,false);content.addView(syncStatus);
        Button sync=button("SYNC M-PESA HISTORY NOW");sync.setOnClickListener(v->syncIfAllowed());content.addView(sync);
    }
    private void showRecordDetails(Record r){String message="Receipt: "+(r.reference==null||r.reference.isEmpty()?"Not detected":r.reference)+"\nCategory: "+displayCategory(r.category)+"\nTransaction amount: KSh "+r.title.replace("KSh ","")+"\nBalance shown in SMS: KSh "+(r.balance==null||r.balance.isEmpty()?"Not provided":r.balance)+"\nSender: "+r.subtitle+"\nDate: "+date(r.timestamp)+"\n\nOriginal message:\n"+r.body;new AlertDialog.Builder(this).setTitle("M-PESA transaction details").setMessage(message).setPositiveButton("Close",null).show();}
    private void addRangeFilter(LinearLayout parent,String label,long start,long end,Runnable refresh){Button b=button(label);b.setTextSize(11);parent.addView(b,new LinearLayout.LayoutParams(0,dp(42),1));b.setOnClickListener(v->{rangeStart=start;rangeEnd=end;refresh.run();});}
    private void renderInsights(){
        content.removeAllViews();content.addView(text("INSIGHTS",22,0xff061b3a,true));content.addView(text("Rolling real-time windows: Daily = last 24h • Weekly = last 7d • Monthly = last 30d • Yearly = last 365/366d. Airtime is spending, not profit.",13,0xff52647a,false));
        LinearLayout periods=new LinearLayout(this);periods.setOrientation(LinearLayout.HORIZONTAL);content.addView(periods);addPeriod(periods,"Daily • 24h","DAILY");addPeriod(periods,"Weekly • 7d","WEEKLY");addPeriod(periods,"Monthly • 30d","MONTHLY");addPeriod(periods,"Yearly • 365/366d","YEARLY");
        long[] bounds=periodBounds(insightPeriod);double[] s=db.summary(bounds[0],bounds[1]);
        LinearLayout live=card();live.addView(text("LIVE • "+insightPeriod,12,0xff0757a6,true));live.addView(text("Received",12,0xff52647a,false));live.addView(text("KSh "+money(s[0]),25,0xff10243e,true));live.addView(text("Money sent + Airtime",12,0xff52647a,false));live.addView(text("KSh "+money(s[1]),25,0xff10243e,true));live.addView(text("Airtime included: KSh "+money(s[2]),12,0xff52647a,false));String sign=s[3]>=0?"+":"-";live.addView(text("Profit/Loss",12,0xff52647a,false));live.addView(text(sign+"KSh "+money(Math.abs(s[3])),30,0xff10243e,true));content.addView(live);
        LinearLayout breakdown=card();breakdown.addView(text("SPENDING VIEW",12,0xff0757a6,true));
        breakdown.addView(text("Window: "+date(bounds[0])+" → "+date(bounds[1]),12,0xff52647a,false));
        breakdown.addView(text("Transactions counted: "+db.countInPeriod(bounds[0],bounds[1]),14,0xff10243e,true));
        breakdown.addView(text("Only transactions whose stored timestamps fall inside this exact rolling window are included. Reversals and unclassified transactions are excluded from money totals.",13,0xff52647a,false));content.addView(breakdown);
    }
    private void addPeriod(LinearLayout p,String label,String value){Button b=button(label);b.setTextSize(10);p.addView(b,new LinearLayout.LayoutParams(0,dp(44),1));b.setOnClickListener(v->{insightPeriod=value;renderInsights();});}
    private String displayCategory(String category){
        if("AIRTIME".equals(category)) return "AIRTIME";
        if("RECEIVED".equals(category)||"DEPOSIT".equals(category)) return "RECEIVED";
        // The M-PESA tab exposes only three public labels. Legacy/other outgoing
        // records are displayed as SENT; reversals remain excluded from Insights
        // by their internal category.
        return "SENT";
    }
    private long[] periodBounds(String p){return InsightPeriods.bounds(p,System.currentTimeMillis());}
    private void renderReports(){
        content.removeAllViews();content.addView(text("REPORTS",22,0xff061b3a,true));LinearLayout a=card();a.addView(text("M-PESA RECORDS",13,0xff0757a6,true));a.addView(text("Total entries: "+db.count(),20,0xff10243e,true));a.addView(text("Captured transaction amounts: KSh "+money(db.sumMpesa()),14,0xff10243e,false));content.addView(a);
        Button m=button("EXPORT ALL M-PESA RECORDS (CSV)");m.setOnClickListener(v->exportCsv());content.addView(m);Button pdf=button("GENERATE PDF SUMMARY");pdf.setOnClickListener(v->{try{share(ExportManager.pdf(this,db),"application/pdf");}catch(Exception e){toast("PDF export failed: "+e.getMessage());}});content.addView(pdf);
    }
    private void exportCsv(){try{share(ExportManager.csv(this,db),"text/csv");}catch(Exception e){toast("CSV export failed: "+e.getMessage());}}
    private void renderSettings(){
        content.removeAllViews();
        content.addView(text("SETTINGS",22,0xff061b3a,true));
        content.addView(text("Control your local data, privacy and SIYOMA experience.",13,0xff52647a,false));

        Button backup=button("BACKUP AND RESTORE");
        backup.setOnClickListener(v->showBackupRestore());
        content.addView(backup);

        Button privacy=button(hasAppPin()?"PRIVACY & APP PIN":"SET APP PIN + RECOVERY EMAIL");
        privacy.setOnClickListener(v->showPrivacy());
        content.addView(privacy);

        if(hasAppPin()){
            Button biometric=button(prefs.getBoolean("biometric_enabled",false)?"FINGERPRINT / BIOMETRIC: ENABLED":"ENABLE FINGERPRINT / BIOMETRIC");
            biometric.setOnClickListener(v->configureBiometric());
            content.addView(biometric);
        }

        Button discover=button("DISCOVER SIYOMA TECH GROUP — WHATSAPP");
        discover.setOnClickListener(v->openWhatsApp());content.addView(discover);
        Button tiktok=button("FOLLOW SIYOMA ON TIKTOK");
        tiktok.setOnClickListener(v->openTikTok());content.addView(tiktok);
        content.addView(text("Follow SIYOMA for app updates, new releases and more SIYOMA TECH DESIGNS content.",12,0xff52647a,false));

        Button dark=button(prefs.getBoolean("dark_mode",false)?"SWITCH TO LIGHT MODE":"SWITCH TO DARK MODE");
        dark.setOnClickListener(v->{boolean on=!prefs.getBoolean("dark_mode",false);prefs.edit().putBoolean("dark_mode",on).apply();AppCompatDelegate.setDefaultNightMode(on?AppCompatDelegate.MODE_NIGHT_YES:AppCompatDelegate.MODE_NIGHT_NO);recreate();});
        content.addView(dark);
        content.addView(text("App name: SIYOMA MPESA TRACKER\nFocus: M-PESA SMS only\nNo call-log access. No SMS replacement. No phone replacement.",13,0xff52647a,false));
    }

    private boolean hasAppPin(){return prefs!=null && prefs.contains("pin_hash") && prefs.contains("pin_salt") && !prefs.getString("recovery_email","").trim().isEmpty();}

    private void showBackupRestore(){new AlertDialog.Builder(this).setTitle("Backup and Restore").setMessage("Create a complete local database backup or restore a previously created SIYOMA MPESA TRACKER backup. Restore validates the SQLite database before replacing the active database.").setNegativeButton("CANCEL",null).setNeutralButton("RESTORE",(d,w)->restoreLauncher.launch(new String[]{"application/octet-stream","application/x-sqlite3","*/*"})).setPositiveButton("BACK UP",(d,w)->backupLauncher.launch("SIYOMA-MPESA-TRACKER-Backup.db")).show();}

    private void showPrivacy(){
        if(!hasAppPin()){ setupPin(); return; }
        String email=prefs.getString("recovery_email","");
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),0);
        EditText e=new EditText(this);e.setSingleLine(true);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);e.setHint("Recovery email address");e.setText(email);form.addView(e);
        new AlertDialog.Builder(this).setTitle("Privacy & PIN settings")
            .setMessage("Your PIN is stored only as a salted hash on this device. The recovery email is saved locally and is required for the Forgotten PIN recovery workflow.")
            .setView(form).setNegativeButton("CANCEL",null)
            .setPositiveButton("SAVE EMAIL",(d,w)->saveRecoveryEmail(e.getText().toString().trim()))
            .setNeutralButton("CHANGE PIN",(d,w)->setupPin()).show();
    }

    private void saveRecoveryEmail(String email){
        email=AppSecurity.normalizeEmail(email);
        if(!AppSecurity.isValidEmail(email)){toast("Enter a valid recovery email address");return;}
        prefs.edit().putString("recovery_email",email).apply();
        toast("Recovery email saved on this device.");
    }

    private void setupPin(){
        LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(18),0,dp(18),0);
        EditText p=new EditText(this);p.setSingleLine(true);p.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);p.setHint("4–8 digit PIN");f.addView(p);
        EditText c=new EditText(this);c.setSingleLine(true);c.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);c.setHint("Confirm PIN");f.addView(c);
        EditText e=new EditText(this);e.setSingleLine(true);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);e.setHint("Required recovery email");e.setText(prefs.getString("recovery_email",""));f.addView(e);
        CheckBox biometric=new CheckBox(this);biometric.setText("Use fingerprint / biometric to open the app");biometric.setChecked(prefs.getBoolean("biometric_enabled",false));f.addView(biometric);
        String title=hasAppPin()?"Change app PIN":"Set app PIN + recovery email";
        new AlertDialog.Builder(this).setTitle(title).setMessage("The recovery email is required. It is stored only on this device and is used when you select FORGOTTEN PIN on the app lock screen.").setView(f).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->savePinAndSecurity(p.getText().toString(),c.getText().toString(),e.getText().toString(),biometric.isChecked())).show();
    }

    private void savePinAndSecurity(String a,String b,String email,boolean biometricRequested){
        email=AppSecurity.normalizeEmail(email);
        if(a.length()<4||a.length()>8||!a.matches("\\d+")){toast("PIN must be 4–8 digits");return;}
        if(!a.equals(b)){toast("PINs do not match");return;}
        if(!AppSecurity.isValidEmail(email)){toast("A valid recovery email is required");return;}
        if(biometricRequested && !biometricAvailable()){
            toast("Fingerprint / biometric is not available or no biometric is enrolled on this device.");
            return;
        }
        String salt=UUID.randomUUID().toString();
        prefs.edit().putString("pin_salt",salt).putString("pin_hash",AppSecurity.hashPin(a,salt)).putString("recovery_email",email).putBoolean("biometric_enabled",biometricRequested).apply();
        toast(biometricRequested?"PIN, recovery email and biometric unlock saved.":"PIN and recovery email saved securely on this device.");
        if(appLocked) showAppLock();
    }

    private boolean biometricAvailable(){
        BiometricManager bm=BiometricManager.from(this);
        return bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)==BiometricManager.BIOMETRIC_SUCCESS;
    }

    private void configureBiometric(){
        if(!hasAppPin()){setupPin();return;}
        if(!biometricAvailable()){
            toast("No enrolled fingerprint / strong biometric is available on this device.");
            return;
        }
        boolean enabled=prefs.getBoolean("biometric_enabled",false);
        prefs.edit().putBoolean("biometric_enabled",!enabled).apply();
        toast(!enabled?"Fingerprint / biometric unlock enabled.":"Fingerprint / biometric unlock disabled. PIN remains available.");
        renderSettings();applySurfaceTheme();
    }

    private void showAppLock(){
        if(!hasAppPin() || isFinishing()) return;
        appLocked=true;
        if(lockOverlay!=null){activityContainer.removeView(lockOverlay);lockOverlay=null;}
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setGravity(android.view.Gravity.CENTER_HORIZONTAL);panel.setPadding(dp(28),dp(36),dp(28),dp(24));
        panel.setBackgroundColor(darkMode()?0xff000000:0xfff4f7fb);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.siyoma_mpesa_call_tracker_logo);logo.setAdjustViewBounds(true);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);panel.addView(logo,new LinearLayout.LayoutParams(-1,dp(130)));
        TextView title=text("SIYOMA MPESA TRACKER",23,darkMode()?0xfff5f7fa:0xff061b3a,true);title.setGravity(android.view.Gravity.CENTER);panel.addView(title);
        TextView sub=text("APP LOCKED",14,darkMode()?0xff73c9ff:0xff0757a6,true);sub.setGravity(android.view.Gravity.CENTER);panel.addView(sub);
        TextView hint=text("Use your PIN or your enrolled fingerprint / biometric.",14,darkMode()?0xffd8dee8:0xff52647a,false);hint.setGravity(android.view.Gravity.CENTER);panel.addView(hint);
        EditText pin=new EditText(this);pin.setSingleLine(true);pin.setGravity(android.view.Gravity.CENTER);pin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);pin.setHint("Enter app PIN");panel.addView(pin,new LinearLayout.LayoutParams(-1,dp(56)));
        Button unlock=button("UNLOCK WITH PIN");unlock.setOnClickListener(v->{if(verifyPin(pin.getText().toString())){pin.setText("");unlockApp();}else{pin.setText("");pin.setError("Incorrect PIN");}});panel.addView(unlock);
        Button forgotten=button("FORGOTTEN PIN");forgotten.setOnClickListener(v->forgottenPinFlow());panel.addView(forgotten);
        if(prefs.getBoolean("biometric_enabled",false)){
            Button bio=button("USE FINGERPRINT / BIOMETRIC");bio.setOnClickListener(v->authenticateBiometric());panel.addView(bio);
        }
        TextView recovery=text("Recovery email is stored locally on this device and is required for PIN recovery.",12,darkMode()?0xff9aa7b8:0xff52647a,false);recovery.setGravity(android.view.Gravity.CENTER);panel.addView(recovery);
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,-1);lp.gravity=android.view.Gravity.FILL;lockOverlay=panel;activityContainer.addView(lockOverlay,lp);
        ViewCompat.setOnApplyWindowInsetsListener(lockOverlay,(v,insets)->{androidx.core.graphics.Insets b=insets.getInsets(WindowInsetsCompat.Type.systemBars());v.setPadding(dp(28)+b.left,dp(36)+b.top,dp(28)+b.right,dp(24)+b.bottom);return insets;});
        ViewCompat.requestApplyInsets(lockOverlay);
        if(prefs.getBoolean("biometric_enabled",false)) new Handler(Looper.getMainLooper()).postDelayed(this::authenticateBiometric,350);
        else pin.requestFocus();
    }

    private boolean verifyPin(String value){
        if(value==null||value.length()==0)return false;
        return AppSecurity.verifyPin(value,prefs.getString("pin_salt",""),prefs.getString("pin_hash",""));
    }

    private void forgottenPinFlow(){
        LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(18),0,dp(18),0);
        EditText e=new EditText(this);e.setSingleLine(true);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);e.setHint("Enter your saved recovery email");f.addView(e);
        new AlertDialog.Builder(this).setTitle("Forgotten PIN").setMessage("Enter the same recovery email you saved in SIYOMA MPESA TRACKER. The email is checked against the value stored locally on this device.").setView(f).setNegativeButton("CANCEL",null).setPositiveButton("RECOVER ACCESS",(d,w)->{
            String entered=AppSecurity.normalizeEmail(e.getText().toString());String saved=AppSecurity.normalizeEmail(prefs.getString("recovery_email",""));
            if(!AppSecurity.isValidEmail(entered)||saved.isEmpty()||!entered.equals(saved)){toast("Recovery email does not match the saved email.");return;}
            toast("Recovery email verified. Access restored. Please change your PIN in Settings.");unlockApp();
        }).show();
    }

    private void authenticateBiometric(){
        if(!appLocked||authenticationInProgress)return;
        if(!biometricAvailable()){toast("Fingerprint / biometric is unavailable. Enter your PIN instead.");return;}
        authenticationInProgress=true;
        BiometricPrompt.AuthenticationCallback callback=new BiometricPrompt.AuthenticationCallback(){
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result){authenticationInProgress=false;runOnUiThread(()->unlockApp());}
            @Override public void onAuthenticationFailed(){authenticationInProgress=false;}
            @Override public void onAuthenticationError(int errorCode,CharSequence errString){authenticationInProgress=false;}
        };
        BiometricPrompt prompt=new BiometricPrompt(this,ContextCompat.getMainExecutor(this),callback);
        BiometricPrompt.PromptInfo info=new BiometricPrompt.PromptInfo.Builder().setTitle("Unlock SIYOMA MPESA TRACKER").setSubtitle("Use your enrolled fingerprint / biometric").setNegativeButtonText("USE APP PIN").setConfirmationRequired(false).build();
        prompt.authenticate(info);
    }

    private void unlockApp(){
        appLocked=false;
        authenticationInProgress=false;
        if(lockOverlay!=null){activityContainer.removeView(lockOverlay);lockOverlay=null;}
        show(page);
        updateBottomNavigationState();
    }

    private void openWhatsApp(){String number="254713622247";
        String msg="Hello SIYOMA Tech Group 👋, I am using SIYOMA MPESA TRACKER and would like to connect with SIYOMA TECH DESIGNS. Please share the latest SIYOMA updates with me.";Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+number+"?text="+Uri.encode(msg)));try{startActivity(i);}catch(Exception e){toast("WhatsApp is not available on this device.");}}
    private void openTikTok(){Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://vm.tiktok.com/ZS9fbYh6U7BGx-KdP3c/"));try{startActivity(i);}catch(Exception e){toast("Could not open TikTok.");}}
    private void share(File f,String type){Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_STREAM,FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(Intent.createChooser(i,"Share SIYOMA export"));}catch(Exception e){toast("Could not open sharing app");}}
    private void writeBackup(Uri uri){File source=getDatabasePath("siyoma_mpesa_tracker.db");try{db.getWritableDatabase().execSQL("PRAGMA wal_checkpoint(TRUNCATE)");db.close();try(InputStream in=new FileInputStream(source);OutputStream out=getContentResolver().openOutputStream(uri,"w")){if(out==null)throw new IllegalStateException("Destination unavailable");byte[] b=new byte[16384];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();}toast("Database backup created successfully.");}catch(Exception e){toast("Backup failed: "+e.getMessage());}finally{db=new TrackerDb(this);}}
    private void restoreBackup(Uri uri){File tmp=new File(getCacheDir(),"siyoma-restore.db");File target=getDatabasePath("siyoma_mpesa_tracker.db");File staged=new File(target.getParent(),"siyoma_mpesa_tracker.restore.db");File previous=new File(target.getParent(),"siyoma_mpesa_tracker.previous.db");try{try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(tmp)){if(in==null)throw new IllegalStateException("Backup unavailable");byte[] b=new byte[16384];int n;while((n=in.read(b))>0)out.write(b,0,n);}android.database.sqlite.SQLiteDatabase check=android.database.sqlite.SQLiteDatabase.openDatabase(tmp.getPath(),null,android.database.sqlite.SQLiteDatabase.OPEN_READONLY);boolean valid=false;try(android.database.Cursor c=check.rawQuery("PRAGMA integrity_check",null)){valid=c.moveToFirst()&&"ok".equalsIgnoreCase(c.getString(0));}if(valid){try(android.database.Cursor c=check.rawQuery("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='mpesa'",null)){valid=c.moveToFirst()&&c.getInt(0)==1;}}check.close();if(!valid)throw new IllegalArgumentException("Invalid SIYOMA MPESA TRACKER backup");copyFile(tmp,staged);db.getWritableDatabase().execSQL("PRAGMA wal_checkpoint(TRUNCATE)");db.close();File wal=new File(target+"-wal"),shm=new File(target+"-shm");if(wal.exists())wal.delete();if(shm.exists())shm.delete();if(previous.exists())previous.delete();if(target.exists()&&!target.renameTo(previous))throw new IllegalStateException("Could not safeguard current database");if(!staged.renameTo(target)){if(previous.exists())previous.renameTo(target);throw new IllegalStateException("Could not install restored database");}if(previous.exists())previous.delete();db=new TrackerDb(this);db.getReadableDatabase();show("HOME");toast("Backup restored successfully.");}catch(Exception e){if(db==null)db=new TrackerDb(this);toast("Restore failed: "+e.getMessage());}finally{tmp.delete();staged.delete();}}
    private void copyFile(File from,File to)throws Exception{try(InputStream in=new FileInputStream(from);OutputStream out=new FileOutputStream(to)){byte[] b=new byte[16384];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();}}
    private String date(long t){return new SimpleDateFormat("dd MMM yyyy, HH:mm",Locale.getDefault()).format(new Date(t));}
    private String money(double v){return String.format(Locale.US,"%,.2f",v);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){handler.removeCallbacks(liveTicker);if(db!=null)db.close();super.onDestroy();}
}
