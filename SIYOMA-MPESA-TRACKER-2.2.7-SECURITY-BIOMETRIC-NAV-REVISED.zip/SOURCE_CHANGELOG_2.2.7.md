# SIYOMA MPESA TRACKER 2.2.7 — App Lock, Recovery Email, Biometric + Navigation UI Revision

## Security / App Access
- Setting an app PIN now requires a valid recovery email in the same setup flow.
- The recovery email is normalized and stored locally in the app's private SharedPreferences.
- After a PIN has been configured, subsequent app launches show an app lock screen.
- `FORGOTTEN PIN` accepts the saved recovery email and restores access when it exactly matches the locally saved value.
- The PIN remains stored as a salted SHA-256 hash; the plaintext PIN is never saved.
- Fingerprint / strong biometric unlock can be enabled during PIN setup or later from Settings.
- When biometric unlock is enabled, the app offers biometric authentication on launch.
- If biometric authentication fails, is unavailable, or is cancelled, the app PIN remains available.
- The biometric implementation uses AndroidX `BiometricPrompt` and requests `BIOMETRIC_STRONG`; the actual supported modality is selected by the device (for example fingerprint or another strong biometric).

## Navigation / UI
- Reworked the five bottom tabs: HOME, MPESA, INSIGHTS, REPORTS, SETTINGS.
- Added explicit selected-tab styling so the active tab is visually clear.
- Preserved click listeners for all five tabs.
- Preserved and strengthened system-navigation insets handling so Android's own navigation controls do not obscure or intercept the app's bottom buttons.
- Increased the navigation target height and improved text sizing/alignment for small Android screens.

## Version
- `versionCode`: 11
- `versionName`: 2.2.7
