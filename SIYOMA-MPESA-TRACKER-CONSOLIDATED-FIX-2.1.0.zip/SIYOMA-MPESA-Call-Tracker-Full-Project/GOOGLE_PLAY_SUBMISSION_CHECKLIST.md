# Google Play submission checklist — SIYOMA M-PESA & Call Tracker

## Before submission
- Publish only after the SMS permissions declaration has been reviewed and approved.
- In Play Console, declare `READ_SMS` and `RECEIVE_SMS` under the SMS-based money-management use case. Explain that the app parses M-PESA transaction notifications for the user's personal budget/transaction history.
- Provide a reviewer video showing the disclosure, explicit consent, M-PESA inbox import, and live M-PESA transaction capture. Use test data and redact personal information.
- Provide a public privacy-policy URL and complete the Data safety form accurately.
- Ensure store listing describes SMS-based M-PESA money management as the app's core feature.
- Do not request call-log or phone-state permissions. Call activity is user-entered only.
- Do not distribute the SMS-enabled APK from a website, file host, messaging app, or GitHub release as the normal installation route. Play Protect may block internet-sideloaded apps with sensitive SMS permissions.
- Submit a Play Protect appeal only if Google continues to classify a policy-compliant, reviewed build incorrectly.

## Important
A permission declaration is a request, not approval. Google Play decides eligibility. This project does not bypass Play Protect or guarantee approval.
