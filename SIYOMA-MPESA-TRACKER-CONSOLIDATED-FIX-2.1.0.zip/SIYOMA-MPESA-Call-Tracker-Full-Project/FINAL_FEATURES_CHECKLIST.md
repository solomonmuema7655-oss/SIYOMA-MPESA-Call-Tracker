# Final feature checklist

Implemented in source:
- App name: SIYOMA MPESA TRACKER
- Existing SIYOMA logo reused with only the title text changed to MPESA TRACKER
- M-PESA SMS only
- No call-log permission
- Home
- M-PESA
- Insights (Daily/Weekly/Monthly/Yearly)
- Reports
- Settings
- Real-time dashboard clock and live daily money flow
- Received / Money sent + Airtime / Profit-Loss
- Airtime included in spending/outgoing calculation
- Latest captured M-PESA balance
- Search and date filters
- CSV and PDF reports
- Backup and restore with SQLite validation
- App PIN salted hash
- Recovery email storage and recovery workflow disclosure
- Dark/Light mode
- WhatsApp entry point reserved for the official SIYOMA Tech Group number

Important release gate:
The official WhatsApp number must be configured before public release. Android compilation and physical-device testing remain required acceptance gates.


## SIYOMA community links
- Official SIYOMA Tech Group WhatsApp: +254 713 622 247.
- SIYOMA TikTok follow link: https://vm.tiktok.com/ZS9fbYh6U7BGx-KdP3c/
- The Settings screen provides buttons for both WhatsApp and TikTok.
