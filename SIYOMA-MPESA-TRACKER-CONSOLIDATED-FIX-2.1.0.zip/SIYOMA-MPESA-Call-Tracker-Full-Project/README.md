# SIYOMA MPESA TRACKER

Production-oriented Android source project focused exclusively on M-PESA SMS transaction tracking and local money-flow analysis.

## Tabs
- Home — live dashboard, current M-PESA balance when available, today's received/sent/airtime/net flow.
- MPESA — searchable transaction history and details.
- Insights — Daily, Weekly, Monthly and Yearly real-time received, money sent + airtime, airtime subtotal and Profit/Loss.
- Reports — CSV/PDF exports.
- Settings — Backup & Restore, Privacy/App PIN and recovery email workflow, SIYOMA Tech Group WhatsApp entry, Dark/Light mode.

The app does not replace the user's SMS or Phone app and does not request call-log access.

### Privacy note
The app PIN is stored as a salted SHA-256 hash. The recovery email is stored locally. A true server-side email verification/recovery service requires a backend; this source deliberately does not embed email credentials or a secret server key.

### Google Play
SMS permissions remain subject to Google Play's restricted-permission policy and approval.


## SIYOMA community links
- Official SIYOMA Tech Group WhatsApp: +254 713 622 247.
- SIYOMA TikTok follow link: https://vm.tiktok.com/ZS9fbYh6U7BGx-KdP3c/
- The Settings screen provides buttons for both WhatsApp and TikTok.
