# SIYOMA MPESA TRACKER — Complete redesign pass

- Renamed app to SIYOMA MPESA TRACKER.
- Modified the existing logo text only: bottom title now reads MPESA TRACKER; core SIYOMA, Kenyan flag, phone, M-PESA and graphical elements remain.
- M-PESA SMS only: removed call-tracking UI and call-log/phone-state permissions.
- Replaced Calls tab with Insights.
- Insights periods: Daily, Weekly, Monthly, Yearly.
- Real-time money flow: Received; Money sent + Airtime; Airtime subtotal; Profit/Loss.
- Airtime is included in money sent/spending.
- Home dashboard now shows live clock and today's money flow plus latest captured M-PESA balance when available.
- Added Settings: Backup/Restore, Privacy/App PIN/recovery email workflow, SIYOMA Tech Group WhatsApp entry, Dark/Light mode.
- Database upgraded to M-PESA-only schema.
- Removed obsolete call records on database upgrade.


## SIYOMA community links
- Official SIYOMA Tech Group WhatsApp: +254 713 622 247.
- SIYOMA TikTok follow link: https://vm.tiktok.com/ZS9fbYh6U7BGx-KdP3c/
- The Settings screen provides buttons for both WhatsApp and TikTok.
