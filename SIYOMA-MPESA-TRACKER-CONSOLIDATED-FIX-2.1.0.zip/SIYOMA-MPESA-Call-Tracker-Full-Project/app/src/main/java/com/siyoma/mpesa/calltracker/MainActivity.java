package com.siyoma.mpesa.calltracker;

import android.Manifest;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends AppCompatActivity {
    public static final String ACTION_MONEY_DATA_CHANGED="com.siyoma.mpesa.calltracker.MONEY_DATA_CHANGED";
    private LinearLayout content;
    private TextView balanceSummary;
    private boolean dataReceiverRegistered=false;
    private final BroadcastReceiver moneyDataReceiver=new BroadcastReceiver(){
        @Override public void onReceive(android.content.Context context,Intent intent){
            runOnUiThread(()->{
                if(page.equals("HOME")) updateHomeLive();
                else if(page.equals("MPESA")) renderMpesa();
                else if(page.equals("INSIGHTS")) renderInsights();
                else if(page.equals("REPORTS")) renderReports();
            });
        }
    };
    private TrackerDb db;
    private String page="HOME", search="";
    private TextView liveClock, liveSummary, syncStatus;
    private long rangeStart=0L, rangeEnd=Long.MAX_VALUE;
    private String insightPeriod="DAILY";
    private final AtomicBoolean syncing=new AtomicBoolean(false);
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final String[] perms={Manifest.permission.READ_SMS,Manifest.permission.RECEIVE_SMS};
    private ActivityResultLauncher<String[]> permissionLauncher;
    private ActivityResultLauncher<String> backupLauncher;
    private ActivityResultLauncher<String[]> restoreLauncher;
    private SharedPreferences prefs;
    private final Runnable liveTicker = new Runnable() {
        @Override public void run() {
            updateLiveClock();
            if(page.equals("HOME") || page.equals("INSIGHTS")) {
                if(page.equals("HOME")) updateHomeLive(); else renderInsights();
            }
            handler.postDelayed(this,5000);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("siyoma_settings",MODE_PRIVATE);
        AppCompatDelegate.setDefaultNightMode(prefs.getBoolean("dark_mode",false)?AppCompatDelegate.MODE_NIGHT_YES:AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(R.layout.activity_main);
        content=findViewById(R.id.content); db=new TrackerDb(this);
        applySurfaceTheme();
        permissionLauncher=registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> { renderHome(); syncIfAllowed(); });
        backupLauncher=registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"), uri -> { if(uri!=null) writeBackup(uri); });
        restoreLauncher=registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> { if(uri!=null) restoreBackup(uri); });
        findViewById(R.id.nav_home).setOnClickListener(v->show("HOME"));
        findViewById(R.id.nav_mpesa).setOnClickListener(v->show("MPESA"));
        findViewById(R.id.nav_insights).setOnClickListener(v->show("INSIGHTS"));
        findViewById(R.id.nav_reports).setOnClickListener(v->show("REPORTS"));
        findViewById(R.id.nav_settings).setOnClickListener(v->show("SETTINGS"));
        show("HOME");
        if((!has(Manifest.permission.READ_SMS)||!has(Manifest.permission.RECEIVE_SMS)) && !prefs.getBoolean("sms_disclosure_shown",false)) {
            prefs.edit().putBoolean("sms_disclosure_shown",true).apply(); showSmsDisclosure();
        }
    }
    @Override protected void onResume(){super.onResume();
        if(!dataReceiverRegistered){ContextCompat.registerReceiver(this,moneyDataReceiver,new IntentFilter(ACTION_MONEY_DATA_CHANGED),ContextCompat.RECEIVER_NOT_EXPORTED);dataReceiverRegistered=true;}
        handler.removeCallbacks(liveTicker); handler.post(liveTicker); if(db!=null) syncIfAllowed();
    }
    @Override protected void onPause(){super.onPause();handler.removeCallbacks(liveTicker);if(dataReceiverRegistered){unregisterReceiver(moneyDataReceiver);dataReceiverRegistered=false;}}
    private boolean has(String p){return ContextCompat.checkSelfPermission(this,p)==PackageManager.PERMISSION_GRANTED;}
    private void syncIfAllowed(){
        if(!has(Manifest.permission.READ_SMS)){return;}
        if(syncing.get()){
            if(syncStatus!=null) syncStatus.setText("Synchronizing M-PESA history…");
            return;
        }
        if(!syncing.compareAndSet(false,true)) return;
        if(syncStatus!=null) syncStatus.setText("Synchronizing M-PESA history…");
        new Thread(()->{
            int inserted=0; String status;
            try {
                inserted=SyncEngine.syncMpesa(this);
                status=inserted>0 ? "M-PESA data synchronized • "+inserted+" new transaction"+(inserted==1?"":"s") : "Already synchronized to real-time M-PESA data";
            } catch(Exception e){
                status="Synchronization paused: "+(e.getMessage()==null?"permission or SMS provider issue":e.getMessage());
            } finally { syncing.set(false); }
            final String finalStatus=status;
            runOnUiThread(()->{
                if(syncStatus!=null) syncStatus.setText(finalStatus);
                if(page.equals("HOME")) updateHomeLive();
                else if(page.equals("MPESA")) renderMpesa();
                else if(page.equals("INSIGHTS")) renderInsights();
                else if(page.equals("REPORTS")) renderReports();
            });
        },"SIYOMA-mpesa-sync").start();
    }
    private void show(String p){page=p;search="";rangeStart=0;rangeEnd=Long.MAX_VALUE;if(p.equals("HOME"))renderHome();else if(p.equals("MPESA"))renderMpesa();else if(p.equals("INSIGHTS"))renderInsights();else if(p.equals("REPORTS"))renderReports();else renderSettings();applySurfaceTheme();}
    private boolean darkMode(){return prefs!=null && prefs.getBoolean("dark_mode",false);}
    private int themedTextColor(int original){
        if(!darkMode()) return original;
        if(original==Color.WHITE || original==0xffffffff || original==0xffe7f2ff) return original;
        if(original==0xff0757a6 || original==0xff061b3a) return 0xff73c9ff;
        if(original==0xff52647a || original==0xff10243e) return 0xffe2e8f0;
        return original;
    }
    private void applySurfaceTheme(){
        int bg=darkMode()?0xff000000:0xfff4f7fb;
        View appRoot=findViewById(android.R.id.content); if(appRoot!=null) appRoot.setBackgroundColor(bg);
        View root=findViewById(R.id.scroll); if(root!=null) root.setBackgroundColor(bg);
        View nav=findViewById(R.id.navigation); if(nav!=null) nav.setBackgroundColor(darkMode()?0xff050505:0xff061b3a);
        if(content!=null) content.setBackgroundColor(bg);
        getWindow().setStatusBarColor(darkMode()?0xff000000:0xff061b3a);
        getWindow().setNavigationBarColor(darkMode()?0xff000000:0xff061b3a);
        getWindow().getDecorView().setSystemUiVisibility(darkMode()?0:0);
        if(content!=null){
            for(int i=0;i<content.getChildCount();i++) themeView(content.getChildAt(i));
        }
    }
    private void themeView(View v){
        if(v instanceof EditText){
            EditText e=(EditText)v; e.setTextColor(darkMode()?0xfff5f7fa:0xff10243e); e.setHintTextColor(darkMode()?0xff9aa7b8:0xff6b7280);
            e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(darkMode()?0xff73c9ff:0xff0757a6));
        } else if(v instanceof Button){
            Button b=(Button)v; b.setTextColor(darkMode()?0xfff5f7fa:0xff061b3a);
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(darkMode()?0xff172235:0xffffffff));
        }
        if(v instanceof android.view.ViewGroup){
            android.view.ViewGroup g=(android.view.ViewGroup)v; for(int i=0;i<g.getChildCount();i++) themeView(g.getChildAt(i));
        }
    }
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(themedTextColor(color));if(bold)t.setTypeface(null,1);t.setPadding(0,dp(6),0,dp(6));return t;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private LinearLayout card(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(dp(16),dp(12),dp(16),dp(12));
        if(darkMode()){GradientDrawable shape=new GradientDrawable();shape.setColor(0xff111111);shape.setCornerRadius(dp(18));shape.setStroke(dp(1),0xff27303a);x.setBackground(shape);}else x.setBackgroundResource(R.drawable.bg_card);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(7),0,dp(7));x.setLayoutParams(lp);return x;}
    private Button button(String label){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(darkMode()?0xfff5f7fa:0xff061b3a);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(darkMode()?0xff172235:0xffffffff));return b;}
    private void renderHome(){
        content.removeAllViews();
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.siyoma_mpesa_call_tracker_logo);logo.setAdjustViewBounds(true);logo.setMaxHeight(dp(210));logo.setScaleType(ImageView.ScaleType.FIT_CENTER);content.addView(logo,new LinearLayout.LayoutParams(-1,dp(190)));
        LinearLayout head=card();
        if(darkMode()){GradientDrawable hd=new GradientDrawable();hd.setColor(0xff050505);hd.setCornerRadius(dp(22));hd.setStroke(dp(1),0xff27303a);head.setBackground(hd);}else head.setBackgroundResource(R.drawable.bg_header);
        head.addView(text("SIYOMA MPESA TRACKER",20,0xffffffff,true));liveClock=text("LIVE • --:--:-- EAT",13,0xffe7f2ff,true);head.addView(liveClock);head.addView(text("Real-time M-PESA money-management overview from captured M-PESA SMS.",13,0xffe7f2ff,false));content.addView(head);
        LinearLayout live=card();live.addView(text("LIVE MONEY FLOW — TODAY",12,0xff0757a6,true));liveSummary=text("Loading…",14,0xff10243e,true);live.addView(liveSummary);content.addView(live);
        LinearLayout balance=card();balance.addView(text("LATEST M-PESA BALANCE",12,0xff0757a6,true));double bal=db.latestBalance();balanceSummary=text(Double.isNaN(bal)?"Not available":"KSh "+money(bal),28,0xff10243e,true);balance.addView(balanceSummary);balance.addView(text("Taken from the most recent captured M-PESA SMS that contains a balance.",12,0xff52647a,false));content.addView(balance);
        LinearLayout access=card();access.addView(text("M-PESA SMS ACCESS",12,0xff0757a6,true));access.addView(text(has(Manifest.permission.READ_SMS)&&has(Manifest.permission.RECEIVE_SMS)?"Enabled":"Permission needed",13,0xff10243e,false));content.addView(access);
        LinearLayout stats=card();stats.addView(text("TRACKED M-PESA SMS",12,0xff0757a6,true));stats.addView(text(String.valueOf(db.count()),30,0xff10243e,true));stats.addView(text("Transactions stored locally on this device.",13,0xff10243e,false));content.addView(stats);
        syncStatus=text(syncing.get()?"Synchronizing M-PESA history…":"M-PESA data is synchronized",12,0xff52647a,false);content.addView(syncStatus);
        Button sync=button("SYNC M-PESA HISTORY NOW");sync.setOnClickListener(v->{if(!has(Manifest.permission.READ_SMS)||!has(Manifest.permission.RECEIVE_SMS))showSmsDisclosure();else syncIfAllowed();});content.addView(sync);
        Button insights=button("OPEN MONEY INSIGHTS");insights.setOnClickListener(v->show("INSIGHTS"));content.addView(insights);
        content.addView(text("SIYOMA does not replace your SMS app, read call logs, record calls, or place calls. This app is focused exclusively on M-PESA SMS transaction tracking and money-flow analysis.",12,0xff52647a,false));
        updateLiveClock();updateHomeLive();
    }
    private void updateLiveClock(){if(liveClock!=null){liveClock.setText("LIVE • "+new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date())+" EAT");}}
    private void updateHomeLive(){if(db==null)return;
        if(balanceSummary!=null){double bal=db.latestBalance();balanceSummary.setText(Double.isNaN(bal)?"Not available":"KSh "+money(bal));}
        if(liveSummary!=null){long[] r=periodBounds("DAILY");double[] s=db.summary(r[0],r[1]);liveSummary.setText("Received: KSh "+money(s[0])+"\nSent + Airtime: KSh "+money(s[1])+"\nProfit/Loss: "+(s[3]>=0?"+":"-")+"KSh "+money(Math.abs(s[3])));}
    }
    private void showSmsDisclosure(){new AlertDialog.Builder(this).setTitle("M-PESA SMS access").setMessage("SIYOMA MPESA TRACKER uses SMS access only to identify and store M-PESA transaction messages for your personal money-management records. It does not send SMS, replace your SMS app, read call logs, or share your message content for advertising. Captured data is stored locally on this device. You can decline, but automatic M-PESA capture and inbox import will remain unavailable. Google Play approval is required before public distribution with these permissions.").setNegativeButton("NOT NOW",null).setPositiveButton("I AGREE — CONTINUE",(d,w)->permissionLauncher.launch(perms)).show();}
    private void renderMpesa(){
        content.removeAllViews();content.addView(text("M-PESA",22,0xff061b3a,true));content.addView(text("Live M-PESA SMS history and transaction details.",13,0xff52647a,false));
        EditText find=new EditText(this);find.setSingleLine(true);find.setHint("Search receipt, category, sender or SMS text");content.addView(find);
        LinearLayout filters=new LinearLayout(this);filters.setOrientation(LinearLayout.HORIZONTAL);content.addView(filters);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        Runnable refresh=()->{list.removeAllViews();List<Record> rows=db.records(search,rangeStart,rangeEnd);if(rows.isEmpty())list.addView(text("No matching M-PESA records. Enable SMS access and sync your inbox.",14,0xff52647a,false));for(Record r:rows){LinearLayout c=card();c.addView(text(r.title,17,0xff10243e,true));c.addView(text((r.category==null?"":r.category)+" • "+date(r.timestamp),12,0xff0757a6,true));c.addView(text("Balance: KSh "+(r.amount==null||r.amount.isEmpty()?"—":r.amount),12,0xff52647a,false));c.addView(text(r.body,12,0xff52647a,false));c.setOnClickListener(v->showRecordDetails(r));list.addView(c);}};
        find.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){search=s.toString();refresh.run();}public void afterTextChanged(Editable e){}});
        addRangeFilter(filters,"All",0,Long.MAX_VALUE,refresh);addRangeFilter(filters,"7d",System.currentTimeMillis()-7L*86400000L,Long.MAX_VALUE,refresh);addRangeFilter(filters,"30d",System.currentTimeMillis()-30L*86400000L,Long.MAX_VALUE,refresh);addRangeFilter(filters,"90d",System.currentTimeMillis()-90L*86400000L,Long.MAX_VALUE,refresh);refresh.run();
        syncStatus=text(syncing.get()?"Synchronizing M-PESA history…":"M-PESA data is synchronized",12,0xff52647a,false);content.addView(syncStatus);
        Button sync=button("SYNC M-PESA HISTORY NOW");sync.setOnClickListener(v->syncIfAllowed());content.addView(sync);
    }
    private void showRecordDetails(Record r){String message="Receipt: "+(r.reference==null||r.reference.isEmpty()?"Not detected":r.reference)+"\nCategory: "+r.category+"\nTransaction amount: KSh "+r.title.replace("KSh ","")+"\nBalance shown in SMS: KSh "+(r.amount==null||r.amount.isEmpty()?"Not provided":r.amount)+"\nSender: "+r.subtitle+"\nDate: "+date(r.timestamp)+"\n\nOriginal message:\n"+r.body;new AlertDialog.Builder(this).setTitle("M-PESA transaction details").setMessage(message).setPositiveButton("Close",null).show();}
    private void addRangeFilter(LinearLayout parent,String label,long start,long end,Runnable refresh){Button b=button(label);b.setTextSize(11);parent.addView(b,new LinearLayout.LayoutParams(0,dp(42),1));b.setOnClickListener(v->{rangeStart=start;rangeEnd=end;refresh.run();});}
    private void renderInsights(){
        content.removeAllViews();content.addView(text("INSIGHTS",22,0xff061b3a,true));content.addView(text("Real-time spending, money received and net profit/loss. Airtime is included in money sent/spending because it is not profit.",13,0xff52647a,false));
        LinearLayout periods=new LinearLayout(this);periods.setOrientation(LinearLayout.HORIZONTAL);content.addView(periods);addPeriod(periods,"Daily","DAILY");addPeriod(periods,"Weekly","WEEKLY");addPeriod(periods,"Monthly","MONTHLY");addPeriod(periods,"Yearly","YEARLY");
        long[] bounds=periodBounds(insightPeriod);double[] s=db.summary(bounds[0],bounds[1]);
        LinearLayout live=card();live.addView(text("LIVE • "+insightPeriod,12,0xff0757a6,true));live.addView(text("Received",12,0xff52647a,false));live.addView(text("KSh "+money(s[0]),25,0xff10243e,true));live.addView(text("Money sent + Airtime",12,0xff52647a,false));live.addView(text("KSh "+money(s[1]),25,0xff10243e,true));live.addView(text("Airtime included: KSh "+money(s[2]),12,0xff52647a,false));String sign=s[3]>=0?"+":"-";live.addView(text("Profit/Loss",12,0xff52647a,false));live.addView(text(sign+"KSh "+money(Math.abs(s[3])),30,0xff10243e,true));content.addView(live);
        LinearLayout breakdown=card();breakdown.addView(text("SPENDING VIEW",12,0xff0757a6,true));breakdown.addView(text("The period total is calculated directly from captured M-PESA SMS categories. Reversals and unclassified transactions are not counted as profit or spending.",13,0xff52647a,false));content.addView(breakdown);
    }
    private void addPeriod(LinearLayout p,String label,String value){Button b=button(label);b.setTextSize(10);p.addView(b,new LinearLayout.LayoutParams(0,dp(44),1));b.setOnClickListener(v->{insightPeriod=value;renderInsights();});}
    private long[] periodBounds(String p){Calendar end=Calendar.getInstance();end.add(Calendar.MILLISECOND,1);Calendar start=(Calendar)end.clone();if("DAILY".equals(p)){start.set(Calendar.HOUR_OF_DAY,0);start.set(Calendar.MINUTE,0);start.set(Calendar.SECOND,0);start.set(Calendar.MILLISECOND,0);}else if("WEEKLY".equals(p)){start.set(Calendar.DAY_OF_WEEK,start.getFirstDayOfWeek());start.set(Calendar.HOUR_OF_DAY,0);start.set(Calendar.MINUTE,0);start.set(Calendar.SECOND,0);start.set(Calendar.MILLISECOND,0);}else if("MONTHLY".equals(p)){start.set(Calendar.DAY_OF_MONTH,1);start.set(Calendar.HOUR_OF_DAY,0);start.set(Calendar.MINUTE,0);start.set(Calendar.SECOND,0);start.set(Calendar.MILLISECOND,0);}else{start.set(Calendar.DAY_OF_YEAR,1);start.set(Calendar.HOUR_OF_DAY,0);start.set(Calendar.MINUTE,0);start.set(Calendar.SECOND,0);start.set(Calendar.MILLISECOND,0);}return new long[]{start.getTimeInMillis(),end.getTimeInMillis()};}
    private void renderReports(){
        content.removeAllViews();content.addView(text("REPORTS",22,0xff061b3a,true));LinearLayout a=card();a.addView(text("M-PESA RECORDS",13,0xff0757a6,true));a.addView(text("Total entries: "+db.count(),20,0xff10243e,true));a.addView(text("Captured transaction amounts: KSh "+money(db.sumMpesa()),14,0xff10243e,false));content.addView(a);
        Button m=button("EXPORT ALL M-PESA RECORDS (CSV)");m.setOnClickListener(v->exportCsv());content.addView(m);Button pdf=button("GENERATE PDF SUMMARY");pdf.setOnClickListener(v->{try{share(ExportManager.pdf(this,db),"application/pdf");}catch(Exception e){toast("PDF export failed: "+e.getMessage());}});content.addView(pdf);
    }
    private void exportCsv(){try{share(ExportManager.csv(this,db),"text/csv");}catch(Exception e){toast("CSV export failed: "+e.getMessage());}}
    private void renderSettings(){
        content.removeAllViews();content.addView(text("SETTINGS",22,0xff061b3a,true));content.addView(text("Control your local data, privacy and SIYOMA experience.",13,0xff52647a,false));
        Button backup=button("BACKUP AND RESTORE");backup.setOnClickListener(v->showBackupRestore());content.addView(backup);
        Button privacy=button("PRIVACY & APP PIN");privacy.setOnClickListener(v->showPrivacy());content.addView(privacy);
        Button discover=button("DISCOVER SIYOMA TECH GROUP — WHATSAPP");discover.setOnClickListener(v->openWhatsApp());content.addView(discover);
        Button tiktok=button("FOLLOW SIYOMA ON TIKTOK");tiktok.setOnClickListener(v->openTikTok());content.addView(tiktok);
        content.addView(text("Follow SIYOMA for app updates, new releases and more SIYOMA TECH DESIGNS content.",12,0xff52647a,false));
        Button dark=button(prefs.getBoolean("dark_mode",false)?"SWITCH TO LIGHT MODE":"SWITCH TO DARK MODE");dark.setOnClickListener(v->{boolean on=!prefs.getBoolean("dark_mode",false);prefs.edit().putBoolean("dark_mode",on).apply();AppCompatDelegate.setDefaultNightMode(on?AppCompatDelegate.MODE_NIGHT_YES:AppCompatDelegate.MODE_NIGHT_NO);recreate();});content.addView(dark);
        content.addView(text("App name: SIYOMA MPESA TRACKER\nFocus: M-PESA SMS only\nNo call-log access. No SMS replacement. No phone replacement.",13,0xff52647a,false));
    }
    private void showBackupRestore(){new AlertDialog.Builder(this).setTitle("Backup and Restore").setMessage("Create a complete local database backup or restore a previously created SIYOMA MPESA TRACKER backup. Restore validates the SQLite database before replacing the active database.").setNegativeButton("CANCEL",null).setNeutralButton("RESTORE",(d,w)->restoreLauncher.launch(new String[]{"application/octet-stream","application/x-sqlite3","*/*"})).setPositiveButton("BACK UP",(d,w)->backupLauncher.launch("SIYOMA-MPESA-TRACKER-Backup.db")).show();}
    private void showPrivacy(){
        String email=prefs.getString("recovery_email","");boolean pinSet=prefs.contains("pin_hash");
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(18),dp(8),dp(18),0);
        EditText e=new EditText(this);e.setSingleLine(true);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);e.setHint("Recovery email address");e.setText(email);form.addView(e);
        new AlertDialog.Builder(this).setTitle(pinSet?"Privacy & PIN settings":"Protect the app with a PIN").setMessage("Your PIN is stored only as a salted hash on this device. The recovery email is stored locally and is used for your recovery workflow. For a true server-side email verification/recovery service, SIYOMA will need an approved backend; this build does not send or store your email password.").setView(form).setNegativeButton("CANCEL",null).setPositiveButton("SAVE EMAIL",(d,w)->saveRecoveryEmail(e.getText().toString().trim())).setNeutralButton(pinSet?"CHANGE PIN":"SET PIN",(d,w)->setupPin()).show();
    }
    private void saveRecoveryEmail(String email){if(!email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")){toast("Enter a valid email address");return;}prefs.edit().putString("recovery_email",email).apply();toast("Recovery email saved on this device.");}
    private void setupPin(){LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(18),0,dp(18),0);EditText p=new EditText(this);p.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);p.setHint("4–8 digit PIN");f.addView(p);EditText c=new EditText(this);c.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);c.setHint("Confirm PIN");f.addView(c);new AlertDialog.Builder(this).setTitle("Set app PIN").setView(f).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->{String a=p.getText().toString(),b=c.getText().toString();if(a.length()<4||a.length()>8||!a.matches("\\d+")){toast("PIN must be 4–8 digits");return;}if(!a.equals(b)){toast("PINs do not match");return;}String salt=UUID.randomUUID().toString();prefs.edit().putString("pin_salt",salt).putString("pin_hash",hash(a,salt)).apply();toast("App PIN saved securely on this device.");}).show();}
    private String hash(String value,String salt){try{MessageDigest md=MessageDigest.getInstance("SHA-256");byte[] b=md.digest((salt+":"+value).getBytes(StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.ROOT,"%02x",x));return s.toString();}catch(Exception e){throw new IllegalStateException(e);}}
    private void openWhatsApp(){String number="254713622247";
        String msg="Hello SIYOMA Tech Group 👋, I am using SIYOMA MPESA TRACKER and would like to connect with SIYOMA TECH DESIGNS. Please share the latest SIYOMA updates with me.";Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+number+"?text="+Uri.encode(msg)));try{startActivity(i);}catch(Exception e){toast("WhatsApp is not available on this device.");}}
    private void openTikTok(){Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://vm.tiktok.com/ZS9fbYh6U7BGx-KdP3c/"));try{startActivity(i);}catch(Exception e){toast("Could not open TikTok.");}}
    private void share(File f,String type){Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_STREAM,FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(Intent.createChooser(i,"Share SIYOMA export"));}catch(Exception e){toast("Could not open sharing app");}}
    private void writeBackup(Uri uri){File source=getDatabasePath("siyoma_mpesa_tracker.db");try{db.getWritableDatabase().execSQL("PRAGMA wal_checkpoint(TRUNCATE)");db.close();try(InputStream in=new FileInputStream(source);OutputStream out=getContentResolver().openOutputStream(uri,"w")){if(out==null)throw new IllegalStateException("Destination unavailable");byte[] b=new byte[16384];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();}toast("Database backup created successfully.");}catch(Exception e){toast("Backup failed: "+e.getMessage());}finally{db=new TrackerDb(this);}}
    private void restoreBackup(Uri uri){File tmp=new File(getCacheDir(),"siyoma-restore.db");File target=getDatabasePath("siyoma_mpesa_tracker.db");File staged=new File(target.getParent(),"siyoma_mpesa_tracker.restore.db");File previous=new File(target.getParent(),"siyoma_mpesa_tracker.previous.db");try{try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(tmp)){if(in==null)throw new IllegalStateException("Backup unavailable");byte[] b=new byte[16384];int n;while((n=in.read(b))>0)out.write(b,0,n);}android.database.sqlite.SQLiteDatabase check=android.database.sqlite.SQLiteDatabase.openDatabase(tmp.getPath(),null,android.database.sqlite.SQLiteDatabase.OPEN_READONLY);boolean valid=false;try(android.database.Cursor c=check.rawQuery("PRAGMA integrity_check",null)){valid=c.moveToFirst()&&"ok".equalsIgnoreCase(c.getString(0));}if(valid){try(android.database.Cursor c=check.rawQuery("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='mpesa'",null)){valid=c.moveToFirst()&&c.getInt(0)==1;}}check.close();if(!valid)throw new IllegalArgumentException("Invalid SIYOMA MPESA TRACKER backup");copyFile(tmp,staged);db.getWritableDatabase().execSQL("PRAGMA wal_checkpoint(TRUNCATE)");db.close();File wal=new File(target+"-wal"),shm=new File(target+"-shm");if(wal.exists())wal.delete();if(shm.exists())shm.delete();if(previous.exists())previous.delete();if(target.exists()&&!target.renameTo(previous))throw new IllegalStateException("Could not safeguard current database");if(!staged.renameTo(target)){if(previous.exists())previous.renameTo(target);throw new IllegalStateException("Could not install restored database");}if(previous.exists())previous.delete();db=new TrackerDb(this);db.getReadableDatabase();show("HOME");toast("Backup restored successfully.");}catch(Exception e){if(db==null)db=new TrackerDb(this);toast("Restore failed: "+e.getMessage());}finally{tmp.delete();staged.delete();}}
    private void copyFile(File from,File to)throws Exception{try(InputStream in=new FileInputStream(from);OutputStream out=new FileOutputStream(to)){byte[] b=new byte[16384];int n;while((n=in.read(b))>0)out.write(b,0,n);out.flush();}}
    private String date(long t){return new SimpleDateFormat("dd MMM yyyy, HH:mm",Locale.getDefault()).format(new Date(t));}
    private String money(double v){return String.format(Locale.US,"%,.2f",v);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){handler.removeCallbacks(liveTicker);if(db!=null)db.close();super.onDestroy();}
}
