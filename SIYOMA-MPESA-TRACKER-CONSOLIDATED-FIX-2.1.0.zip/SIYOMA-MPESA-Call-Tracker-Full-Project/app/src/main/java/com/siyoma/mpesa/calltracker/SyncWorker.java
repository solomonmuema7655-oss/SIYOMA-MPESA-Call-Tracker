package com.siyoma.mpesa.calltracker;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Background recovery sync for the app's approved M-PESA SMS money-management feature. */
public class SyncWorker extends Worker {
    public SyncWorker(@NonNull Context c,@NonNull WorkerParameters p) { super(c,p); }
    @NonNull @Override public Result doWork() {
        try {
            if(getApplicationContext().checkSelfPermission(android.Manifest.permission.READ_SMS)==android.content.pm.PackageManager.PERMISSION_GRANTED)
                SyncEngine.syncMpesa(getApplicationContext());
            return Result.success();
        } catch(RuntimeException e) { return Result.retry(); }
    }
}
