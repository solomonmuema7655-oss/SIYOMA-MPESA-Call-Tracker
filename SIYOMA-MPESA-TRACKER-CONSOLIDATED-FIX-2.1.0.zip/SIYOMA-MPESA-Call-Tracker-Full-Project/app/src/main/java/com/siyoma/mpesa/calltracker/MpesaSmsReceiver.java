package com.siyoma.mpesa.calltracker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsMessage;
import android.provider.Telephony;
import java.util.LinkedHashMap;
import java.util.Map;

public class MpesaSmsReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent) {
        if(!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        final SmsMessage[] messages=Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if(messages==null||messages.length==0) return;
        final Context app=context.getApplicationContext();
        final PendingResult pending=goAsync();
        new Thread(()->{
            TrackerDb db=null;
            try {
                db=new TrackerDb(app);
                Map<String,StringBuilder> multipartBodies=new LinkedHashMap<>();
                Map<String,SmsMessage> multipartHeads=new LinkedHashMap<>();
                for(SmsMessage sms:messages) {
                    if(sms==null) continue;
                    String sender=sms.getOriginatingAddress();
                    String key=(sender==null?"":sender)+"|"+sms.getTimestampMillis();
                    if(!multipartBodies.containsKey(key)) {
                        multipartBodies.put(key,new StringBuilder());
                        multipartHeads.put(key,sms);
                    }
                    multipartBodies.get(key).append(sms.getMessageBody()==null?"":sms.getMessageBody());
                }
                boolean insertedAny=false;
                for(String key:multipartBodies.keySet()) {
                    SmsMessage head=multipartHeads.get(key);
                    String body=multipartBodies.get(key).toString();
                    if(!MpesaParser.isMpesa(body)) continue;
                    String sender=head.getOriginatingAddress();
                    long timestamp=head.getTimestampMillis();
                    boolean inserted=db.addMpesa(MpesaParser.fingerprint(sender,body,timestamp),MpesaParser.reference(body),
                        MpesaParser.amount(body),MpesaParser.balance(body),MpesaParser.category(body),
                        sender,body,timestamp);
                    insertedAny |= inserted;
                }
                if(insertedAny) app.sendBroadcast(new Intent(MainActivity.ACTION_MONEY_DATA_CHANGED).setPackage(app.getPackageName()));
            } catch(RuntimeException ignored) {
                // The next app launch/history sync can recover messages still in the Inbox.
            } finally {
                if(db!=null) db.close();
                pending.finish();
            }
        },"SIYOMA-live-mpesa-sms").start();
    }
}
