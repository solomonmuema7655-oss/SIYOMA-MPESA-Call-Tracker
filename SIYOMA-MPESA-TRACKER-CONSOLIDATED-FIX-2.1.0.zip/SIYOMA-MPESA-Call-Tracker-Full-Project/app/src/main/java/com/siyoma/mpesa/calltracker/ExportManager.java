package com.siyoma.mpesa.calltracker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Environment;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Local-only M-PESA exports. Reports are descriptive and are not official Safaricom statements. */
public final class ExportManager {
    private ExportManager() {}

    private static File exportDir(Context c) throws Exception {
        File base=c.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        if(base==null) base=c.getFilesDir();
        File dir=new File(base,"SIYOMA-Exports");
        if(!dir.exists()&&!dir.mkdirs()) throw new IllegalStateException("Could not create export folder");
        return dir;
    }

    /** Export only M-PESA transactions. */
    public static File csv(Context c,TrackerDb db) throws Exception {
        File f=new File(exportDir(c),"mpesa-transactions-"+System.currentTimeMillis()+".csv");
        try(OutputStreamWriter w=new OutputStreamWriter(new FileOutputStream(f),StandardCharsets.UTF_8)) {
            w.write('\ufeff');
            w.write("Date,Receipt reference,Category,Transaction amount KES,Balance KES,Sender,Original SMS\r\n");
            for(Record r:db.allMpesa()) {
                w.write(csv(date(r.timestamp))+","+csv(r.reference)+","+csv(r.category)+","+
                        csv(r.title==null?"":r.title.replace("KSh ",""))+","+csv(r.amount)+","+
                        csv(r.subtitle)+","+csv(r.body)+"\r\n");
            }
        }
        return f;
    }

    private static String csv(String value) {
        String s=value==null?"":value.replace("\r"," ").replace("\n"," ");
        if(!s.isEmpty() && "=+-@".indexOf(s.charAt(0))>=0) s="'"+s;
        return "\""+s.replace("\"","\"\"")+"\"";
    }

    /** Export a descriptive M-PESA summary PDF only. */
    public static File pdf(Context c,TrackerDb db) throws Exception {
        File f=new File(exportDir(c),"SIYOMA-MPESA-summary-"+System.currentTimeMillis()+".pdf");
        PdfDocument pdf=new PdfDocument();
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        List<Record> mpesa=db.allMpesa();
        int pageNo=1,y;
        PdfDocument.Page page=pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());
        Canvas canvas=page.getCanvas();
        p.setColor(0xff061b3a); p.setTextSize(25); p.setFakeBoldText(true); canvas.drawText("SIYOMA",40,52,p);
        p.setTextSize(14); canvas.drawText("M-PESA TRACKER — ACTIVITY REPORT",40,78,p);
        p.setFakeBoldText(false); p.setTextSize(10); p.setColor(0xff0757a6);
        canvas.drawText("Generated: "+date(System.currentTimeMillis()),40,101,p);
        p.setColor(0xff10243e); p.setTextSize(12);
        canvas.drawText("M-PESA records captured: "+mpesa.size(),40,145,p);
        canvas.drawText("Sum of captured transaction amounts: KSh "+String.format(Locale.US,"%.2f",db.sumMpesa()),40,166,p);
        p.setTextSize(9); p.setColor(0xff52647a);
        canvas.drawText("The amount sum is not an account balance and may include different transaction types.",40,190,p);
        canvas.drawText("This report is based only on records available to this app; it is not a Safaricom statement.",40,205,p);
        y=249; p.setColor(0xff061b3a); p.setTextSize(12); p.setFakeBoldText(true);
        canvas.drawText("RECENT M-PESA ACTIVITY",40,y,p); y+=22; p.setFakeBoldText(false); p.setTextSize(9);
        int shown=0;
        for(Record r:mpesa) {
            if(shown>=100) break;
            if(y>790) { pdf.finishPage(page); page=pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create()); canvas=page.getCanvas(); y=48; }
            String title=r.title==null?"":r.title.replace("KSh ","");
            String line=date(r.timestamp)+"  "+safe(r.reference,14)+"  "+safe(r.category,13)+"  KSh "+safe(title,14);
            canvas.drawText(line,40,y,p); y+=15; shown++;
        }
        if(mpesa.isEmpty()) canvas.drawText("No M-PESA transactions have been captured.",40,y,p);
        pdf.finishPage(page);
        try(FileOutputStream out=new FileOutputStream(f)){pdf.writeTo(out);} finally {pdf.close();}
        return f;
    }

    private static String safe(String s,int max) { if(s==null)return ""; String v=s.replace('\n',' ').replace('\r',' '); return v.length()>max?v.substring(0,max):v; }
    private static String date(long t){return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault()).format(new Date(t));}
}
