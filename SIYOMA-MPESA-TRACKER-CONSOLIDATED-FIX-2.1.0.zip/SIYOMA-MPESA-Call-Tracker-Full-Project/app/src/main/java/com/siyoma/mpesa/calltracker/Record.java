package com.siyoma.mpesa.calltracker;

public class Record {
    public long id, timestamp, duration;
    public String title, subtitle, body, reference, category, amount;
    public int type;
    public boolean isCall;
    public Record(long id, long timestamp, String title, String subtitle, String body,
                  String reference, String category, String amount, int type,
                  long duration, boolean isCall) {
        this.id=id; this.timestamp=timestamp; this.title=title; this.subtitle=subtitle;
        this.body=body; this.reference=reference; this.category=category;
        this.amount=amount; this.type=type; this.duration=duration; this.isCall=isCall;
    }
}
