package com.siyoma.mpesa.calltracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class TrackerDb extends SQLiteOpenHelper {
    private static final String DB="siyoma_mpesa_tracker.db";
    public static final int VERSION=6;
    public TrackerDb(Context c) { super(c, DB, null, VERSION); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE mpesa (_id INTEGER PRIMARY KEY AUTOINCREMENT, fingerprint TEXT UNIQUE, sms_id TEXT, reference TEXT, amount TEXT, balance TEXT, category TEXT, sender TEXT, body TEXT, time INTEGER)");
        db.execSQL("CREATE UNIQUE INDEX idx_mpesa_sms_id_unique ON mpesa(sms_id) WHERE sms_id IS NOT NULL AND TRIM(sms_id)<>''");
        db.execSQL("CREATE INDEX idx_mpesa_time ON mpesa(time)");
        db.execSQL("CREATE INDEX idx_mpesa_category ON mpesa(category)");
        db.execSQL("CREATE UNIQUE INDEX idx_mpesa_reference_unique ON mpesa(UPPER(TRIM(reference))) WHERE reference IS NOT NULL AND TRIM(reference)<>''");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV) {
        if (oldV < 2) db.execSQL("CREATE INDEX IF NOT EXISTS idx_mpesa_category ON mpesa(category)");
        if (oldV < 3) { try { db.execSQL("DROP TABLE IF EXISTS calls"); } catch(Exception ignored) {} }
        if (oldV < 4) { try { db.execSQL("DROP TABLE IF EXISTS calls"); } catch(Exception ignored) {} }
        if (oldV < 5) {
            db.execSQL("DELETE FROM mpesa WHERE reference IS NOT NULL AND TRIM(reference)<>'' AND _id NOT IN (SELECT MIN(_id) FROM mpesa WHERE reference IS NOT NULL AND TRIM(reference)<>'' GROUP BY UPPER(TRIM(reference)))");
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_mpesa_reference_unique ON mpesa(UPPER(TRIM(reference))) WHERE reference IS NOT NULL AND TRIM(reference)<>''");
        }
        if (oldV < 6) {
            db.execSQL("DELETE FROM mpesa WHERE _id NOT IN (SELECT MIN(_id) FROM mpesa GROUP BY fingerprint)");
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_mpesa_fingerprint_unique ON mpesa(fingerprint)");
            db.execSQL("ALTER TABLE mpesa ADD COLUMN sms_id TEXT");
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_mpesa_sms_id_unique ON mpesa(sms_id) WHERE sms_id IS NOT NULL AND TRIM(sms_id)<>''");
        }
    }
    public synchronized boolean addMpesa(String fingerprint,String ref,String amount,String balance,String category,String sender,String body,long time) {
        return addMpesa(null,fingerprint,ref,amount,balance,category,sender,body,time);
    }
    public synchronized boolean addMpesa(String smsId,String fingerprint,String ref,String amount,String balance,String category,String sender,String body,long time) {
        SQLiteDatabase database=getWritableDatabase();
        // Receipt references are Safaricom's transaction identity. They are more
        // reliable than SMS timestamps, which can differ between broadcast and Inbox.
        if(smsId!=null && !smsId.trim().isEmpty()) {
            try(Cursor existing=database.rawQuery("SELECT 1 FROM mpesa WHERE sms_id=? LIMIT 1",new String[]{smsId})) {
                if(existing.moveToFirst()) return false;
            }
        }
        if(ref!=null && !ref.trim().isEmpty()) {
            try(Cursor existing=database.rawQuery("SELECT 1 FROM mpesa WHERE UPPER(TRIM(reference))=UPPER(TRIM(?)) LIMIT 1",new String[]{ref})) {
                if(existing.moveToFirst()) return false;
            }
        }
        ContentValues v=new ContentValues();
        v.put("fingerprint",fingerprint); if(smsId!=null) v.put("sms_id",smsId); v.put("reference",ref);
        v.put("amount",amount); v.put("balance",balance); v.put("category",category);
        v.put("sender",sender); v.put("body",body); v.put("time",time);
        return database.insertWithOnConflict("mpesa",null,v,SQLiteDatabase.CONFLICT_IGNORE)!=-1;
    }
    public int count() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM mpesa",null)) { return c.moveToFirst()?c.getInt(0):0; }
    }
    public double sumMpesa() { return sumMpesa(0L,Long.MAX_VALUE); }
    public double sumMpesa(long startInclusive,long endExclusive) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(CAST(amount AS REAL)),0) FROM mpesa WHERE time>=? AND time<?",new String[]{String.valueOf(startInclusive),String.valueOf(endExclusive)})) { return c.moveToFirst()?c.getDouble(0):0; }
    }
    public double latestBalance() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT balance FROM mpesa WHERE balance IS NOT NULL AND TRIM(balance)<>'' ORDER BY time DESC LIMIT 1",null)) {
            if(!c.moveToFirst()) return Double.NaN;
            try{return Double.parseDouble(c.getString(0).replace(",",""));}catch(Exception e){return Double.NaN;}
        }
    }
    public double[] summary(long startInclusive,long endExclusive) {
        double received=0, sent=0, airtime=0;
        String sql="SELECT category, COALESCE(SUM(CAST(amount AS REAL)),0) FROM mpesa WHERE time>=? AND time<? GROUP BY category";
        try(Cursor c=getReadableDatabase().rawQuery(sql,new String[]{String.valueOf(startInclusive),String.valueOf(endExclusive)})) {
            while(c.moveToNext()) {
                String cat=c.getString(0); double v=c.getDouble(1);
                if("RECEIVED".equals(cat)||"DEPOSIT".equals(cat)) received+=v;
                else if("AIRTIME".equals(cat)) { sent+=v; airtime+=v; }
                else if("FEE".equals(cat)) sent+=v;
                else if("SENT".equals(cat)||"BUY GOODS".equals(cat)||"PAYBILL".equals(cat)||"WITHDRAWAL".equals(cat)) sent+=v;
            }
        }
        return new double[]{received,sent,airtime,received-sent};
    }
    public List<Record> records(String query) { return records(query,0L,Long.MAX_VALUE); }
    public List<Record> records(String query,long startInclusive,long endExclusive) {
        List<Record> out=new ArrayList<>(); String q="%"+(query==null?"":query.trim())+"%";
        String sql="SELECT _id,reference,amount,balance,category,sender,body,time FROM mpesa WHERE (body LIKE ? OR reference LIKE ? OR category LIKE ? OR sender LIKE ?) AND time>=? AND time<? ORDER BY time DESC";
        String[] args={q,q,q,q,String.valueOf(startInclusive),String.valueOf(endExclusive)};
        try(Cursor c=getReadableDatabase().rawQuery(sql,args)) {
            while(c.moveToNext()) out.add(new Record(c.getLong(0),c.getLong(7),"KSh "+(c.getString(2)==null?"—":c.getString(2)),c.getString(5)==null?"":c.getString(5),c.getString(6),c.getString(1),c.getString(4),c.getString(3),0,0,false));
        }
        return out;
    }
    public List<Record> allMpesa(){return records("");}
}
