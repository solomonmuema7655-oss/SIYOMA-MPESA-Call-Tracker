# Uploading this ZIP to GitHub

1. Open the SIYOMA-MPESA-Call-Tracker repository.
2. Choose **Add file → Upload files** (do not paste the ZIP contents into the code editor).
3. Select this ZIP and wait for the upload progress to finish.
4. Commit the upload to the `main` branch.
5. Open **Actions** and run the Android build workflow if it does not start automatically.

The ZIP is a repository source bundle, not an APK. GitHub Actions extracts it and builds the Android project.

If GitHub's web uploader still displays “Something went really wrong, and we can't process that file”, try a desktop browser or GitHub's mobile browser in desktop mode. The archive should not be opened in the GitHub code editor. The ZIP is under GitHub's normal 25 MiB browser-upload limit.
