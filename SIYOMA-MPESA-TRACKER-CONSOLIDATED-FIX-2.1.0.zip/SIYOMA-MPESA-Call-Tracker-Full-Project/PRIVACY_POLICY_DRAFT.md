# Privacy Policy — SIYOMA M-PESA & Call Tracker

**Draft for review before publication.** Replace the contact placeholder and publish this policy at a stable public URL before submitting to Google Play.

## Data processed
With your explicit permission, the app accesses SMS messages on your device to identify M-PESA transaction messages. It extracts transaction references, amounts, balances when present, sender information, message text, and timestamps to create your personal transaction history. The app does not request access to your call log, does not replace your SMS or Phone app, does not send SMS, and does not record or place calls. Call activity entries are manually entered by you.

## Purpose and storage
M-PESA message data is used only to provide the app's personal M-PESA transaction-tracking and reporting features. Records are stored in the app's local database on your device. CSV/PDF exports and database backups are created only when you initiate those actions and are shared only through the Android share/document interfaces you choose.

## Sharing and advertising
This app build does not include advertising SDKs or upload SMS content to a developer server. Do not add analytics, advertising, cloud synchronization, or third-party data sharing without updating this policy and completing a separate privacy and Play policy review.

## Retention and deletion
Records remain on the device until you delete the app's data or uninstall the app. Exported files and backups are under your control and must be deleted separately from the destination where you saved them.

## Your choices
You can decline or revoke SMS permissions in Android Settings. Without those permissions, automatic M-PESA SMS capture and inbox import are unavailable; manually entered call activity remains available.

## Contact
Privacy questions: **[INSERT OFFICIAL SIYOMA SUPPORT EMAIL]**
