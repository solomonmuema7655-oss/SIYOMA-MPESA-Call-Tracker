# Google Play Option A — SIYOMA MPESA TRACKER

The app retains READ_SMS and RECEIVE_SMS solely for M-PESA transaction tracking and money-management functionality. It does not act as the default SMS app, does not request call-log access, and does not act as the default Phone app.

Public distribution still requires the applicable Google Play SMS permission declaration/review.
