package com.siyoma.mpesa.calltracker;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parser for common Safaricom M-PESA confirmation SMS formats. */
public final class MpesaParser {
    private MpesaParser() {}
    private static final Pattern REF = Pattern.compile("(?i)^\\s*([A-Z0-9]{8,12})\\s+(?=(?:confirmed|reversed|received|cancelled|canceled))");
    private static final Pattern AMOUNT = Pattern.compile("(?i)Ksh\\.?\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)");
    private static final Pattern BALANCE = Pattern.compile("(?i)(?:new\\s+)?M-PESA\\s+balance\\s+is\\s+Ksh\\.?\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)");
    public static boolean isMpesa(String body) {
        if (body == null || body.trim().isEmpty()) return false;
        String s=body.toLowerCase(Locale.ROOT);
        boolean hasAmount=AMOUNT.matcher(body).find();
        boolean transactionLanguage=s.contains("confirmed")||s.contains("reversed")||s.contains("received")||s.contains("sent to")||s.contains("paid to")||s.contains("withdraw")||s.contains("deposit")||s.contains("buy goods")||s.contains("paybill")||s.contains("airtime");
        return hasAmount && transactionLanguage && (s.contains("m-pesa")||s.contains("mpesa"));
    }
    public static String reference(String body) {
        Matcher m=REF.matcher(body == null ? "" : body);
        return m.find()?m.group(1).toUpperCase(Locale.ROOT):"";
    }
    public static String amount(String body) {
        Matcher m=AMOUNT.matcher(body == null ? "" : body);
        return m.find()?m.group(1).replace(",",""):"";
    }
    public static String balance(String body) {
        Matcher m=BALANCE.matcher(body == null ? "" : body);
        return m.find()?m.group(1).replace(",",""):"";
    }
    public static String fingerprint(String sender, String body, long timestamp) {
        try {
            String ref=reference(body);
            String raw=!ref.isEmpty() ? "MPESA-REF|"+ref.toUpperCase(Locale.ROOT)
                : (sender==null?"":sender.trim().toLowerCase(Locale.ROOT))+"|"+(body==null?"":body.trim().replaceAll("\\s+"," ").toLowerCase(Locale.ROOT));
            byte[] digest=MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8));
            StringBuilder out=new StringBuilder();
            for(byte b:digest) out.append(String.format(Locale.ROOT,"%02x",b));
            return out.toString();
        } catch(Exception e) { return String.valueOf(timestamp)+"|"+(body==null?"":body); }
    }
    public static String category(String body) {
        String s=body == null ? "" : body.toLowerCase(Locale.ROOT);
        if (s.contains("reversal") || s.contains("reversed")) return "REVERSAL";
        if (s.contains("buy goods") || s.contains("till number")) return "BUY GOODS";
        if (s.contains("paybill") || s.contains("account number")) return "PAYBILL";
        if (s.contains("airtime")) return "AIRTIME";
        if (s.contains("withdraw")) return "WITHDRAWAL";
        if (s.contains("deposit")) return "DEPOSIT";
        if (s.contains("received") || s.contains("from ")) return "RECEIVED";
        if (s.contains("sent to") || s.contains("paid to")) return "SENT";
        if (s.contains("fuliza")) return "FULIZA";
        return "OTHER";
    }
}
