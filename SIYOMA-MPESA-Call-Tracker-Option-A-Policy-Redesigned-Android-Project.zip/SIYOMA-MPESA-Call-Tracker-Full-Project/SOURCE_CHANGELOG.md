# Source change log — Option A

- Removed READ_CALL_LOG and READ_PHONE_STATE permissions and all call-log provider access.
- Removed automatic call-log and phone-state synchronization.
- Retained manual call-activity records only.
- Added prominent disclosure and consent before requesting SMS permissions.
- Retained M-PESA inbox scanning, live SMS receiver, local storage and duplicate prevention.
- Retained search, date filters, transaction details, CSV/PDF exports and user-controlled backup/restore.
- Retained approved SIYOMA branding.
- Included parser unit tests and a Java 17 / Gradle 8.7 / Android SDK 35 GitHub Actions workflow.

Google Play SMS permission approval, Android compilation and physical-device acceptance tests remain external verification gates.
