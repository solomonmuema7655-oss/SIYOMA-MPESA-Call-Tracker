package com.siyoma.mpesa.calltracker;

import org.junit.Test;
import static org.junit.Assert.*;

public class MpesaParserTest {
    private static final String SAMPLE="UK9LC1RH1Y Confirmed. Ksh50.00 paid to Caroline Ndinda Mwanthi. on 9/11/26 at 6:03 PM.New M-PESA balance is Ksh16.44. Transaction cost, Ksh0.00.";
    @Test public void identifiesConfirmationAndReceipt() {
        assertTrue(MpesaParser.isMpesa(SAMPLE));
        assertEquals("UK9LC1RH1Y",MpesaParser.reference(SAMPLE));
    }
    @Test public void extractsAmountAndBalance() {
        assertEquals("50.00",MpesaParser.amount(SAMPLE));
        assertEquals("16.44",MpesaParser.balance(SAMPLE));
    }
    @Test public void categorizesSentPayments() {
        assertEquals("SENT",MpesaParser.category(SAMPLE));
    }
    @Test public void rejectsUnrelatedText() {
        assertFalse(MpesaParser.isMpesa("Your account has been updated. Ksh50 available."));
    }
    @Test public void categorizesReversals() {
        assertEquals("REVERSAL",MpesaParser.category("Transaction reversed. M-PESA"));
    }
}
