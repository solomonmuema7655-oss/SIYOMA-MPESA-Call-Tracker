package com.siyoma.mpesa.calltracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.database.sqlite.SQLiteDatabase;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends AppCompatActivity {
    private LinearLayout content;
    private TrackerDb db;
    private String page="HOME", search="";
    private TextView syncStatus;
    private long rangeStart=0L, rangeEnd=Long.MAX_VALUE;
    private final AtomicBoolean syncing=new AtomicBoolean(false);
    private final String[] perms={Manifest.permission.READ_SMS,Manifest.permission.RECEIVE_SMS};
    private ActivityResultLauncher<String[]> permissionLauncher;
    private ActivityResultLauncher<String> backupLauncher;
    private ActivityResultLauncher<String[]> restoreLauncher;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        content=findViewById(R.id.content); db=new TrackerDb(this);
        permissionLauncher=registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
            renderHome(); syncIfAllowed();
        });
        backupLauncher=registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"), uri -> { if(uri!=null) writeBackup(uri); });
        restoreLauncher=registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> { if(uri!=null) restoreBackup(uri); });
        findViewById(R.id.nav_home).setOnClickListener(v->show("HOME"));
        findViewById(R.id.nav_mpesa).setOnClickListener(v->show("MPESA"));
        findViewById(R.id.nav_calls).setOnClickListener(v->show("CALLS"));
        findViewById(R.id.nav_reports).setOnClickListener(v->show("REPORTS"));
        show("HOME");
        if((!has(Manifest.permission.READ_SMS)||!has(Manifest.permission.RECEIVE_SMS)) &&
            !getPreferences(MODE_PRIVATE).getBoolean("sms_disclosure_shown",false)) {
            getPreferences(MODE_PRIVATE).edit().putBoolean("sms_disclosure_shown",true).apply();
            showSmsDisclosure();
        }
    }
    @Override protected void onResume(){super.onResume(); if(db!=null) syncIfAllowed();}
    private boolean has(String p){return ContextCompat.checkSelfPermission(this,p)==PackageManager.PERMISSION_GRANTED;}
    private void syncIfAllowed(){
        if(syncing.get()) return;
        if(has(Manifest.permission.READ_SMS)){
            if(!syncing.compareAndSet(false,true)) return;
            if(syncStatus!=null) syncStatus.setText("Synchronizing local history…");
            new Thread(()->{
                int m=0; String status;
                try {
                    m=has(Manifest.permission.READ_SMS)?SyncEngine.syncMpesa(this):0;
                    status="Last M-PESA sync: "+m+" new transactions";
                } catch(RuntimeException e) {
                    status="Sync could not finish: "+(e.getMessage()==null?"unexpected storage/provider error":e.getMessage());
                } finally { syncing.set(false); }
                String finalStatus=status;
                runOnUiThread(()->{if(syncStatus!=null)syncStatus.setText(finalStatus); if(page.equals("HOME"))renderHome();});
            },"SIYOMA-history-sync").start();
        }
    }
    private void show(String p){page=p; search=""; if(p.equals("HOME"))renderHome(); else if(p.equals("MPESA"))renderRecords(false); else if(p.equals("CALLS"))renderRecords(true); else renderReports();}
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(null,1);t.setPadding(0,6,0,6);return t;
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}
    private LinearLayout card(){
        LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(dp(16),dp(12),dp(16),dp(12));
        x.setBackgroundResource(R.drawable.bg_card);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(7),0,dp(7));x.setLayoutParams(lp);return x;
    }
    private void renderHome(){
        content.removeAllViews();
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.siyoma_mpesa_call_tracker_logo);
        logo.setAdjustViewBounds(true);logo.setMaxHeight(dp(210));logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        content.addView(logo,new LinearLayout.LayoutParams(-1,dp(190)));
        LinearLayout head=card();head.setBackgroundResource(R.drawable.bg_header);
        TextView hello=text("BUSINESS ACTIVITY OVERVIEW",18,0xffffffff,true);head.addView(hello);
        head.addView(text("Your records stay on this device first. Internet is not required for SMS capture or local history.",13,0xffe7f2ff,false));
        content.addView(head);
        LinearLayout access=card();
        access.addView(text("DATA ACCESS STATUS",12,0xff0757a6,true));
        access.addView(text("M-PESA SMS: "+(has(Manifest.permission.READ_SMS)&&has(Manifest.permission.RECEIVE_SMS)?"Enabled":"Permission needed"),13,0xff10243e,false));
        access.addView(text("Call activity: manual records only (no call-log permission)",13,0xff10243e,false));
        content.addView(access);
        LinearLayout stats=card();
        stats.addView(text("M-PESA TRANSACTIONS",12,0xff0757a6,true));
        stats.addView(text(String.valueOf(db.count("mpesa")),30,0xff10243e,true));
        stats.addView(text("Recorded amounts total: KSh "+String.format(Locale.US,"%.2f",db.sumMpesa()),14,0xff10243e,false));
        content.addView(stats);
        LinearLayout calls=card();calls.addView(text("MANUAL CALL ACTIVITY",12,0xff0757a6,true));
        calls.addView(text(String.valueOf(db.count("calls"))+" records stored",25,0xff10243e,true));
        content.addView(calls);
        syncStatus=text("Syncing records…",13,0xff0757a6,false);content.addView(syncStatus);
        Button sync=button("SYNC M-PESA HISTORY");sync.setOnClickListener(v->{
            if(!has(Manifest.permission.READ_SMS)||!has(Manifest.permission.RECEIVE_SMS)) showSmsDisclosure();
            else {syncStatus.setText("Synchronizing…");syncIfAllowed();}
        });content.addView(sync);
        Button perm=button("ENABLE M-PESA SMS ACCESS");perm.setOnClickListener(v->showSmsDisclosure());content.addView(perm);
        content.addView(text("Privacy: SIYOMA does not replace your SMS or Phone app, read your call log, record calls, or place calls. Call activity entries are added manually by you.",12,0xff52647a,false));
    }
    private void showSmsDisclosure() {
        new AlertDialog.Builder(this).setTitle("M-PESA SMS access")
            .setMessage("SIYOMA M-PESA & Call Tracker uses SMS access only to identify and store M-PESA transaction messages for your personal money-management records. It does not send SMS, read unrelated messages for advertising, or share your message content. Messages and extracted transaction data are stored locally on this device. You can decline; automatic SMS capture and inbox import will then remain unavailable. Google Play approval is required before public distribution with these permissions.")
            .setNegativeButton("NOT NOW",(d,w)->{})
            .setPositiveButton("I AGREE — CONTINUE",(d,w)->permissionLauncher.launch(perms)).show();
    }
    private void showAddCallDialog() {
        LinearLayout form=new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(18),dp(8),dp(18),0);
        EditText contact=new EditText(this); contact.setSingleLine(true); contact.setHint("Contact name (optional)"); form.addView(contact);
        EditText number=new EditText(this); number.setSingleLine(true); number.setHint("Phone number"); form.addView(number);
        EditText type=new EditText(this); type.setSingleLine(true); type.setHint("Type: Incoming / Outgoing / Missed / Rejected"); type.setText("Outgoing"); form.addView(type);
        EditText seconds=new EditText(this); seconds.setSingleLine(true); seconds.setInputType(2); seconds.setHint("Duration in seconds (optional)"); seconds.setText("0"); form.addView(seconds);
        new AlertDialog.Builder(this).setTitle("Add call activity").setView(form)
            .setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->{
                String n=number.getText().toString().trim(); if(n.isEmpty()){toast("Enter a phone number");return;}
                String t=type.getText().toString().trim().toLowerCase(Locale.ROOT); int kind=t.contains("miss")?3:t.contains("reject")?5:t.contains("incoming")?1:2;
                long sec=0; try{sec=Math.max(0,Long.parseLong(seconds.getText().toString().trim()));}catch(Exception ignored){}
                db.addManualCall(n,contact.getText().toString().trim(),kind,sec,System.currentTimeMillis());
                show("CALLS"); toast("Call activity saved on this device.");
            }).show();
    }
    private Button button(String label){Button b=new Button(this);b.setText(label);b.setAllCaps(false);return b;}
    private void renderRecords(boolean calls){
        content.removeAllViews();
        content.addView(text(calls?"CALL ACTIVITY (MANUAL ENTRIES)":"M-PESA TRANSACTIONS",22,0xff061b3a,true));
        if(calls) {
            content.addView(text("To respect Android and Google Play call-log restrictions, SIYOMA does not read your phone's call history. Add only the call details you choose to record.",13,0xff52647a,false));
            Button add=button("ADD CALL RECORD"); add.setOnClickListener(v->showAddCallDialog()); content.addView(add);
        }
        EditText find=new EditText(this);find.setSingleLine(true);find.setHint(calls?"Search number or contact":"Search receipt, category, sender or SMS text");content.addView(find);
        LinearLayout filters=new LinearLayout(this);filters.setOrientation(LinearLayout.HORIZONTAL);content.addView(filters);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);
        Runnable refresh=()->{
            list.removeAllViews();List<Record> rows=db.records(calls,search,rangeStart,rangeEnd);
            if(rows.isEmpty())list.addView(text(calls?"No call entries yet. Use ADD CALL RECORD to create one.":"No matching M-PESA records. Enable SMS access and sync your inbox.",14,0xff52647a,false));
            for(Record r:rows){
                LinearLayout c=card();c.addView(text(r.title,17,0xff10243e,true));
                c.addView(text(r.subtitle+" • "+date(r.timestamp),12,0xff0757a6,true));
                if(calls) { c.addView(text("Number: "+r.subtitle,13,0xff52647a,false)); c.addView(text("Type: "+r.category+" • Duration: "+duration(r.duration),13,0xff52647a,false)); }
                else {
                    c.addView(text("Category: "+r.category+"  |  Balance: KSh "+(r.amount==null?"—":r.amount),12,0xff52647a,false));
                    c.addView(text(r.body,12,0xff52647a,false));
                }
                c.setOnClickListener(v -> showRecordDetails(r,calls));
                list.addView(c);
            }
        };
        find.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int count,int after){}
            public void onTextChanged(CharSequence s,int st,int before,int count){search=s.toString();refresh.run();}
            public void afterTextChanged(Editable e){}
        });
        addRangeFilter(filters,"All",0L,Long.MAX_VALUE,refresh);
        addRangeFilter(filters,"7 days",System.currentTimeMillis()-7L*86400000L,Long.MAX_VALUE,refresh);
        addRangeFilter(filters,"30 days",System.currentTimeMillis()-30L*86400000L,Long.MAX_VALUE,refresh);
        addRangeFilter(filters,"90 days",System.currentTimeMillis()-90L*86400000L,Long.MAX_VALUE,refresh);
        refresh.run();
        if(!calls) { Button sync=button("REFRESH M-PESA INBOX");sync.setOnClickListener(v->{syncIfAllowed();Toast.makeText(this,"M-PESA sync requested",Toast.LENGTH_SHORT).show();});content.addView(sync); }
    }
    private void showRecordDetails(Record r,boolean calls){
        String message;
        if(calls) {
            message="Contact: "+r.title+"\nNumber: "+r.subtitle+"\nCall type: "+r.category+"\nDuration: "+duration(r.duration)+"\nDate: "+date(r.timestamp);
        } else {
            message="Receipt: "+(r.reference==null||r.reference.isEmpty()?"Not detected":r.reference)+"\nCategory: "+r.category+"\nTransaction amount: KSh "+r.title.replace("KSh ","")+"\nBalance shown in SMS: KSh "+(r.amount==null||r.amount.isEmpty()?"Not provided":r.amount)+"\nSender: "+r.subtitle+"\nDate: "+date(r.timestamp)+"\n\nOriginal message:\n"+r.body;
        }
        new AlertDialog.Builder(this).setTitle(calls?"Call details":"M-PESA transaction details").setMessage(message).setPositiveButton("Close",null).show();
    }
    private void addRangeFilter(LinearLayout parent,String label,long start,long end,Runnable refresh){
        Button b=button(label); b.setTextSize(11); b.setPadding(dp(4),0,dp(4),0);
        parent.addView(b,new LinearLayout.LayoutParams(0,dp(42),1));
        b.setOnClickListener(v->{rangeStart=start;rangeEnd=end;refresh.run();});
    }
    private void renderReports(){
        content.removeAllViews();
        content.addView(text("REPORTS & EXPORTS",22,0xff061b3a,true));
        LinearLayout a=card();a.addView(text("M-PESA RECORDS",13,0xff0757a6,true));
        a.addView(text("Total entries: "+db.count("mpesa"),20,0xff10243e,true));
        a.addView(text("Sum of captured transaction amounts: KSh "+String.format(Locale.US,"%.2f",db.sumMpesa()),14,0xff10243e,false));
        content.addView(a);
        LinearLayout b=card();b.addView(text("CALL ACTIVITY",13,0xff0757a6,true));
        b.addView(text("Manually recorded calls: "+db.count("calls"),20,0xff10243e,true));content.addView(b);
        Button m=button("EXPORT ALL M-PESA RECORDS (CSV)");m.setOnClickListener(v->exportCsv(false));content.addView(m);
        Button c=button("EXPORT MANUAL CALL ACTIVITY (CSV)");c.setOnClickListener(v->exportCsv(true));content.addView(c);
        Button pdf=button("GENERATE PDF SUMMARY");pdf.setOnClickListener(v->{
            try{share(ExportManager.pdf(this,db),"application/pdf");}catch(Exception e){toast("PDF export failed: "+e.getMessage());}
        });content.addView(pdf);
        Button backup=button("BACK UP LOCAL DATABASE"); backup.setOnClickListener(v->backupLauncher.launch("SIYOMA-MPESA-Call-Tracker-Backup.db")); content.addView(backup); Button restore=button("RESTORE DATABASE BACKUP"); restore.setOnClickListener(v->restoreLauncher.launch(new String[]{"application/octet-stream","application/x-sqlite3","*/*"})); content.addView(restore); content.addView(text("CSV files contain transaction/call records captured on this device. The PDF is a local summary, not an official Safaricom statement.",12,0xff52647a,false));
    }
    private void exportCsv(boolean calls){
        try{share(ExportManager.csv(this,db,calls),"text/csv");}
        catch(Exception e){toast("CSV export failed: "+e.getMessage());}
    }
    private void share(File f,String type){
        Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_STREAM,FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try{startActivity(Intent.createChooser(i,"Share SIYOMA export"));}catch(Exception e){toast("Could not open sharing app");}
    }

    private void writeBackup(Uri uri) {
        File source=getDatabasePath("siyoma_tracker.db");
        try {
            db.getWritableDatabase().execSQL("PRAGMA wal_checkpoint(TRUNCATE)");
            db.close();
            try(InputStream in=new FileInputStream(source); OutputStream out=getContentResolver().openOutputStream(uri,"w")) {
                if(out==null) throw new IllegalStateException("Destination unavailable");
                byte[] b=new byte[16384]; int n; while((n=in.read(b))>0) out.write(b,0,n); out.flush();
            }
            toast("Database backup created successfully.");
        } catch(Exception e) { toast("Backup failed: "+e.getMessage()); }
        finally { if(db!=null) db.close(); db=new TrackerDb(this); }
    }
    private void restoreBackup(Uri uri) {
        File tmp=new File(getCacheDir(),"siyoma-restore-candidate.db");
        File target=getDatabasePath("siyoma_tracker.db");
        File staged=new File(getDatabasePath("siyoma_tracker.db").getParentFile(),"siyoma_tracker.restore.db");
        File previous=new File(getDatabasePath("siyoma_tracker.db").getParentFile(),"siyoma_tracker.previous.db");
        try {
            try(InputStream in=getContentResolver().openInputStream(uri); OutputStream out=new FileOutputStream(tmp)) {
                if(in==null) throw new IllegalStateException("Backup unavailable");
                byte[] b=new byte[16384]; int n; while((n=in.read(b))>0) out.write(b,0,n);
            }
            SQLiteDatabase check=SQLiteDatabase.openDatabase(tmp.getPath(),null,SQLiteDatabase.OPEN_READONLY);
            boolean valid=false;
            try(android.database.Cursor c=check.rawQuery("PRAGMA integrity_check",null)) { valid=c.moveToFirst()&&"ok".equalsIgnoreCase(c.getString(0)); }
            if(valid) {
                try(android.database.Cursor c=check.rawQuery("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('mpesa','calls')",null)) { valid=c.moveToFirst()&&c.getInt(0)==2; }
            }
            if(valid) {
                try(android.database.Cursor c=check.rawQuery("SELECT fingerprint,reference,amount,balance,category,sender,body,time FROM mpesa LIMIT 0",null)) { valid=true; }
                catch(Exception invalidSchema) { valid=false; }
            }
            if(valid) {
                try(android.database.Cursor c=check.rawQuery("SELECT source_id,number,contact,type,duration,time FROM calls LIMIT 0",null)) { valid=true; }
                catch(Exception invalidSchema) { valid=false; }
            }
            check.close();
            if(!valid) throw new IllegalArgumentException("This is not a valid SIYOMA tracker database backup");
            copyFile(tmp,staged);
            db.getWritableDatabase().execSQL("PRAGMA wal_checkpoint(TRUNCATE)");
            db.close();
            File wal=new File(target.getPath()+"-wal"), shm=new File(target.getPath()+"-shm");
            if(wal.exists()) wal.delete(); if(shm.exists()) shm.delete();
            if(previous.exists()) previous.delete();
            if(target.exists()&&!target.renameTo(previous)) throw new IllegalStateException("Could not safeguard current database");
            if(!staged.renameTo(target)) {
                if(previous.exists()) previous.renameTo(target);
                throw new IllegalStateException("Could not install restored database");
            }
            if(previous.exists()) previous.delete();
            db=new TrackerDb(this); db.getReadableDatabase(); show("HOME");
            toast("Backup restored and database validated successfully.");
        } catch(Exception e) {
            if(db==null) db=new TrackerDb(this);
            toast("Restore failed: "+e.getMessage());
        } finally { tmp.delete(); staged.delete(); }
    }
    private void copyFile(File from,File to) throws Exception {
        try(InputStream in=new FileInputStream(from);OutputStream out=new FileOutputStream(to)) {
            byte[] b=new byte[16384]; int n; while((n=in.read(b))>0) out.write(b,0,n); out.flush();
        }
    }
    private String date(long t){return new SimpleDateFormat("dd MMM yyyy, HH:mm",Locale.getDefault()).format(new Date(t));}
    private String duration(long sec){return String.format(Locale.getDefault(),"%02d:%02d",sec/60,sec%60);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
