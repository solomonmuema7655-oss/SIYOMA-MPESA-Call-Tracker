package com.siyoma.mpesa.calltracker;

import android.content.Context;
import android.database.Cursor;
import android.provider.Telephony;

/** Imports provider history incrementally; unique keys make repeated full scans safe. */
public final class SyncEngine {
    private SyncEngine() {}

    public static int syncMpesa(Context context) {
        int inserted=0;
        String[] projection={Telephony.Sms.ADDRESS,Telephony.Sms.BODY,Telephony.Sms.DATE};
        TrackerDb db=null;
        try(Cursor c=context.getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI,projection,null,null,Telephony.Sms.DATE+" ASC")) {
            if(c==null) return 0;
            int ixAddress=c.getColumnIndexOrThrow(Telephony.Sms.ADDRESS);
            int ixBody=c.getColumnIndexOrThrow(Telephony.Sms.BODY);
            int ixDate=c.getColumnIndexOrThrow(Telephony.Sms.DATE);
            db=new TrackerDb(context);
            while(c.moveToNext()) {
                String body=c.getString(ixBody);
                if(!MpesaParser.isMpesa(body)) continue;
                long timestamp=c.getLong(ixDate);
                String sender=c.getString(ixAddress);
                String fingerprint=MpesaParser.fingerprint(sender,body,timestamp);
                if(db.addMpesa(fingerprint,MpesaParser.reference(body),MpesaParser.amount(body),
                    MpesaParser.balance(body),MpesaParser.category(body),sender,body,timestamp)) inserted++;
            }
        } catch(SecurityException ignored) {
            // Permission can be revoked while a scan is running; keep already stored records.
        } finally { if(db!=null) db.close(); }
        return inserted;
    }

}
