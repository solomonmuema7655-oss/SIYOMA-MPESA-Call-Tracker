# SIYOMA M-PESA & Call Tracker — Option A policy design

## Default communication apps
This application does not request to become the default SMS app, default Phone app, or Assistant. It does not replace the user's existing apps.

## SMS-based money management
The app's core purpose is personal M-PESA transaction tracking. `READ_SMS` and `RECEIVE_SMS` are retained only for inbox import and incoming M-PESA transaction capture. The app presents a prominent disclosure and consent step before requesting runtime permissions. These permissions remain subject to Google Play's SMS-based money-management exception review and approval. This source change is not evidence that Google has approved the declaration.

## Call activity
`READ_CALL_LOG`, `READ_PHONE_STATE`, CallLog provider access, and phone-state broadcast monitoring have been removed. The Calls section now stores only records the user manually enters. Existing automatically imported call records are cleared on database upgrade to avoid continuing to use data obtained through the removed restricted permission.

## Distribution
Google Play policy approval is required before publishing with SMS permissions. Play Protect may still block direct internet sideloading of an APK declaring sensitive SMS permissions; distributing through Google Play and completing policy review is the intended route. No attempt is made to bypass Play Protect.

## User data
SMS data is used solely for the app's disclosed local M-PESA transaction-tracking function. Do not add advertising, analytics, cloud upload, or unrelated message processing without a separate policy and privacy review.
