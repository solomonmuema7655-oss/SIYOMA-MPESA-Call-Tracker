# SIYOMA M-PESA & Call Tracker — Option A

A local-first Android app for personal M-PESA transaction record-keeping. It retains the user's existing default SMS and Phone apps.

## Included
- Disclosed, user-consented M-PESA SMS access.
- Historical M-PESA inbox scan and live SMS_RECEIVED capture.
- Receipt reference, amount, balance, category, sender, raw message and timestamp extraction.
- Local SQLite storage with duplicate prevention.
- Manual call-activity entries only. The app does not read the device call log.
- Search, All / 7 / 30 / 90 day filters and record details.
- CSV exports and PDF activity summary.
- User-controlled database backup and validated restore.
- SIYOMA branding and launcher artwork.

## Explicitly not included
- No READ_CALL_LOG, WRITE_CALL_LOG, READ_PHONE_STATE or call-log provider access.
- No default Phone or SMS role replacement.
- No call recording, call placement, cloud upload or automatic call-history import.

## Build
The GitHub Actions workflow targets Ubuntu 22.04, Java 17, Gradle 8.7 and Android SDK 35. It runs parser unit tests, builds DEBUG and unsigned RELEASE APKs, and uploads both as workflow artifacts.

The workflow can build this project from its extracted directory or from the ZIP committed at repository root. Keep the ZIP filename exactly `SIYOMA-MPESA-Call-Tracker-Option-A-Policy-Redesigned-Android-Project.zip` unless you also update the repository workflow's ZIP search name.

## Google Play and privacy
The SMS permissions are retained only for the M-PESA money-management feature. Google Play eligibility and permission approval are not guaranteed by this source package; the developer must complete the Play Console declaration and receive Google's decision. Sideloading may still trigger Play Protect. The app stores captured messages and records locally; it does not upload them to a server.

## Verification
See `BUILD_STATUS.md`. Archive integrity and source-level policy checks can be performed before upload, but Android compilation, installation, device behavior and Google Play approval must be verified separately.

Developer identity: SiyomaCodingPrograms / SIYOMA TECH DESIGNS.
