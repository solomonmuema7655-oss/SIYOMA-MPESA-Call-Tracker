# SIYOMA Tenant & Rent Tracker V3.4

Professional Android property-management build based on the supplied V2.1 source foundation.

## V3.2 payment implementation
- Tenant payment profile: M-PESA number or bank name/account number.
- Payment Intent records for expected rent obligations.
- Immutable original transaction records with source fingerprints.
- Native M-PESA SMS detection and review notifications.
- Detection is deliberately separated from accounting allocation.
- Registered M-PESA number matching with unique-name fallback and ambiguous-match handling.
- Confidence assessment: very strong, strong, moderate, ambiguous and unmatched.
- Pending confirmation, partial allocation, allocated and unallocated states.
- Exact rent, partial rent and overpayment handling.
- Real split-allocation editor: one transaction can be divided across multiple purposes and tenants, subject to transaction and rent-period limits.
- Accounting categories: Rent, Water, Electricity, Maintenance, Service Charge, Deposit, Arrears, Refund/Adjustment and Other.
- Separate append-only accounting allocation ledger.
- Rent allocations update the existing rent ledger and rent balances; non-rent allocations do not silently change rent balances.
- Already-paid-rent protection.
- Payment audit trail.
- Generic bank CSV statement import without pretending that a stored bank account number provides bank access.
- Payment Control Center and separate views for pending reviews, confirmed rent, all allocations and original detected transactions.
- Backup/restore preserves the reconciliation model.
- Existing Paystack/Cloudflare-D1 subscription foundation, App PIN, reminders, receipts and reporting retained.

## UI direction
The payment area is designed around a property-manager workflow rather than an AI-style dashboard: review queue first, clear accounting decision, source transaction history, allocation ledger and audit trail.

## Compatibility
- Minimum Android: API 21
- Target Android: API 35
- Resizable/adaptive activity enabled.

## Accounting principle
**SIYOMA detects. SIYOMA informs. The landlord confirms. SIYOMA records.**

## Verification
- `node --check app/src/main/assets/app.js`: PASS.
- Payment-engine smoke tests execute functions extracted from the actual `app.js`: PASS.
- Smoke tests cover exact rent matching, already-paid-rent protection, partial payments, overpayments, split-allocation arithmetic, Kenyan phone normalization and transaction fingerprint normalization.
- Source-level checks for the new payment UI, allocation ledger, bank CSV importer and native tenant matcher: PASS.
- Android APK compilation was **not** claimed here because the supplied project delegates to a system Gradle executable and Gradle is unavailable in this execution environment. The included GitHub Actions workflow remains configured for Ubuntu 22.04, Java 17 and Gradle 8.7.

## SMS / Google Play note
Android SMS access is sensitive and Google Play policy-controlled. The source includes the requested native SMS workflow for compatible Android testing, but Play Store publication requires the SMS use case to satisfy the applicable policy and declaration/review requirements. The reconciliation engine is source-agnostic and also supports bank CSV input.


## V3.4 permission-flow correction
- Added an explicit in-app M-PESA SMS permission explanation before Android's native permission dialog.
- Android's real RECEIVE_SMS runtime dialog is requested only after the user chooses Continue.
- Added explicit permission-denied state and retry flow.
- Added Android App Settings recovery when the system no longer offers the permission prompt.
- Added live SMS/notification permission status in Settings.
- Added separate notification permission handling for Android 13+ so payment-review alerts are not requested silently.
- Added clear first-party disclosure of what SMS access is used for and that detected transactions are not automatically posted as rent.
- Added Play Store policy warning: SMS access remains a restricted permission and is subject to eligibility/review; test APK behavior does not imply Play approval.
