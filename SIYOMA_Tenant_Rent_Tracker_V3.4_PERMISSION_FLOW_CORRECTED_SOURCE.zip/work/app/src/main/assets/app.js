const KEY='siyomaTenantTrackerV2';
const SUBSCRIPTION_API='https://siyoma-api-dev.solomonmuema7655.workers.dev';
const INSTALLATION_KEY='siyomaInstallationId';
let pendingPaymentReference=localStorage.getItem('siyomaPendingPaymentReference')||localStorage.getItem('siyomaPaymentReference')||'';

let data=JSON.parse(localStorage.getItem(KEY)||'null')||{properties:[],units:[],tenants:[],payments:[],expenses:[],settings:{landlordName:'',landlordPhone:'',pin:''}};
data.properties=data.properties||[];data.units=data.units||[];data.tenants=data.tenants||[];data.payments=data.payments||[];data.expenses=data.expenses||[];data.settings=Object.assign({landlordName:'',landlordPhone:'',pin:'',securityInitialized:false,remindersEnabled:true,reminderSound:true,reminderVibration:true,reminderTime:'08:00',subscriberEmail:''},data.settings||{});
const money=n=>'KSh '+Number(n||0).toLocaleString('en-KE',{minimumFractionDigits:0,maximumFractionDigits:2});
const todayISO=()=>{let d=new Date();return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10)};
const save=()=>{localStorage.setItem(KEY,JSON.stringify(data));renderAll()};
// V3 payment-reconciliation data model. Existing V2.1 data remains intact.
data.paymentTransactions=data.paymentTransactions||[];
data.paymentIntents=data.paymentIntents||[];
data.paymentAudit=data.paymentAudit||[];
data.paymentAllocations=data.paymentAllocations||[];
data.settings=Object.assign({notifyUnknownPayments:false,paymentNotificationDetails:true},data.settings||{});
data.tenants.forEach(t=>{t.paymentMethod=t.paymentMethod||'M-PESA';t.mpesaNumber=t.mpesaNumber||'';t.bankName=t.bankName||'';t.bankAccountNumber=t.bankAccountNumber||''});

const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const readImage=file=>new Promise(r=>{if(!file)return r('');const fr=new FileReader();fr.onload=()=>r(fr.result);fr.onerror=()=>r('');fr.readAsDataURL(file)});
function pid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function showScreen(id){document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));let s=document.getElementById(id);if(s)s.classList.add('active');document.querySelectorAll('nav button').forEach(x=>x.classList.toggle('active',x.dataset.screen===id));renderAll()}
function openModal(id){if(id==='unitModal')populateUnitProperty();if(id==='tenantModal'){populateUnitSelect();if(!document.getElementById('tenantForm').dataset.edit){document.getElementById('tenantModalTitle').textContent='Add Tenant';document.getElementById('tMoveIn').value=todayISO();document.getElementById('tDue').value=todayISO()}}if(id==='paymentModal'){populateTenantSelect();document.getElementById('pDate').value=todayISO()}if(id==='expenseModal')populateExpenseProperty();document.getElementById(id).classList.add('show')}
function closeModal(id){document.getElementById(id)?.classList.remove('show')}
function monthsDue(t,asOf=todayISO()){let due=t.due||t.moveIn||asOf;if(due>asOf)return 0;let a=new Date(due+'T00:00:00'),b=new Date(asOf+'T00:00:00');return Math.max(1,(b.getFullYear()-a.getFullYear())*12+b.getMonth()-a.getMonth()+1)}
function totalDue(t){return Number(t.rent||0)*monthsDue(t)}
function tenantPaid(t){return data.payments.filter(p=>p.tenantId===t.id).reduce((a,p)=>a+Number(p.amount||0),0)}
function prepaidInfo(t,asOf=todayISO()){
  const rent=Number(t.rent||0), first=t.due||t.moveIn||asOf, paid=tenantPaid(t), accrued=rent*monthsDue(t,asOf);
  if(rent<=0||!first)return {paid,accrued,prepaidAmount:0,prepaidMonths:0,nextDue:first};
  const completeMonths=Math.floor(paid/rent);
  let d=new Date(first+'T00:00:00');
  d.setMonth(d.getMonth()+completeMonths);
  const today=new Date(asOf+'T00:00:00');
  while(d<=today && paid < rent*(monthsDue(t,asOf)+1)) d.setMonth(d.getMonth()+1);
  const prepaidAmount=Math.max(0,paid-accrued);
  const prepaidMonths=Math.max(0,Math.floor(prepaidAmount/rent));
  return {paid,accrued,prepaidAmount,prepaidMonths,nextDue:d.toISOString().slice(0,10)};
}
function tenantBalance(t){return Math.max(0,totalDue(t)-tenantPaid(t))}
function tenantStatus(t){if(t.status==='moved')return'moved';const b=tenantBalance(t);if(b<=0)return'paid';return (t.due||'9999')<todayISO()?'overdue':'partial'}
function nextDueDate(t){return prepaidInfo(t).nextDue}
function selectedProperty(){return document.getElementById('propertyFilter')?.value||'all'}
function filteredTenants(){let prop=selectedProperty();return data.tenants.filter(t=>prop==='all'||t.propertyId===prop)}
function propertyName(id){return data.properties.find(p=>p.id===id)?.name||''}
function unitName(id){return data.units.find(u=>u.id===id)?.number||''}
function renderDashboard(){let ts=filteredTenants().filter(t=>t.status!=='moved'),units=data.units.filter(u=>selectedProperty()==='all'||u.propertyId===selectedProperty());let expected=ts.reduce((a,t)=>a+totalDue(t),0),collected=data.payments.filter(p=>ts.some(t=>t.id===p.tenantId)).reduce((a,p)=>a+Number(p.amount||0),0),out=ts.reduce((a,t)=>a+tenantBalance(t),0),occ=units.filter(u=>u.tenantId&&ts.some(t=>t.id===u.tenantId)).length;setText('unitsCount',units.length);setText('occupiedCount',occ);setText('vacantCount',Math.max(0,units.length-occ));setText('activeTenants',ts.length);setText('movedOutCount',data.tenants.filter(t=>t.status==='moved'&&(selectedProperty()==='all'||t.propertyId===selectedProperty())).length);setText('overdueCount',ts.filter(t=>tenantStatus(t)==='overdue').length);setText('expected',money(expected));setText('collected',money(collected));setText('outstanding',money(out));setText('collectionRate',(expected?Math.min(100,(collected/expected)*100):0).toFixed(1)+'%');let alerts=ts.filter(t=>tenantBalance(t)>0).sort((a,b)=>tenantBalance(b)-tenantBalance(a)).slice(0,6);document.getElementById('attentionList').innerHTML=alerts.length?alerts.map(itemHTML).join(''):'No rent alerts.'}
function itemHTML(t){let b=tenantBalance(t),s=tenantStatus(t),u=data.units.find(x=>x.id===t.unitId),pr=data.properties.find(x=>x.id===t.propertyId);return `<div class="item"><div><b>${esc(t.name)}</b><div class="meta">${esc(pr?.name||'')} · Unit ${esc(u?.number||'')} · Due ${esc(t.due||'-')}</div></div><div class="amount ${b?'balance':'paid'}">${money(b)}<div class="meta">${s==='overdue'?'OVERDUE':s==='partial'?'PARTIAL':'PAID'}</div></div></div>`}
function renderProperties(){let el=document.getElementById('propertyList');el.innerHTML=data.properties.length?data.properties.map(p=>{let units=data.units.filter(u=>u.propertyId===p.id),occ=units.filter(u=>u.tenantId&&data.tenants.some(t=>t.id===u.tenantId&&t.status!=='moved')).length;return `<div class="propertyCard"><img class="propertyImg" src="${p.image||''}" onerror="this.style.display='none'"><div class="propertyBody"><h3>${esc(p.name)}</h3><p>📍 ${esc(p.location||'Location not set')}</p><p>🏠 ${units.length} units · 👥 ${occ} occupied · 🔑 ${units.length-occ} vacant</p><div class="actionRow"><button class="smallbtn" onclick="viewProperty('${p.id}')">View</button><button class="secondaryBtn" onclick="editProperty('${p.id}')">✏️ Edit</button><button class="smallDanger" onclick="deleteProperty('${p.id}')">🗑️ Delete</button></div></div></div>`}).join(''):'<div class="panel">No properties yet. Add your first property.</div>'}
function renderUnits(){let pf=document.getElementById('unitPropertyFilter')?.value||'all',sf=document.getElementById('unitStatusFilter')?.value||'all';let arr=data.units.filter(u=>(pf==='all'||u.propertyId===pf)&&(sf==='all'||(sf==='occupied'?!!data.tenants.find(t=>t.id===u.tenantId&&t.status!=='moved'):!data.tenants.find(t=>t.id===u.tenantId&&t.status!=='moved'))));document.getElementById('unitList').innerHTML=arr.length?arr.map(u=>{let t=data.tenants.find(x=>x.id===u.tenantId&&x.status!=='moved'),p=data.properties.find(x=>x.id===u.propertyId);return `<div class="item"><div><b>🚪 ${esc(u.number)}</b><div class="meta">${esc(p?.name||'')} · ${esc(u.floor||'Floor not set')}</div><div class="meta">${t?'👤 '+esc(t.name):'🔑 Vacant'}</div></div><div class="amount">${money(u.rent)}<div class="status ${t?'':'vacant'}">${t?'OCCUPIED':'VACANT'}</div><div class="actionRow"><button class="textbtn" onclick="viewUnit('${u.id}')">View</button><button class="textbtn" onclick="editUnit('${u.id}')">✏️ Edit</button><button class="textbtn dangerText" onclick="deleteUnit('${u.id}')">🗑️ Delete</button></div></div></div>`}).join(''):'<div class="panel">No units match your filters.</div>'}
function renderTenants(){let q=(document.getElementById('tenantSearch')?.value||'').toLowerCase(),sf=document.getElementById('tenantStatusFilter')?.value||'active',pf=document.getElementById('tenantPayFilter')?.value||'all';let arr=filteredTenants().filter(t=>(sf==='all'||(sf==='active'?t.status!=='moved':t.status==='moved'))&&(t.name+' '+unitName(t.unitId)+' '+t.phone).toLowerCase().includes(q)&&(pf==='all'||tenantStatus(t)===pf));document.getElementById('tenantList').innerHTML=arr.length?arr.map(t=>{let u=data.units.find(x=>x.id===t.unitId),b=tenantBalance(t);return `<div class="item"><div><b>👤 ${esc(t.name)}</b><div class="meta">Unit ${esc(u?.number||'-')} · ${esc(t.phone||'No phone')}</div><div class="meta">${t.status==='moved'?'🚪 Moved out '+esc(t.moveOutDate||''): '📅 First due '+esc(t.due||'-')+' · Next '+esc(nextDueDate(t))+(prepaidInfo(t).prepaidMonths>0?' · '+prepaidInfo(t).prepaidMonths+' month(s) prepaid':'')}</div></div><div class="amount ${b?'balance':'paid'}">${money(b)}<div class="meta">${tenantStatus(t).toUpperCase()}</div><button class="textbtn" onclick="viewTenant('${t.id}')">View</button></div></div>`}).join(''):'<div class="panel">No tenants match your filters.</div>'}
function renderPayments(){let arr=[...data.payments].reverse();document.getElementById('paymentList').innerHTML=arr.length?arr.map(p=>{let t=data.tenants.find(x=>x.id===p.tenantId);return `<div class="item"><div><b>💳 ${esc(t?.name||'Unknown tenant')}</b><div class="meta">${esc(p.date)} · ${esc(p.period||'')} · ${esc(p.method)}${p.ref?' · Ref '+esc(p.ref):''}</div></div><div class="amount paid">${money(p.amount)}<div class="actionRow"><button class="textbtn" onclick="receipt('${p.id}')">🧾 Receipt</button><button class="textbtn" onclick="editPayment('${p.id}')">✏️ Edit</button><button class="textbtn dangerText" onclick="deletePayment('${p.id}')">🗑️ Delete</button></div></div></div>`}).join(''):'<div class="panel">No payments recorded yet.</div>'}
function renderReports(){let ts=filteredTenants().filter(t=>t.status!=='moved'),units=data.units.filter(u=>selectedProperty()==='all'||u.propertyId===selectedProperty()),expected=ts.reduce((a,t)=>a+totalDue(t),0),collected=data.payments.filter(p=>ts.some(t=>t.id===p.tenantId)).reduce((a,p)=>a+Number(p.amount||0),0),out=ts.reduce((a,t)=>a+tenantBalance(t),0),exps=data.expenses.filter(e=>selectedProperty()==='all'||e.propertyId===selectedProperty()).reduce((a,e)=>a+Number(e.amount||0),0);setText('rExpected',money(expected));setText('rCollected',money(collected));setText('rOutstanding',money(out));setText('rOccupancy',(units.length?((units.filter(u=>u.tenantId&&ts.some(t=>t.id===u.tenantId)).length/units.length)*100):0).toFixed(1)+'%');let net=collected-exps;let pc=document.getElementById('propertyReport');if(pc)pc.innerHTML=`<div class="item"><div><b>💰 Total Expenses</b></div><div class="amount">${money(exps)}</div></div><div class="item"><div><b>📈 Net Income</b></div><div class="amount ${net>=0?'paid':'balance'}">${money(net)}</div></div>`+data.properties.map(p=>{let u=data.units.filter(x=>x.propertyId===p.id),t=data.tenants.filter(x=>x.propertyId===p.id&&x.status!=='moved'),e=t.reduce((a,x)=>a+totalDue(x),0),c=data.payments.filter(x=>t.some(y=>y.id===x.tenantId)).reduce((a,x)=>a+Number(x.amount||0),0),ex=data.expenses.filter(x=>x.propertyId===p.id).reduce((a,x)=>a+Number(x.amount||0),0);return `<div class="item"><div><b>${esc(p.name)}</b><div class="meta">${u.length} units · ${t.length} active · Expenses ${money(ex)}</div></div><div class="amount">${money(c-ex)}<div class="meta">Net · Collected ${money(c)} / Due ${money(e)}</div></div></div>`}).join('')||'<p>No properties to report.</p>';let months=[];for(let i=5;i>=0;i--){let d=new Date();d.setMonth(d.getMonth()-i);let key=d.toISOString().slice(0,7),val=data.payments.filter(p=>p.date.startsWith(key)).reduce((a,p)=>a+Number(p.amount||0),0);months.push({val,label:d.toLocaleString('en',{month:'short'})})}let max=Math.max(1,...months.map(x=>x.val));document.getElementById('chart').innerHTML=months.map(x=>`<div class="barWrap"><div class="barValue">${money(x.val).replace('KSh ','')}</div><div class="bar" style="height:${Math.max(3,x.val/max*135)}px"></div><div class="barLabel">${x.label}</div></div>`).join('')}
function renderExpenses(){let pf=document.getElementById('expensePropertyFilter')?.value||'all',cf=document.getElementById('expenseCategoryFilter')?.value||'all',arr=data.expenses.filter(e=>(pf==='all'||e.propertyId===pf)&&(cf==='all'||e.category===cf)).reverse(),total=arr.reduce((a,e)=>a+Number(e.amount||0),0);let body=arr.length?arr.map(e=>`<div class="item"><div><b>${esc(e.category)} <span class="categoryTag">${esc(propertyName(e.propertyId))}</span></b><div class="meta">${esc(e.date)} · ${esc(e.description||'No description')}${e.ref?' · Ref '+esc(e.ref):''}</div></div><div class="amount">${money(e.amount)}<div class="actionRow"><button class="textbtn" onclick="editExpense('${e.id}')">✏️ Edit</button><button class="textbtn dangerText" onclick="deleteExpense('${e.id}')">🗑️ Delete</button></div></div></div>`).join(''):'<div class="panel">No expenses recorded.</div>';document.getElementById('expenseList').innerHTML=`<div class="panel"><span class="expenseTotal">Total: ${money(total)}</span></div>`+body}
function populatePropertySelectors(){let opts='<option value="all">All Properties</option>'+data.properties.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');['propertyFilter','unitPropertyFilter','expensePropertyFilter'].forEach(id=>{let el=document.getElementById(id);if(el){let old=el.value;el.innerHTML=opts;el.value=[...el.options].some(o=>o.value===old)?old:'all'}})}
function populateUnitProperty(){document.getElementById('uProperty').innerHTML=data.properties.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')||'<option value="">Add a property first</option>'}
function populateUnitSelect(){document.getElementById('tUnit').innerHTML=data.units.filter(u=>{let t=data.tenants.find(x=>x.id===u.tenantId&&x.status!=='moved');return !t}).map(u=>`<option value="${u.id}">${esc(propertyName(u.propertyId))} — ${esc(u.number)}</option>`).join('')||'<option value="">Add a vacant unit first</option>'}
function populateTenantSelect(){document.getElementById('pTenant').innerHTML=data.tenants.filter(t=>t.status!=='moved').map(t=>`<option value="${t.id}">${esc(t.name)} — ${esc(unitName(t.unitId))}</option>`).join('')||'<option value="">Add an active tenant first</option>'}
function populateExpenseProperty(){document.getElementById('eProperty').innerHTML=data.properties.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')||'<option value="">Add a property first</option>'}
function setText(id,v){let e=document.getElementById(id);if(e)e.textContent=v}
async function addImage(id){return readImage(document.getElementById(id)?.files?.[0])}
function resetPropertyForm(){document.getElementById('propertyForm').reset();document.getElementById('propertyForm').dataset.edit='';document.getElementById('propertyModalTitle').textContent='Add Property';document.getElementById('propertySubmit').textContent='Save Property'}
function resetUnitForm(){document.getElementById('unitForm').reset();document.getElementById('unitForm').dataset.edit='';document.getElementById('unitModalTitle').textContent='Add Unit';document.getElementById('unitSubmit').textContent='Save Unit'}
document.getElementById('propertyForm').onsubmit=async e=>{e.preventDefault();let edit=e.target.dataset.edit;if(edit){let p=data.properties.find(x=>x.id===edit);if(!p)return;p.name=propName.value.trim();p.location=propLocation.value.trim();p.description=propDescription.value.trim();let img=await addImage('propImage');if(img)p.image=img;alert('Property updated successfully.')}else{data.properties.push({id:pid(),name:propName.value.trim(),location:propLocation.value.trim(),description:propDescription.value.trim(),image:await addImage('propImage')})}save();resetPropertyForm();closeModal('propertyModal');showScreen('properties')}
document.getElementById('unitForm').onsubmit=async e=>{e.preventDefault();if(!uProperty.value){alert('Add a property first.');return}let edit=e.target.dataset.edit;if(edit){let u=data.units.find(x=>x.id===edit);if(!u)return;u.propertyId=uProperty.value;u.number=uNumber.value.trim();u.rent=Number(uRent.value);u.floor=uFloor.value.trim();u.description=uDescription.value.trim();let img=await addImage('uImage');if(img)u.image=img;let t=data.tenants.find(t=>t.unitId===u.id);if(t)t.propertyId=u.propertyId;t&&(t.rent=Number(uRent.value));alert('Unit updated successfully.')}else data.units.push({id:pid(),propertyId:uProperty.value,number:uNumber.value.trim(),rent:Number(uRent.value),floor:uFloor.value.trim(),description:uDescription.value.trim(),image:await addImage('uImage'),tenantId:null});save();resetUnitForm();closeModal('unitModal');showScreen('units')}
document.getElementById('tenantForm').onsubmit=async e=>{e.preventDefault();let edit=e.target.dataset.edit;if(edit){let t=data.tenants.find(x=>x.id===edit),nu=data.units.find(x=>x.id===tUnit.value),old=data.units.find(u=>u.id===t.unitId);if(!t||!nu)return;if(nu.id!==old?.id&&data.tenants.some(x=>x.status!=='moved'&&x.unitId===nu.id)){alert('That unit is already occupied.');return}t.name=tName.value.trim();t.phone=tPhone.value.trim();t.rent=Number(tRent.value);t.moveIn=tMoveIn.value;t.due=tDue.value;t.note=tNote.value.trim();if(nu.id!==old?.id){if(old)old.tenantId=null;nu.tenantId=t.id;t.unitId=nu.id;t.propertyId=nu.propertyId}let img=await addImage('tImage');if(img)t.image=img;delete e.target.dataset.edit;document.getElementById('tenantModalTitle').textContent='Add Tenant';save();e.target.reset();closeModal('tenantModal');showScreen('tenants');return}let u=data.units.find(x=>x.id===tUnit.value);if(!u||data.tenants.some(t=>t.status!=='moved'&&t.unitId===u.id)){alert('Please choose a vacant unit.');return}let t={id:pid(),name:tName.value.trim(),phone:tPhone.value.trim(),unitId:u.id,propertyId:u.propertyId,rent:Number(tRent.value||u.rent),moveIn:tMoveIn.value,due:tDue.value,image:await addImage('tImage'),note:tNote.value.trim(),status:'active'};data.tenants.push(t);u.tenantId=t.id;save();e.target.reset();document.getElementById('tDue').value=todayISO();document.getElementById('tMoveIn').value=todayISO();closeModal('tenantModal');showScreen('tenants')}
document.getElementById('paymentForm').onsubmit=e=>{e.preventDefault();let edit=e.target.dataset.edit;if(!pTenant.value)return;if(edit){let p=data.payments.find(x=>x.id===edit);if(!p)return;p.tenantId=pTenant.value;p.amount=Number(pAmount.value);p.date=pDate.value;p.period=pPeriod.value;p.method=pMethod.value;p.ref=pRef.value.trim();p.note=pNote.value.trim();delete e.target.dataset.edit;document.querySelector('#paymentModal .modalhead h2').textContent='Record Payment';save();e.target.reset();pDate.value=todayISO();closeModal('paymentModal');showScreen('payments');return}data.payments.push({id:pid(),tenantId:pTenant.value,amount:Number(pAmount.value),date:pDate.value,period:pPeriod.value,method:pMethod.value,ref:pRef.value.trim(),note:pNote.value.trim()});save();e.target.reset();pDate.value=todayISO();pPeriod.value=todayISO().slice(0,7);closeModal('paymentModal');showScreen('payments')}
document.getElementById('expenseForm').onsubmit=e=>{e.preventDefault();let edit=e.target.dataset.edit;if(!eProperty.value){alert('Add a property first.');return}if(edit){let x=data.expenses.find(x=>x.id===edit);if(!x)return;x.propertyId=eProperty.value;x.category=eCategory.value;x.amount=Number(eAmount.value);x.date=eDate.value;x.ref=eRef.value.trim();x.description=eDescription.value.trim();delete e.target.dataset.edit;document.getElementById('expenseModalTitle').textContent='Add Expense'}else data.expenses.push({id:pid(),propertyId:eProperty.value,category:eCategory.value,amount:Number(eAmount.value),date:eDate.value,ref:eRef.value.trim(),description:eDescription.value.trim()});save();e.target.reset();eDate.value=todayISO();closeModal('expenseModal');showScreen('expenses')}
function viewProperty(id){let p=data.properties.find(x=>x.id===id),u=data.units.filter(x=>x.propertyId===id);if(!p)return;document.getElementById('viewTitle').textContent=p.name;document.getElementById('viewBody').innerHTML=`<p>📍 ${esc(p.location||'')}</p><p>${esc(p.description||'')}</p>${u.map(x=>`<div class="item"><div><b>${esc(x.number)}</b><div class="meta">${data.tenants.find(t=>t.id===x.tenantId&&t.status!=='moved')?.name||'Vacant'}</div></div><div class="amount">${money(x.rent)}</div></div>`).join('')}`;document.getElementById('viewModal').classList.add('show')}
function viewUnit(id){let u=data.units.find(x=>x.id===id),t=data.tenants.find(x=>x.id===u?.tenantId&&x.status!=='moved');if(!u)return;document.getElementById('viewTitle').textContent='Unit '+u.number;document.getElementById('viewBody').innerHTML=`<p><b>Property:</b> ${esc(propertyName(u.propertyId))}</p><p><b>Rent:</b> ${money(u.rent)}<br><b>Status:</b> ${t?'Occupied':'Vacant'}<br><b>Tenant:</b> ${esc(t?.name||'None')}</p>${t?`<button class="primary" onclick="closeModal('viewModal');viewTenant('${t.id}')">View Tenant</button>`:''}`;document.getElementById('viewModal').classList.add('show')}
function viewTenant(id){let t=data.tenants.find(x=>x.id===id),u=data.units.find(x=>x.id===t?.unitId),b=tenantBalance(t);if(!t)return;document.getElementById('viewTitle').textContent=t.name;document.getElementById('viewBody').innerHTML=`${t.image?`<img class="propertyImg" src="${t.image}">`:''}<p><b>Unit:</b> ${esc(u?.number||'-')}<br><b>Property:</b> ${esc(propertyName(t.propertyId))}<br><b>Phone:</b> ${esc(t.phone||'-')}<br><b>Monthly Rent:</b> ${money(t.rent)}<br><b>Paid to date:</b> ${money(tenantPaid(t))}<br><b>Balance:</b> ${money(b)}<br><b>Status:</b> ${t.status==='moved'?'Moved Out':tenantStatus(t).toUpperCase()}<br><b>Move-In:</b> ${esc(t.moveIn||'-')}<br><b>First Due:</b> ${esc(t.due||'-')}<br><b>Next Due:</b> ${esc(nextDueDate(t))}<br><b>Prepaid Amount:</b> ${money(prepaidInfo(t).prepaidAmount)}<br><b>Extra Months Paid:</b> ${prepaidInfo(t).prepaidMonths}</p><div class="quick"><button onclick="whatsapp('${t.id}')">📲 WhatsApp</button><button onclick="editTenant('${t.id}')">✏️ Edit</button>${t.status!=='moved'?`<button onclick="moveOut('${t.id}')">🚪 Move Out</button>`:''}<button onclick="closeModal('viewModal')">Close</button></div><h3>📜 Payment History</h3>${data.payments.filter(p=>p.tenantId===id).reverse().map(p=>`<div class="item"><span>${esc(p.date)} · ${esc(p.period||'')} · ${esc(p.method)}</span><b class="paid">${money(p.amount)}</b></div>`).join('')||'<p>No payments yet.</p>'}`;document.getElementById('viewModal').classList.add('show')}
function editTenant(id){let t=data.tenants.find(x=>x.id===id);if(!t)return;closeModal('viewModal');document.getElementById('tenantModalTitle').textContent='Edit Tenant';tName.value=t.name;tPhone.value=t.phone;tRent.value=t.rent;tMoveIn.value=t.moveIn;tDue.value=t.due;tNote.value=t.note||'';populateUnitSelect();tUnit.value=t.unitId;document.getElementById('tenantForm').dataset.edit=id;document.getElementById('tenantModal').classList.add('show')}
function editProperty(id){let p=data.properties.find(x=>x.id===id);if(!p)return;document.getElementById('propertyModalTitle').textContent='Edit Property';document.getElementById('propertySubmit').textContent='Update Property';propName.value=p.name;propLocation.value=p.location||'';propDescription.value=p.description||'';document.getElementById('propertyForm').dataset.edit=id;document.getElementById('propertyModal').classList.add('show')}
function editUnit(id){let u=data.units.find(x=>x.id===id);if(!u)return;document.getElementById('unitModalTitle').textContent='Edit Unit';document.getElementById('unitSubmit').textContent='Update Unit';populateUnitProperty();uProperty.value=u.propertyId;uNumber.value=u.number;uRent.value=u.rent;uFloor.value=u.floor||'';uDescription.value=u.description||'';document.getElementById('unitForm').dataset.edit=id;document.getElementById('unitModal').classList.add('show')}
function editPayment(id){let p=data.payments.find(x=>x.id===id);if(!p)return;populateTenantSelect();pTenant.value=p.tenantId;pAmount.value=p.amount;pDate.value=p.date;pPeriod.value=p.period||p.date.slice(0,7);pMethod.value=p.method;pRef.value=p.ref||'';pNote.value=p.note||'';document.querySelector('#paymentModal .modalhead h2').textContent='Edit Payment';document.getElementById('paymentForm').dataset.edit=id;document.getElementById('paymentModal').classList.add('show')}
function editExpense(id){let x=data.expenses.find(x=>x.id===id);if(!x)return;populateExpenseProperty();eProperty.value=x.propertyId;eCategory.value=x.category;eAmount.value=x.amount;eDate.value=x.date;eRef.value=x.ref||'';eDescription.value=x.description||'';document.getElementById('expenseModalTitle').textContent='Edit Expense';document.getElementById('expenseForm').dataset.edit=id;document.getElementById('expenseModal').classList.add('show')}
function deleteProperty(id){let p=data.properties.find(x=>x.id===id);if(!p)return;let units=data.units.filter(u=>u.propertyId===id),tenants=data.tenants.filter(t=>t.propertyId===id),payments=data.payments.filter(pay=>tenants.some(t=>t.id===pay.tenantId)),expenses=data.expenses.filter(e=>e.propertyId===id);if(units.length||tenants.length||payments.length||expenses.length){alert('This property contains linked units, tenants, payments or expenses. For data safety, remove/archive those records first.');return}if(confirm(`Delete property "${p.name}"?`)){data.properties=data.properties.filter(x=>x.id!==id);save()}}
function deleteUnit(id){let u=data.units.find(x=>x.id===id);if(!u)return;let linked=data.tenants.find(t=>t.unitId===id)||data.payments.some(p=>data.tenants.some(t=>t.id===p.tenantId&&t.unitId===id));if(linked){alert('This unit has a tenant or payment history. Move the tenant out first; linked financial history is protected.');return}if(confirm(`Delete unit "${u.number}"?`)){data.units=data.units.filter(x=>x.id!==id);save()}}
function deletePayment(id){if(confirm('Delete this payment record? Dashboard balances and reports will recalculate.')){data.payments=data.payments.filter(x=>x.id!==id);save()}}
function deleteExpense(id){if(confirm('Delete this expense? Reports and net income will recalculate.')){data.expenses=data.expenses.filter(x=>x.id!==id);save()}}
function moveOut(id){let t=data.tenants.find(x=>x.id===id);if(!t||t.status==='moved')return;if(!confirm(`Move out ${t.name}? Their payment history will be preserved.`))return;t.status='moved';t.moveOutDate=todayISO();let u=data.units.find(x=>x.id===t.unitId);if(u)u.tenantId=null;save();closeModal('viewModal');showScreen('tenants')}
function whatsapp(id){let t=data.tenants.find(x=>x.id===id),phone=(t.phone||'').replace(/\D/g,'');if(phone.startsWith('0'))phone='254'+phone.slice(1);if(!phone){alert('This tenant has no phone number. Edit the tenant profile first.');return}let u=data.units.find(x=>x.id===t.unitId),pi=prepaidInfo(t),msg=pi.prepaidMonths>0?`Hello ${t.name}, this is a rent update for Unit ${u?.number||''}. Current balance: ${money(tenantBalance(t))}. Your rent is prepaid for ${pi.prepaidMonths} extra month(s), with ${money(pi.prepaidAmount)} credit. Next rent due: ${pi.nextDue}. No payment is required before the next due date. Thank you.\n— SIYOMA Tenant & Rent Tracker`:`Hello ${t.name}, this is a rent reminder for Unit ${u?.number||''}. Current balance: ${money(tenantBalance(t))}. Next rent due: ${pi.nextDue}. Kindly make payment when due. Thank you.\n— SIYOMA Tenant & Rent Tracker`;window.location.href=`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`}
function receipt(id){let p=data.payments.find(x=>x.id===id),t=data.tenants.find(x=>x.id===p?.tenantId),u=data.units.find(x=>x.id===t?.unitId),prop=data.properties.find(x=>x.id===t?.propertyId),balance=t?tenantBalance(t):0;if(!p||!t)return;let html=`<div class="printArea"><h2>SIYOMA TENANT & RENT TRACKER</h2><p><b>RENT PAYMENT RECEIPT</b></p><hr><p><b>Receipt No:</b> ${esc(p.id)}<br><b>Tenant:</b> ${esc(t.name)}<br><b>Property:</b> ${esc(prop?.name||'')}<br><b>Unit:</b> ${esc(u?.number||'')}<br><b>Rent Period:</b> ${esc(p.period||p.date.slice(0,7))}<br><b>Amount Paid:</b> ${money(p.amount)}<br><b>Payment Date:</b> ${esc(p.date)}<br><b>Method:</b> ${esc(p.method)}<br><b>Reference:</b> ${esc(p.ref||'Not provided')}<br><b>Balance After Payment:</b> ${money(balance)}<br><b>Prepaid Amount / Credit:</b> ${money(prepaidInfo(t).prepaidAmount)}<br><b>Extra Months Paid:</b> ${prepaidInfo(t).prepaidMonths}<br><b>Next Rent Due:</b> ${esc(nextDueDate(t))}<br><b>Status:</b> ${balance<=0?(prepaidInfo(t).prepaidMonths>0?'PAID — PREPAID':'PAID'):tenantStatus(t).toUpperCase()}</p><p>Thank you for your payment.</p><p class="mini">© 2026 SiyomaCodingPrograms</p></div>`;document.getElementById('viewTitle').textContent='🧾 Rent Payment Receipt';document.getElementById('viewBody').innerHTML=html+`<div class="actionRow"><button class="primary" onclick="nativePrint()">🖨️ Print / Save PDF</button><button class="secondaryBtn" onclick="shareReceiptText('${p.id}')">📤 Share</button></div>`;document.getElementById('viewModal').classList.add('show')}
function nativePrint(){if(window.AndroidBridge&&AndroidBridge.printPage){AndroidBridge.printPage();}else window.print()}
function shareReceiptText(id){let p=data.payments.find(x=>x.id===id),t=data.tenants.find(x=>x.id===p?.tenantId);if(!p||!t)return;let pi=prepaidInfo(t),text=`SIYOMA TENANT & RENT TRACKER\nRENT PAYMENT RECEIPT\nTenant: ${t.name}\nProperty: ${propertyName(t.propertyId)}\nUnit: ${unitName(t.unitId)}\nAmount Paid: ${money(p.amount)}\nDate: ${p.date}\nMethod: ${p.method}\nReference: ${p.ref||'Not provided'}\nBalance: ${money(tenantBalance(t))}\nPrepaid Credit: ${money(pi.prepaidAmount)}\nExtra Months Paid: ${pi.prepaidMonths}\nNext Rent Due: ${pi.nextDue}\nStatus: ${tenantBalance(t)<=0?(pi.prepaidMonths>0?'PAID — PREPAID':'PAID'):tenantStatus(t).toUpperCase()}`;if(navigator.share)navigator.share({title:'Rent Payment Receipt',text}).catch(()=>{});else alert(text)}
function toBase64Utf8(str){let bytes=new TextEncoder().encode(str),bin='';for(let i=0;i<bytes.length;i+=0x8000)bin+=String.fromCharCode(...bytes.subarray(i,i+0x8000));return btoa(bin)}
function saveFileNative(filename,mime,text){if(window.AndroidBridge&&AndroidBridge.saveTextFile){AndroidBridge.saveTextFile(filename,mime,toBase64Utf8(text));return true}return false}
function exportCSV(){let rows=[['Property','Unit','Tenant','Phone','Monthly Rent','Move-In Date','First Rent Due','Payment Date','Rent Period','Payment Method','Reference','Payment Amount','Current Balance','Prepaid Credit','Extra Months Paid','Next Rent Due','Status']];data.tenants.forEach(t=>{let pays=data.payments.filter(p=>p.tenantId===t.id);if(!pays.length)rows.push([propertyName(t.propertyId),unitName(t.unitId),t.name,t.phone,t.rent,t.moveIn,t.due,'','','','','',tenantBalance(t),prepaidInfo(t).prepaidAmount,prepaidInfo(t).prepaidMonths,nextDueDate(t),t.status==='moved'?'Moved Out':tenantStatus(t)]);else pays.forEach(p=>rows.push([propertyName(t.propertyId),unitName(t.unitId),t.name,t.phone,t.rent,t.moveIn,t.due,p.date,p.period||p.date.slice(0,7),p.method,p.ref||'',p.amount,tenantBalance(t),prepaidInfo(t).prepaidAmount,prepaidInfo(t).prepaidMonths,nextDueDate(t),t.status==='moved'?'Moved Out':tenantStatus(t)]))});data.expenses.forEach(e=>rows.push([propertyName(e.propertyId),'','','','','','','',e.date,'EXPENSE',e.ref||'',e.amount,'',e.category+' - '+(e.description||'')]));let csv=rows.map(r=>r.map(x=>'"'+String(x??'').replaceAll('"','""')+'"').join(',')).join('\n');if(!saveFileNative('SIYOMA_Rent_Report.csv','text/csv',csv)){let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download='SIYOMA_Rent_Report.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}}
function backupData(){let text=JSON.stringify(data,null,2);if(!saveFileNative('SIYOMA_V2_Backup_'+todayISO()+'.json','application/json',text)){let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:'application/json'}));a.download='SIYOMA_V2_Backup_'+todayISO()+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}}
function restoreData(e){let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let x=JSON.parse(r.result);if(!x.properties||!x.units||!x.tenants||!x.payments)throw 0;x.expenses=x.expenses||[];x.settings=Object.assign({landlordName:'',landlordPhone:'',pin:'',securityInitialized:false},x.settings||{});if(confirm('Replace current data with this backup?')){data=x;save();alert('Backup restored successfully.')}}catch(err){alert('Invalid SIYOMA backup file.')}};r.readAsText(f)}
async function hashText(v){const b=new TextEncoder().encode(v);const h=await crypto.subtle.digest('SHA-256',b);return Array.from(new Uint8Array(h)).map(x=>x.toString(16).padStart(2,'0')).join('')}

function getInstallationId(){
  let id=localStorage.getItem(INSTALLATION_KEY);
  if(!id){
    const bytes=new Uint8Array(16);
    crypto.getRandomValues(bytes);
    id='SIYOMA-'+Array.from(bytes).map(x=>x.toString(16).padStart(2,'0')).join('');
    localStorage.setItem(INSTALLATION_KEY,id);
  }
  return id;
}

function showSubscriptionGate(message){
  const gate=document.getElementById('subscriptionGate');
  if(!gate)return;
  gate.classList.remove('hidden');
  if(message)document.getElementById('subscriptionMessage').textContent=message;
  const email=document.getElementById('subscriberEmail');
  if(email)email.value=data.settings.subscriberEmail||'';
}

function hideSubscriptionGate(){
  document.getElementById('subscriptionGate')?.classList.add('hidden');
}

function setSubscriptionStatus(message,isError=false){
  const el=document.getElementById('subscriptionStatus');
  if(el){
    el.textContent=message||'';
    el.style.color=isError?'#b91c1c':'#166534';
  }
}

function formatExpiry(ms){
  if(!ms)return '';
  const d=new Date(ms);
  return d.toLocaleString('en-KE',{day:'numeric',month:'short',year:'numeric',hour:'numeric',minute:'2-digit'});
}

async function registerInstallation(){
  const installation_id=getInstallationId();
  const r=await fetch(SUBSCRIPTION_API+'/register',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({installation_id})
  });
  if(!r.ok)throw new Error('Registration failed');
  return r.json();
}

async function getSubscriptionStatus(){
  const installation_id=getInstallationId();
  const r=await fetch(SUBSCRIPTION_API+'/status?installation_id='+encodeURIComponent(installation_id));
  if(!r.ok)throw new Error('Status check failed');
  return r.json();
}

async function startSubscription(planId){
  const email=(document.getElementById('subscriberEmail')?.value||'').trim();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){
    setSubscriptionStatus('Please enter a valid email address.',true);
    document.getElementById('subscriberEmail')?.focus();
    return;
  }
  data.settings.subscriberEmail=email;
  localStorage.setItem(KEY,JSON.stringify(data));
  setSubscriptionStatus('Preparing secure payment...');
  try{
    await registerInstallation();
    const r=await fetch(SUBSCRIPTION_API+'/init',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({
        email,
        installation_id:getInstallationId(),
        plan_id:planId
      })
    });
    const result=await r.json();
    if(!r.ok||!result.ok||!result.authorization_url){
      const details = result.paystack_message || result.message || 'Payment could not be initialized.';
      throw new Error(details);
    }
    pendingPaymentReference=(result.reference||'').trim();
    if(pendingPaymentReference){
      localStorage.setItem('siyomaPendingPaymentReference',pendingPaymentReference);
      // Keep the legacy key too so payment state survives upgrades from the previous working app.
      localStorage.setItem('siyomaPaymentReference',pendingPaymentReference);
      localStorage.setItem('siyomaPaymentPlan',planId);
      localStorage.setItem('siyomaPaymentStartedAt',String(Date.now()));
    }
    setSubscriptionStatus('Payment page opened. Complete payment, then return to SIYOMA and tap Verify.');
    if(window.AndroidBridge&&AndroidBridge.openExternalUrl){
      AndroidBridge.openExternalUrl(result.authorization_url);
    }else{
      window.open(result.authorization_url,'_blank');
    }
  }catch(e){
    setSubscriptionStatus(e.message||'Unable to start payment.',true);
  }
}

function getPendingPaymentReference(){
  return (pendingPaymentReference||
    localStorage.getItem('siyomaPendingPaymentReference')||
    localStorage.getItem('siyomaPaymentReference')||'').trim();
}

function clearPendingPaymentReference(){
  pendingPaymentReference='';
  localStorage.removeItem('siyomaPendingPaymentReference');
  localStorage.removeItem('siyomaPaymentReference');
  localStorage.removeItem('siyomaPaymentPlan');
  localStorage.removeItem('siyomaPaymentStartedAt');
}

async function verifySubscriptionPayment(silent=false){
  const reference=getPendingPaymentReference();
  if(!reference){
    if(!silent)setSubscriptionStatus('No pending payment was found. Start a subscription payment first.',true);
    return false;
  }
  if(!silent)setSubscriptionStatus('Verifying payment with SIYOMA...');
  try{
    // The Cloudflare Worker /verify endpoint is a GET endpoint.
    // Keep the exact reference in the query string; do not send a POST body here.
    const r=await fetch(SUBSCRIPTION_API+'/verify?reference='+encodeURIComponent(reference),{cache:'no-store'});
    const result=await r.json();
    if(!r.ok||result.ok!==true){
      throw new Error(result.message||result.error||'Payment verification failed.');
    }
    if(result.verified===false){
      if(!silent)setSubscriptionStatus(result.message||'Payment has not been completed yet.');
      return false;
    }
    clearPendingPaymentReference();
    await checkSubscription(true);
    if(subscription.active){
      if(!silent)setSubscriptionStatus('Payment verified. Subscription activated successfully.');
      return true;
    }
    if(!silent)setSubscriptionStatus('Payment was verified, but the subscription is not active yet.');
    return false;
  }catch(e){
    if(!silent)setSubscriptionStatus(e.message||'Payment verification failed. Please try again.',true);
    return false;
  }
}

async function resumePendingSubscriptionVerification(){
  if(!getPendingPaymentReference())return false;
  return verifySubscriptionPayment(true);
}

async function checkSubscription(showGate=true){
  if(showGate)showSubscriptionGate('An active subscription is required before you can use SIYOMA Tenant & Rent Tracker.');
  try{
    await registerInstallation();
    const s=await getSubscriptionStatus();
    if(s.active===true){
      hideSubscriptionGate();
      const expiry=document.getElementById('subscriptionExpiry');
      if(expiry)expiry.textContent=s.expires_at?('Subscription expires: '+formatExpiry(Number(s.expires_at)*1000)):'Subscription active';
      return true;
    }
    if(s.status==='suspended'||s.status==='expelled'){
      showSubscriptionGate(s.message||'Your SIYOMA access is currently restricted by the administrator.');
      setSubscriptionStatus(s.status==='expelled'?'Account expelled. Contact SIYOMA for reinstatement.':'Account suspended. Contact SIYOMA for reinstatement.',true);
      return false;
    }
    showSubscriptionGate('Your SIYOMA subscription is inactive or has expired. Select a plan to continue.');
    setSubscriptionStatus('Subscription required.',true);
    return false;
  }catch(e){
    showSubscriptionGate('Internet connection is required to verify your SIYOMA subscription. No offline grace period is available.');
    setSubscriptionStatus('Could not contact the subscription server. Please connect to the internet and try again.',true);
    return false;
  }
}

function hideSecurityScreens(){
  ['lock','setPinSetup'].forEach(id=>document.getElementById(id)?.classList.add('hidden'));
}

async function pinHash(pin){
  const b=new TextEncoder().encode(pin);
  const h=await crypto.subtle.digest('SHA-256',b);
  return Array.from(new Uint8Array(h)).map(x=>x.toString(16).padStart(2,'0')).join('');
}

async function finishSecuritySetup(){
  const p=(document.getElementById('newPinSetup')?.value||'').trim();
  const c=(document.getElementById('confirmPinSetup')?.value||'').trim();
  const hint=document.getElementById('setupPinHint');
  if(!/^\d{4,6}$/.test(p)){if(hint)hint.textContent='PIN must contain 4–6 digits.';return;}
  if(p!==c){if(hint)hint.textContent='PINs do not match.';return;}
  data.settings.pin=await pinHash(p);
  data.settings.securityInitialized=true;
  save();
  sessionStorage.setItem('siyomaUnlocked','1');
  document.getElementById('newPinSetup').value='';
  document.getElementById('confirmPinSetup').value='';
  if(hint)hint.textContent='';
  hideSecurityScreens();
}

async function unlockApp(){
  const p=(document.getElementById('pinInput')?.value||'').trim();
  const hint=document.getElementById('pinHint');
  if(!/^\d{4,6}$/.test(p)){if(hint)hint.textContent='Enter your 4–6 digit App PIN.';return;}
  const stored=data.settings.pin||'';
  const hashed=await pinHash(p);
  const valid=stored===hashed || stored===p;
  if(valid){
    if(stored===p){data.settings.pin=hashed;save();}
    document.getElementById('pinInput').value='';
    if(hint)hint.textContent='';
    sessionStorage.setItem('siyomaUnlocked','1');
    hideSecurityScreens();
  }else if(hint){
    hint.textContent='Incorrect PIN. Use Forgot PIN? if you cannot remember it.';
  }
}

async function forgotPin(){
  const active=await checkSubscription(false);
  if(!active){
    hideSecurityScreens();
    alert('PIN recovery is available only while your SIYOMA subscription is active.');
    return;
  }
  const confirmation=prompt('Confirm your active subscription by typing RESET PIN:');
  if(confirmation===null)return;
  if(confirmation.trim().toUpperCase()!=='RESET PIN'){
    alert('PIN recovery cancelled. Please type RESET PIN exactly.');
    return;
  }
  const p=(prompt('Enter a new 4–6 digit App PIN:')||'').trim();
  if(!/^\d{4,6}$/.test(p)){alert('PIN must contain 4–6 digits.');return;}
  const c=(prompt('Confirm the new App PIN:')||'').trim();
  if(p!==c){alert('PINs do not match.');return;}
  data.settings.pin=await pinHash(p);
  data.settings.securityInitialized=true;
  save();
  sessionStorage.setItem('siyomaUnlocked','1');
  hideSecurityScreens();
}

async function enforceAppSecurity(){
  const active=await checkSubscription(false);
  if(!active)return false;
  if(!data.settings.securityInitialized||!data.settings.pin){
    sessionStorage.removeItem('siyomaUnlocked');
    document.getElementById('setPinSetup')?.classList.remove('hidden');
    document.getElementById('newPinSetup')?.focus();
    return false;
  }
  if(sessionStorage.getItem('siyomaUnlocked')==='1'){
    hideSecurityScreens();
    return true;
  }
  document.getElementById('lock')?.classList.remove('hidden');
  document.getElementById('pinInput')?.focus();
  return false;
}

function initSecurity(){
  document.getElementById('landlordName').value=data.settings.landlordName||'';
  document.getElementById('landlordPhone').value=data.settings.landlordPhone||'';
  if(document.getElementById('remindersEnabled'))document.getElementById('remindersEnabled').checked=data.settings.remindersEnabled!==false;
  if(document.getElementById('reminderSound'))document.getElementById('reminderSound').checked=data.settings.reminderSound!==false;
  if(document.getElementById('reminderVibration'))document.getElementById('reminderVibration').checked=data.settings.reminderVibration!==false;
  if(document.getElementById('reminderTime'))document.getElementById('reminderTime').value=data.settings.reminderTime||'08:00';if(document.getElementById('notifyUnknownPayments'))document.getElementById('notifyUnknownPayments').checked=data.settings.notifyUnknownPayments===true;if(document.getElementById('paymentNotificationDetails'))document.getElementById('paymentNotificationDetails').checked=data.settings.paymentNotificationDetails!==false;updateSmsPermissionStatus();
}

function requestReminderPermission(){
  try{
    if(window.AndroidBridge&&AndroidBridge.requestNotificationPermission){
      AndroidBridge.requestNotificationPermission();
    }
    const enabled=document.getElementById('remindersEnabled')?.checked!==false;
    if(!enabled){alert('Enable reminders first, then test again.');return;}
    const sound=document.getElementById('reminderSound')?.checked!==false;
    const vibration=document.getElementById('reminderVibration')?.checked!==false;
    const now=new Date(Date.now()+60000);
    const date=now.toISOString().slice(0,10);
    const time=now.toTimeString().slice(0,5);
    if(window.AndroidBridge&&AndroidBridge.scheduleRentReminder){
      AndroidBridge.scheduleRentReminder('TEST','Test Tenant','Test Unit',date,date,time,'SIYOMA Rent Reminder Test','This is a test of the SIYOMA rent reminder alarm.',sound,vibration);
      alert('Test reminder scheduled for about 1 minute from now.');
    }else{
      alert('Notifications are not available on this build.');
    }
  }catch(e){alert('Unable to test notifications on this device.');}
}

function scheduleAllRentReminders(){
  if(!window.AndroidBridge||!AndroidBridge.scheduleRentReminder)return;
  if(data.settings.remindersEnabled===false){
    AndroidBridge.clearRentReminders();
    return;
  }
  AndroidBridge.clearRentReminders();
  const time=data.settings.reminderTime||'08:00';
  const sound=data.settings.reminderSound!==false;
  const vibration=data.settings.reminderVibration!==false;
  const offsets=[
    {days:7,label:'7 days before'},
    {days:3,label:'3 days before'},
    {days:1,label:'1 day before'},
    {days:0,label:'Due today'},
    {days:-1,label:'Overdue'}
  ];
  data.tenants.filter(t=>t.status!=='moved'&&t.due).forEach(t=>{
    const due=new Date(t.due+'T00:00:00');
    offsets.forEach(o=>{
      const d=new Date(due);
      d.setDate(d.getDate()-o.days);
      const reminderDate=d.toISOString().slice(0,10);
      if(new Date(reminderDate+'T'+time+':00').getTime()<=Date.now())return;
      const unit=unitName(t.unitId);
      const title=o.days<0?'🔴 Rent Overdue':(o.days===0?'💳 Rent Due Today':'🔔 Rent Reminder');
      const message=`${t.name||'Tenant'} — Unit ${unit||''}: ${o.label}. Rent: ${money(t.rent)}.`;
      AndroidBridge.scheduleRentReminder(
        t.id,
        t.name||'Tenant',
        unit||'',
        t.due,
        reminderDate,
        time,
        title,
        message,
        sound,
        vibration
      );
    });
  });
}

function saveSettings(){data.settings.landlordName=document.getElementById('landlordName').value.trim();data.settings.landlordPhone=document.getElementById('landlordPhone').value.trim();data.settings.remindersEnabled=document.getElementById('remindersEnabled').checked;data.settings.reminderSound=document.getElementById('reminderSound').checked;data.settings.reminderVibration=document.getElementById('reminderVibration').checked;data.settings.reminderTime=document.getElementById('reminderTime').value||'08:00';save();scheduleAllRentReminders();alert('Settings saved. Rent reminders updated.')}
function clearData(){if(confirm('Permanently delete all properties, units, tenants, payments and expenses?')){data={properties:[],units:[],tenants:[],payments:[],expenses:[],settings:{landlordName:'',landlordPhone:'',pin:'',securityInitialized:false,subscriberEmail:''}};save();showScreen('dashboard')}}
function renderAll(){ensurePaymentModel();populatePropertySelectors();renderDashboard();renderProperties();renderUnits();renderTenants();renderPayments();renderReports();renderExpenses();initSecurity();syncNativePaymentMatchers()}

/* ========================= SIYOMA V3.2 PAYMENT ENGINE ========================= */
const PAYMENT_CATEGORIES=['Rent','Water','Electricity','Maintenance','Service Charge','Deposit','Arrears','Refund/Adjustment','Other'];
const PAYMENT_STATES=['pending_allocation','unmatched','partially_allocated','allocated','unallocated','reversed'];
function addLedgerPayment(tx,tenantId,amount,period,method,ref,note,fromDetected=false){
  const duplicate=data.payments.some(p=>p.sourceTransactionId===tx.id&&p.tenantId===tenantId&&p.period===period&&Number(p.amount||0)===Number(amount||0)&&!p.reversalOf);
  if(duplicate)return;
  data.payments.push({id:pid(),tenantId,amount:Number(amount),date:String(tx.dateTime||todayISO()).slice(0,10),period,method:method||'M-Pesa',ref:ref||'',note:note||'',sourceTransactionId:fromDetected?tx.id:null,createdAt:new Date().toISOString()});
}
function normalizePhone(v){let s=String(v||'').replace(/\D/g,'');if(s.startsWith('254'))return '0'+s.slice(3);if(s.startsWith('7'))return '0'+s;return s}
function normalizeName(v){return String(v||'').trim().toLowerCase().replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ')}
function currentPeriod(){return todayISO().slice(0,7)}
function periodRentPaid(t,period){return data.payments.filter(p=>p.tenantId===t.id&&(p.period||String(p.date||'').slice(0,7))===period&&!p.reversalOf).reduce((a,p)=>a+Number(p.amount||0),0)}
function paymentIntentFor(t,period){return data.paymentIntents.find(i=>i.tenantId===t.id&&i.period===period&&i.status==='open')}
function ensurePaymentIntent(t,period=currentPeriod()){
  if(!t||t.status==='moved'||Number(t.rent||0)<=0)return null;
  if((t.due||'9999-12-31')>todayISO())return null;
  if(periodRentPaid(t,period)>=Number(t.rent||0))return null;
  let existing=paymentIntentFor(t,period); if(existing)return existing;
  const intent={id:pid(),tenantId:t.id,period,amount:Number(t.rent||0),purpose:'Rent',createdAt:new Date().toISOString(),status:'open',source:'system'};
  data.paymentIntents.push(intent); return intent;
}
function allocationTotal(tx){return (tx.allocations||[]).reduce((a,x)=>a+Number(x.amount||0),0)}
function remainingTransactionAmount(tx){return Math.max(0,Number(tx.amount||0)-allocationTotal(tx))}
function audit(tx,action,details){data.paymentAudit.push({id:pid(),transactionId:tx.id,action,details:details||'',at:new Date().toISOString()})}
function allocationLedger(tx){return data.paymentAllocations.filter(a=>a.transactionId===tx.id&&!a.reversalOf)}
function transactionFingerprint(tx){return [tx.mpesaCode||'',normalizePhone(tx.payerPhone||''),Number(tx.amount||0).toFixed(2),String(tx.dateTime||'')].join('|').toLowerCase()}
function tenantMatchForTransaction(tx){
  const phone=normalizePhone(tx.payerPhone||'');
  const exact=data.tenants.filter(t=>t.status!=='moved'&&phone&&normalizePhone(t.mpesaNumber)===phone);
  if(exact.length===1)return {tenant:exact[0],reason:'Registered M-PESA number matched exactly.',confidence:'strong',matchType:'phone'};
  if(exact.length>1)return {tenant:null,reason:'The payer number is registered to more than one active tenant.',confidence:'ambiguous',matchType:'ambiguous_phone'};
  const byName=normalizeName(tx.payerName||'');
  if(byName){
    const candidates=data.tenants.filter(t=>t.status!=='moved'&&normalizeName(t.name)===byName);
    if(candidates.length===1)return {tenant:candidates[0],reason:'Payer name matched uniquely; phone number was unavailable.',confidence:'moderate',matchType:'name'};
    if(candidates.length>1)return {tenant:null,reason:'Multiple active tenants have the same payer name.',confidence:'ambiguous',matchType:'ambiguous_name'};
  }
  return {tenant:null,reason:'No unique registered payer could be established.',confidence:'unmatched',matchType:'none'};
}
function reconcileTransaction(tx){
  tx.amount=Number(tx.amount||0); tx.allocations=Array.isArray(tx.allocations)?tx.allocations:[];
  tx.remainingAmount=remainingTransactionAmount(tx);
  const m=tenantMatchForTransaction(tx);
  tx.tenantId=m.tenant?.id||null; tx.matchType=m.matchType; tx.matchReason=m.reason;
  if(!m.tenant){tx.confidence=m.confidence==='ambiguous'?'ambiguous':'unmatched';tx.suggestedCategory='Other';tx.suggestedPeriod='';tx.suggestedAmount=0;tx.status=tx.remainingAmount<=0?'allocated':(tx.status==='unallocated'?'unallocated':'unmatched');return tx}
  const t=m.tenant,period=currentPeriod(),rent=Number(t.rent||0),paid=periodRentPaid(t,period),outstanding=Math.max(0,rent-paid);
  const intent=paymentIntentFor(t,period)||ensurePaymentIntent(t,period);
  tx.suggestedPeriod=period;tx.suggestedCategory='Rent';tx.paymentIntentId=intent?.id||null;tx.suggestedAmount=Math.min(tx.remainingAmount,outstanding);
  const amount=tx.amount;
  if(outstanding<=0){tx.confidence='ambiguous';tx.matchReason='Tenant identified, but the current rent obligation is already covered. Another purpose must be confirmed.';tx.suggestedAmount=0}
  else if(intent&&Number(intent.amount||0)===amount&&intent.status==='open'){tx.confidence='very_high';tx.matchReason='Registered tenant + open rent payment intent + exact expected amount.'}
  else if(amount===outstanding){tx.confidence='strong';tx.matchReason='Registered tenant + exact outstanding rent balance.'}
  else if(amount<outstanding){tx.confidence='strong';tx.matchReason='Registered tenant + amount is below outstanding rent; partial rent payment is possible.'}
  else if(amount>outstanding){tx.confidence='moderate';tx.matchReason='Registered tenant + amount exceeds outstanding rent; excess must be allocated separately.'}
  else {tx.confidence='ambiguous';tx.matchReason='Tenant identified but transaction purpose/amount needs confirmation.'}
  tx.status=tx.remainingAmount<=0?'allocated':(allocationTotal(tx)>0?'partially_allocated':'pending_allocation'); return tx;
}
function ensurePaymentModel(){
  data.paymentTransactions=data.paymentTransactions||[]; data.paymentIntents=data.paymentIntents||[]; data.paymentAudit=data.paymentAudit||[]; data.paymentAllocations=data.paymentAllocations||[];
  data.tenants.forEach(t=>{t.paymentMethod=t.paymentMethod||'M-PESA';t.mpesaNumber=t.mpesaNumber||'';t.bankName=t.bankName||'';t.bankAccountNumber=t.bankAccountNumber||''});
  data.paymentTransactions.forEach(tx=>{tx.allocations=Array.isArray(tx.allocations)?tx.allocations:[];tx.sourceFingerprint=tx.sourceFingerprint||transactionFingerprint(tx);tx.remainingAmount=remainingTransactionAmount(tx);if(!tx.status)tx.status=tx.remainingAmount<=0?'allocated':'pending_allocation'});
  // Migrate legacy embedded allocations into the append-only allocation ledger exactly once.
  data.paymentTransactions.forEach(tx=>{
    const existing=data.paymentAllocations.filter(a=>a.transactionId===tx.id).length;
    if(!existing&&tx.allocations.length){tx.allocations.forEach(a=>data.paymentAllocations.push(Object.assign({},a,{transactionId:tx.id,migrated:true})));}
  });
}
function runReconciliationCheck(){let changed=0;data.paymentTransactions.forEach(tx=>{if(['pending_allocation','unmatched','partially_allocated'].includes(tx.status)){const before=JSON.stringify([tx.tenantId,tx.confidence,tx.suggestedAmount,tx.matchReason]);reconcileTransaction(tx);const after=JSON.stringify([tx.tenantId,tx.confidence,tx.suggestedAmount,tx.matchReason]);if(before!==after)changed++}});save();alert(changed+' pending transaction'+(changed===1?' was':'s were')+' re-evaluated.');}
function importNativeTransactions(silent=false){
  try{
    if(!window.AndroidBridge||!AndroidBridge.getPendingPaymentTransactions){if(!silent)alert('Native M-PESA detection is not available on this build.');return}
    const raw=AndroidBridge.getPendingPaymentTransactions(),arr=JSON.parse(raw||'[]');let added=0;
    arr.forEach(x=>{
      const fp=transactionFingerprint(x); const duplicate=data.paymentTransactions.some(t=>(x.mpesaCode&&t.mpesaCode&&t.mpesaCode.toUpperCase()===x.mpesaCode.toUpperCase())||(t.sourceFingerprint&&t.sourceFingerprint===fp));
      if(duplicate){AndroidBridge.clearPendingPaymentTransaction?.(x.id);return}
      const tx=Object.assign({},x,{sourceFingerprint:fp,status:'pending_allocation',allocations:[]});reconcileTransaction(tx);data.paymentTransactions.push(tx);audit(tx,'detected','Original transaction captured from native M-PESA SMS source.');added++;AndroidBridge.clearPendingPaymentTransaction?.(x.id);
    });
    if(added)save();else renderAll(); if(added&&!silent)alert(added+' payment transaction'+(added===1?'':'s')+' imported for review.');
  }catch(e){if(!silent)alert('Unable to import detected payment transactions.');}
}
function importBankCsvFile(input){const f=input.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const lines=String(r.result||'').split(/\r?\n/).filter(Boolean);if(lines.length<2)throw new Error('CSV is empty');const headers=lines.shift().split(',').map(x=>x.trim().toLowerCase());const col=n=>headers.findIndex(h=>h===n||h.includes(n));const iRef=col('reference'),iAmt=col('amount'),iDate=col('date'),iName=col('name'),iPhone=col('phone'),iType=col('type');if(iAmt<0)throw new Error('CSV must contain an amount column');let added=0;lines.forEach(line=>{const cells=line.match(/(?:"(?:[^"]|"")*"|[^,])+/g)?.map(x=>x.replace(/^"|"$/g,'').replace(/""/g,'"'))||[];const amount=Number(String(cells[iAmt]||'').replace(/[^0-9.-]/g,''));if(!(amount>0))return;const tx={id:'bank_'+pid(),source:'bank_csv',mpesaCode:iRef>=0?cells[iRef]||'':'',payerName:iName>=0?cells[iName]||'':'',payerPhone:iPhone>=0?cells[iPhone]||'':'',amount,dateTime:iDate>=0?cells[iDate]||new Date().toISOString():new Date().toISOString(),transactionType:iType>=0?cells[iType]||'BANK_RECEIPT':'BANK_RECEIPT',originalStatus:'Imported from user-selected bank CSV',status:'pending_allocation',allocations:[]};tx.sourceFingerprint=transactionFingerprint(tx);if(!data.paymentTransactions.some(x=>x.sourceFingerprint===tx.sourceFingerprint)){reconcileTransaction(tx);data.paymentTransactions.push(tx);audit(tx,'imported','Bank transaction imported from user-selected CSV statement.');added++}});save();alert(added+' bank transaction'+(added===1?'':'s')+' imported for review.');input.value=''}catch(e){alert('Could not import bank CSV: '+e.message)}};r.readAsText(f)}
function transactionLabel(tx){const t=data.tenants.find(x=>x.id===tx.tenantId);return t?`${t.name} · Unit ${unitName(t.unitId)}`:(tx.payerName||'Unmatched payer')}
function confidenceLabel(c){return c==='very_high'?'VERY STRONG':c==='strong'?'STRONG':c==='moderate'?'MODERATE':c==='unmatched'?'UNMATCHED':'AMBIGUOUS'}
function pendingTransactions(){return data.paymentTransactions.filter(t=>['pending_allocation','unmatched','partially_allocated'].includes(t.status)).slice().reverse()}
function renderPendingPayments(){
  const arr=pendingTransactions();setText('pendingCount',arr.length);setText('paymentNeedsReview',arr.length);setText('paymentUnallocatedValue',money(arr.reduce((a,x)=>a+remainingTransactionAmount(x),0)));const today=todayISO();setText('paymentConfirmedToday',money(data.payments.filter(p=>p.date===today&&!p.reversalOf).reduce((a,p)=>a+Number(p.amount||0),0)));const el=document.getElementById('pendingPaymentList');if(!el)return;
  el.innerHTML=arr.length?arr.map(tx=>{const t=data.tenants.find(x=>x.id===tx.tenantId),suggested=t&&tx.suggestedAmount>0?`Possible match: ${esc(tx.suggestedPeriod||currentPeriod())} rent · ${money(tx.suggestedAmount)}`:'No safe rent allocation was identified.';const state=tx.status==='unmatched'?'UNMATCHED':tx.status==='partially_allocated'?'PARTIALLY ALLOCATED':'PENDING CONFIRMATION';return `<div class="item paymentReview"><div style="flex:1"><div class="reviewHeader"><div><b>${esc(transactionLabel(tx))}</b><div class="meta">${esc(tx.mpesaCode||'No reference')} · ${esc(tx.dateTime||tx.detectedAt||'')} · ${esc(tx.source||'')}</div></div><span class="confidence">${confidenceLabel(tx.confidence)}</span></div><p class="meta">${esc(state)} · ${suggested}<br>${esc(tx.matchReason||'Review the transaction purpose before posting.')}</p><div class="actionRow"><button class="miniAction primaryAction" onclick="reviewTransaction('${tx.id}')">Review & Allocate</button><button class="miniAction dangerAction" onclick="leaveUnallocated('${tx.id}')">Leave unallocated</button></div></div><div class="amount">${money(tx.amount)}<div class="meta">Remaining ${money(remainingTransactionAmount(tx))}</div></div></div>`}).join(''):'<div class="panel empty">No payments are waiting for review. Confirmed transactions appear only after allocation.</div>';
  renderAllTransactions(); renderAllocationLedger();
}
function renderPaymentAttention(){const el=document.getElementById('paymentAttentionList');if(!el)return;const arr=pendingTransactions().slice(0,5);el.innerHTML=arr.length?arr.map(tx=>`<div class="item"><div><b>${esc(transactionLabel(tx))}</b><div class="meta">${esc(tx.matchReason||'Payment requires review')}</div></div><div class="amount">${money(tx.amount)}<button class="textbtn" onclick="showScreen('payments');reviewTransaction('${tx.id}')">Review</button></div></div>`).join(''):'No pending payment reviews.'}
function renderPayments(){const arr=[...data.payments].filter(p=>!p.reversalOf).reverse(),el=document.getElementById('paymentList');if(!el)return;el.innerHTML=arr.length?arr.map(p=>{let t=data.tenants.find(x=>x.id===p.tenantId);return `<div class="item"><div><b>${esc(t?.name||'Unknown tenant')}</b><div class="meta">${esc(p.date)} · ${esc(p.period||'')} · ${esc(p.method)}${p.ref?' · Ref '+esc(p.ref):''}${p.sourceTransactionId?' · Detected transaction':''}</div></div><div class="amount paid">${money(p.amount)}<div class="actionRow"><button class="textbtn" onclick="receipt('${p.id}')">Receipt</button><button class="textbtn" onclick="editPayment('${p.id}')">Edit</button></div></div></div>`}).join(''):'<div class="panel empty">No confirmed rent payments in the ledger yet.</div>';renderPendingPayments()}
function renderAllTransactions(){const el=document.getElementById('allTransactionList');if(!el)return;const arr=[...data.paymentTransactions].reverse();el.innerHTML=arr.length?arr.map(tx=>{const state=tx.status==='allocated'?'allocated':tx.status==='unallocated'?'unallocated':tx.status==='reversed'?'reversed':tx.status==='partially_allocated'?'partial':'pending';const alloc=allocationTotal(tx);return `<div class="item"><div style="flex:1"><b>${esc(transactionLabel(tx))}</b><div class="meta">${esc(tx.mpesaCode||'No reference')} · ${esc(tx.dateTime||'')} · ${esc(tx.payerPhone||'')}</div><div class="meta"><span class="transactionState ${state}">${esc(state.toUpperCase())}</span> ${alloc?`Allocated ${money(alloc)} · Remaining ${money(remainingTransactionAmount(tx))}`:''}</div></div><div class="amount">${money(tx.amount)}<button class="textbtn" onclick="reviewTransaction('${tx.id}')">View</button></div></div>`}).join(''):'<div class="panel empty">No detected transactions yet.</div>'}
function renderAllocationLedger(){const el=document.getElementById('allocationLedgerList');if(!el)return;const arr=[...data.paymentAllocations].filter(a=>!a.reversalOf).reverse();el.innerHTML=arr.length?arr.map(a=>{const t=data.tenants.find(x=>x.id===a.tenantId),tx=data.paymentTransactions.find(x=>x.id===a.transactionId);return `<div class="item"><div><b>${esc(a.category)}</b><div class="meta">${esc(t?.name||'Unassigned')} · ${esc(a.period||'No period')} · ${esc(a.at||'')}</div><div class="meta">Source ${esc(tx?.mpesaCode||tx?.source||'Transaction')}</div></div><div class="amount paid">${money(a.amount)}</div></div>`}).join(''):'<div class="panel empty">No accounting allocations yet.</div>'}
function setPaymentTab(tab){document.getElementById('tabPending')?.classList.toggle('active',tab==='pending');document.getElementById('tabLedger')?.classList.toggle('active',tab==='ledger');document.getElementById('tabAllocations')?.classList.toggle('active',tab==='allocations');document.getElementById('tabTransactions')?.classList.toggle('active',tab==='transactions');document.getElementById('pendingPaymentSection')?.classList.toggle('hiddenSection',tab!=='pending');document.getElementById('ledgerPaymentSection')?.classList.toggle('hiddenSection',tab!=='ledger');document.getElementById('allocationLedgerSection')?.classList.toggle('hiddenSection',tab!=='allocations');document.getElementById('allTransactionsSection')?.classList.toggle('hiddenSection',tab!=='transactions')}
function reviewTransaction(id){
  const tx=data.paymentTransactions.find(x=>x.id===id);if(!tx)return;const t=data.tenants.find(x=>x.id===tx.tenantId),remaining=remainingTransactionAmount(tx),auditRows=data.paymentAudit.filter(a=>a.transactionId===id).slice().reverse();
  const rows=(tx.allocations||[]).map(a=>`<div class="allocationRow"><span>${esc(a.category)}${a.period?' · '+esc(a.period):''}</span><b>${money(a.amount)}</b></div>`).join('');
  document.getElementById('viewTitle').textContent='Payment Review';document.getElementById('viewBody').innerHTML=`<div class="reviewGrid"><div class="panel"><div class="reviewHeader"><div><b>${esc(transactionLabel(tx))}</b><div class="meta">${esc(tx.mpesaCode||'')} · ${esc(tx.dateTime||'')}</div></div><div class="amount">${money(tx.amount)}</div></div><p><b>Original transaction</b><br>Payer: ${esc(tx.payerName||'Unknown')}<br>Number: ${esc(tx.payerPhone||'Unknown')}<br>Source: ${esc(tx.source||'Unknown')}<br>Original status: ${esc(tx.originalStatus||'Completed/valid as parsed')}<br>Fingerprint: <span class="meta">${esc(tx.sourceFingerprint||'')}</span></p><p><b>SIYOMA assessment</b><br>${esc(tx.matchReason||'No assessment')}<br>Confidence: <b>${confidenceLabel(tx.confidence)}</b><br>Suggested rent: <b>${money(tx.suggestedAmount||0)}</b></p></div>
  <div class="panel"><h3>Allocate transaction</h3><p class="meta">The original transaction cannot be edited here. Add accounting allocations against it. You may split one transaction across several purposes.</p><div id="allocationRows"></div><div class="allocationSummary"><b>Remaining to allocate</b><strong id="allocationRemaining">${money(remaining)}</strong></div><button class="secondaryBtn" onclick="addAllocationRow('${id}')">＋ Add allocation</button><div class="actionRow"><button class="miniAction primaryAction" onclick="saveAllocationRows('${id}')">Confirm allocations</button><button class="miniAction dangerAction" onclick="leaveUnallocated('${id}')">Leave remaining unallocated</button></div></div></div><div class="panel"><h3>Existing allocations</h3>${rows||'<p class="meta">Nothing has been allocated from this transaction yet.</p>'}<p><b>Remaining:</b> ${money(remaining)}</p></div><div class="panel"><h3>Audit trail</h3>${auditRows.length?auditRows.map(a=>`<div class="meta">${esc(a.at)} · <b>${esc(a.action)}</b> · ${esc(a.details||'')}</div>`).join(''):'<p class="meta">No audit events yet.</p>'}</div>`;
  document.getElementById('viewModal').classList.add('show');const suggested=tx.suggestedAmount>0?tx.suggestedAmount:0;addAllocationRow(id,tx.tenantId||'',suggested,'Rent',tx.suggestedPeriod||currentPeriod());
}
function allocationTenantOptions(selected){return data.tenants.filter(x=>x.status!=='moved').map(x=>`<option value="${x.id}" ${x.id===selected?'selected':''}>${esc(x.name)} · Unit ${esc(unitName(x.unitId))}</option>`).join('')}
function addAllocationRow(txId,tenantId='',amount=0,category='Other',period=''){const host=document.getElementById('allocationRows');if(!host)return;const row=document.createElement('div');row.className='allocationEditor';row.dataset.tx=txId;row.innerHTML=`<div class="allocationGrid"><label class="fieldLabel">Tenant<select class="allocTenant">${allocationTenantOptions(tenantId)}</select></label><label class="fieldLabel">Purpose<select class="allocCategory">${PAYMENT_CATEGORIES.map(c=>`<option ${c===category?'selected':''}>${c}</option>`).join('')}</select></label><label class="fieldLabel allocPeriodWrap">Rent period<input class="allocPeriod" type="month" value="${esc(period||currentPeriod())}"></label><label class="fieldLabel">Amount<input class="allocAmount" type="number" min="0" step="0.01" value="${Number(amount||0)}"></label></div><div class="actionRow"><button class="textbtn dangerText" onclick="this.closest('.allocationEditor').remove();updateAllocationSummary('${txId}')">Remove allocation row</button></div>`;host.appendChild(row);row.querySelector('.allocCategory').addEventListener('change',()=>{row.querySelector('.allocPeriodWrap').style.display=row.querySelector('.allocCategory').value==='Rent'?'block':'none';updateAllocationSummary(txId)});row.querySelector('.allocAmount').addEventListener('input',()=>updateAllocationSummary(txId));row.querySelector('.allocPeriodWrap').style.display=category==='Rent'?'block':'none';updateAllocationSummary(txId)}
function updateAllocationSummary(txId){const tx=data.paymentTransactions.find(x=>x.id===txId),host=document.getElementById('allocationRows');if(!tx||!host)return;const used=[...host.querySelectorAll('.allocAmount')].reduce((a,e)=>a+Math.max(0,Number(e.value||0)),0);const remaining=remainingTransactionAmount(tx);const el=document.getElementById('allocationRemaining');if(el){const left=remaining-used;el.textContent=money(left);el.style.color=left<0?'#b13b3b':''}}
function saveAllocationRows(id){const tx=data.paymentTransactions.find(x=>x.id===id),host=document.getElementById('allocationRows');if(!tx||!host)return;const baseRemaining=remainingTransactionAmount(tx);const rows=[...host.querySelectorAll('.allocationEditor')].map(row=>({tenantId:row.querySelector('.allocTenant')?.value||'',category:row.querySelector('.allocCategory')?.value||'Other',period:row.querySelector('.allocPeriod')?.value||'',amount:Number(row.querySelector('.allocAmount')?.value||0)})).filter(x=>x.amount>0);if(!rows.length){alert('Add at least one allocation.');return}const sum=rows.reduce((a,x)=>a+x.amount,0);if(sum>baseRemaining+0.0001){alert(`Allocations total ${money(sum)}, but only ${money(baseRemaining)} remains.`);return}for(const r of rows){const t=data.tenants.find(x=>x.id===r.tenantId);if(!t){alert('Every allocation must have a tenant.');return}if(r.category==='Rent'){if(!r.period){alert('Rent allocations require a rent period.');return}const outstanding=Math.max(0,Number(t.rent||0)-periodRentPaid(t,r.period));if(r.amount>outstanding+0.0001){alert(`${t.name} has only ${money(outstanding)} outstanding for ${r.period}.`);return}}}
  rows.forEach(r=>{const t=data.tenants.find(x=>x.id===r.tenantId);const allocation={id:pid(),transactionId:tx.id,tenantId:t.id,category:r.category,period:r.category==='Rent'?r.period:null,amount:r.amount,note:'Confirmed through SIYOMA payment review',at:new Date().toISOString()};data.paymentAllocations.push(allocation);tx.allocations.push(Object.assign({},allocation));if(r.category==='Rent'){addLedgerPayment(tx,t.id,r.amount,r.period,'M-Pesa',tx.mpesaCode,'Confirmed from detected transaction',true);const intent=paymentIntentFor(t,r.period);if(intent&&periodRentPaid(t,r.period)>=Number(intent.amount||0))intent.status='fulfilled'}audit(tx,'allocation_confirmed',`${r.category} · ${t.name} · ${r.amount}${r.period?' · '+r.period:''}`)});
  tx.remainingAmount=remainingTransactionAmount(tx);tx.status=tx.remainingAmount<=0?'allocated':'partially_allocated';tx.reviewedAt=new Date().toISOString();if(tx.remainingAmount<=0&&tx.paymentIntentId){const i=data.paymentIntents.find(x=>x.id===tx.paymentIntentId);if(i)i.status='fulfilled'}save();closeModal('viewModal');showScreen('payments');setPaymentTab(tx.remainingAmount>0?'pending':'transactions');
}
function leaveUnallocated(id){const tx=data.paymentTransactions.find(x=>x.id===id);if(!tx)return;if(!confirm('Leave this transaction unallocated? It will remain in original transaction history and will not affect rent balances.'))return;tx.status='unallocated';tx.reviewedAt=new Date().toISOString();tx.remainingAmount=remainingTransactionAmount(tx);audit(tx,'left_unallocated','User explicitly left the remaining transaction amount unallocated.');if(window.AndroidBridge&&AndroidBridge.clearPendingPaymentTransaction)AndroidBridge.clearPendingPaymentTransaction(tx.id);save();closeModal('viewModal');showScreen('payments');setPaymentTab('transactions')}
function createPaymentIntent(tenantId){const t=data.tenants.find(x=>x.id===tenantId);if(!t)return;const period=currentPeriod(),existing=paymentIntentFor(t,period);if(existing){alert('An open rent payment intent already exists for this tenant and period.');return}const intent={id:pid(),tenantId,period,amount:Number(t.rent||0),purpose:'Rent',createdAt:new Date().toISOString(),status:'open',source:'manual'};data.paymentIntents.push(intent);audit({id:intent.id},'intent_created',`${t.name} · ${period} · ${intent.amount}`);save();alert(`Payment intent created for ${t.name}: ${money(intent.amount)} rent for ${period}.`)}
function viewTenant(id){let t=data.tenants.find(x=>x.id===id),u=data.units.find(x=>x.id===t?.unitId),b=tenantBalance(t);if(!t)return;const period=currentPeriod(),intent=paymentIntentFor(t,period);document.getElementById('viewTitle').textContent=t.name;document.getElementById('viewBody').innerHTML=`${t.image?`<img class="propertyImg" src="${t.image}">`:''}<p><b>Unit:</b> ${esc(u?.number||'-')}<br><b>Property:</b> ${esc(propertyName(t.propertyId))}<br><b>Phone:</b> ${esc(t.phone||'-')}<br><b>Monthly rent:</b> ${money(t.rent)}<br><b>Payment method:</b> ${esc(t.paymentMethod||'M-PESA')}<br><b>M-PESA number:</b> ${esc(t.mpesaNumber||'-')}<br><b>Bank:</b> ${esc(t.bankName||'-')} · ${esc(t.bankAccountNumber||'-')}<br><b>Balance:</b> ${money(b)}<br><b>Status:</b> ${t.status==='moved'?'Moved Out':tenantStatus(t).toUpperCase()}<br><b>Move-In:</b> ${esc(t.moveIn||'-')}<br><b>First due:</b> ${esc(t.due||'-')}<br><b>Next due:</b> ${esc(nextDueDate(t))}</p><div class="panel subtle"><b>Payment intent</b><p class="meta">${intent?`Open intent: ${money(intent.amount)} · ${esc(intent.period)} · Rent`:'No open rent intent for '+period+'. An intent makes a later matching transaction a stronger match.'}</p><button class="secondaryBtn" onclick="createPaymentIntent('${t.id}')">${intent?'Create later intent':'Create current rent intent'}</button></div><div class="quick"><button onclick="whatsapp('${t.id}')">WhatsApp</button><button onclick="editTenant('${t.id}')">Edit</button>${t.status!=='moved'?`<button onclick="moveOut('${t.id}')">Move out</button>`:''}<button onclick="closeModal('viewModal')">Close</button></div><h3>Payment history</h3>${data.payments.filter(p=>p.tenantId===id).reverse().map(p=>`<div class="item"><span>${esc(p.date)} · ${esc(p.period||'')} · ${esc(p.method)}</span><b class="paid">${money(p.amount)}</b></div>`).join('')||'<p class="meta">No confirmed payments yet.</p>'}`;document.getElementById('viewModal').classList.add('show')}
function editTenant(id){let t=data.tenants.find(x=>x.id===id);if(!t)return;closeModal('viewModal');document.getElementById('tenantModalTitle').textContent='Edit Tenant';tName.value=t.name;tPhone.value=t.phone;tRent.value=t.rent;tMoveIn.value=t.moveIn;tDue.value=t.due;tNote.value=t.note||'';tPaymentMethod.value=t.paymentMethod||'M-PESA';tMpesaNumber.value=t.mpesaNumber||'';tBankName.value=t.bankName||'';tBankAccount.value=t.bankAccountNumber||'';populateUnitSelect();tUnit.value=t.unitId;document.getElementById('tenantForm').dataset.edit=id;toggleTenantPaymentFields();document.getElementById('tenantModal').classList.add('show')}
function toggleTenantPaymentFields(){const bank=tPaymentMethod.value==='Bank';document.getElementById('mpesaFields')?.classList.toggle('hiddenSection',bank);document.getElementById('bankFields')?.classList.toggle('hiddenSection',!bank)}
function openModal(id){if(id==='unitModal')populateUnitProperty();if(id==='tenantModal'){populateUnitSelect();if(!document.getElementById('tenantForm').dataset.edit){document.getElementById('tenantModalTitle').textContent='Add Tenant';document.getElementById('tenantForm').reset();tPaymentMethod.value='M-PESA';tMoveIn.value=todayISO();tDue.value=todayISO();toggleTenantPaymentFields()}}if(id==='paymentModal'){populateTenantSelect();pDate.value=todayISO();pPeriod.value=currentPeriod()}if(id==='expenseModal')populateExpenseProperty();document.getElementById(id).classList.add('show')}
document.getElementById('tPaymentMethod').addEventListener('change',toggleTenantPaymentFields);
document.getElementById('tenantForm').onsubmit=async e=>{e.preventDefault();let edit=e.target.dataset.edit;if(edit){let t=data.tenants.find(x=>x.id===edit),nu=data.units.find(x=>x.id===tUnit.value),old=data.units.find(u=>u.id===t.unitId);if(!t||!nu)return;if(nu.id!==old?.id&&data.tenants.some(x=>x.status!=='moved'&&x.unitId===nu.id)){alert('That unit is already occupied.');return}t.name=tName.value.trim();t.phone=tPhone.value.trim();t.rent=Number(tRent.value);t.moveIn=tMoveIn.value;t.due=tDue.value;t.note=tNote.value.trim();t.paymentMethod=tPaymentMethod.value;t.mpesaNumber=tMpesaNumber.value.trim();t.bankName=tBankName.value.trim();t.bankAccountNumber=tBankAccount.value.trim();if(nu.id!==old?.id){if(old)old.tenantId=null;nu.tenantId=t.id;t.unitId=nu.id;t.propertyId=nu.propertyId}let img=await addImage('tImage');if(img)t.image=img;delete e.target.dataset.edit;document.getElementById('tenantModalTitle').textContent='Add Tenant';save();e.target.reset();closeModal('tenantModal');showScreen('tenants');return}let u=data.units.find(x=>x.id===tUnit.value);if(!u||data.tenants.some(t=>t.status!=='moved'&&t.unitId===u.id)){alert('Please choose a vacant unit.');return}if(tPaymentMethod.value==='M-PESA'&&!tMpesaNumber.value.trim()){if(!confirm('No M-PESA number was entered. Continue?'))return}if(tPaymentMethod.value==='Bank'&&!tBankAccount.value.trim()){if(!confirm('No bank account number was entered. Continue?'))return}let t={id:pid(),name:tName.value.trim(),phone:tPhone.value.trim(),unitId:u.id,propertyId:u.propertyId,rent:Number(tRent.value||u.rent),moveIn:tMoveIn.value,due:tDue.value,image:await addImage('tImage'),note:tNote.value.trim(),status:'active',paymentMethod:tPaymentMethod.value,mpesaNumber:tMpesaNumber.value.trim(),bankName:tBankName.value.trim(),bankAccountNumber:tBankAccount.value.trim()};data.tenants.push(t);u.tenantId=t.id;save();e.target.reset();tPaymentMethod.value='M-PESA';toggleTenantPaymentFields();tDue.value=todayISO();tMoveIn.value=todayISO();closeModal('tenantModal');showScreen('tenants')}
function enableSmsDetection(){
  if(!(window.AndroidBridge&&AndroidBridge.requestSmsPermission)){alert('This build does not expose Android SMS detection.');return}
  openSmsPermissionExplanation();
}
function openSmsPermissionExplanation(){
  const m=document.getElementById('smsPermissionModal');
  if(m)m.classList.add('show');
}
function closeSmsPermissionExplanation(){document.getElementById('smsPermissionModal')?.classList.remove('show')}
function continueSmsPermission(){
  closeSmsPermissionExplanation();
  if(window.AndroidBridge&&AndroidBridge.requestSmsPermission){AndroidBridge.requestSmsPermission();}
}
function openSmsAppSettings(){if(window.AndroidBridge?.openAppSettings)AndroidBridge.openAppSettings()}
function onNativePermissionResult(type,granted){
  updateSmsPermissionStatus();
  if(type==='sms'&&!granted){
    const permanentlyDenied=window.AndroidBridge?.shouldOpenSmsSettings&&AndroidBridge.shouldOpenSmsSettings();
    if(permanentlyDenied) showSmsSettingsRecovery();
    else showSmsDeniedState();
    return;
  }
  if(type==='sms'&&granted){
    const nOk=window.AndroidBridge?.hasNotificationPermission?AndroidBridge.hasNotificationPermission():true;
    if(nOk){importNativeTransactions();alert('M-PESA SMS detection is now enabled on this device. SIYOMA will review eligible incoming transactions and will not automatically mark rent as paid.');}
  }
  if(type==='notifications'&&granted){updateSmsPermissionStatus();importNativeTransactions();alert('M-PESA detection and payment-review notifications are enabled.');}
  if(type==='notifications'&&!granted){updateSmsPermissionStatus();showNotificationPermissionInfo();}
}
function showSmsDeniedState(){
  const m=document.getElementById('smsPermissionDeniedModal');if(m)m.classList.add('show');
}
function showSmsSettingsRecovery(){
  const m=document.getElementById('smsPermissionSettingsModal');if(m)m.classList.add('show');
}
function showNotificationPermissionInfo(){
  const m=document.getElementById('notificationPermissionModal');if(m)m.classList.add('show');
}
function updateSmsPermissionStatus(){
  const el=document.getElementById('smsPermissionStatus');if(!el)return;
  const smsOk=window.AndroidBridge&&AndroidBridge.hasSmsPermission&&AndroidBridge.hasSmsPermission();
  const notifOk=window.AndroidBridge&&AndroidBridge.hasNotificationPermission?AndroidBridge.hasNotificationPermission():true;
  if(smsOk&&notifOk){el.textContent='Enabled';el.className='statusBadge enabled';}
  else if(smsOk){el.textContent='SMS enabled · notifications off';el.className='statusBadge attention';}
  else {el.textContent='Not enabled';el.className='statusBadge attention';}
  const detail=document.getElementById('smsPermissionDetail');
  if(detail){detail.innerHTML=smsOk?`<b>Device access:</b> SMS detection is enabled.${notifOk?' Notifications are enabled for payment-review alerts.':' Notifications are currently disabled; enable them for background review alerts.'}`:`<b>Device access:</b> Android SMS permission has not been granted. Tap <b>Enable M-PESA SMS detection</b> to begin the guided permission setup.`;}
  const btn=document.getElementById('smsSettingsButton');if(btn)btn.style.display=smsOk?'none':'inline-block';
}

function syncNativePaymentMatchers(){try{if(window.AndroidBridge&&AndroidBridge.setRegisteredMpesaNumbers){const active=data.tenants.filter(t=>t.status!=='moved'&&t.mpesaNumber).map(t=>({phone:normalizePhone(t.mpesaNumber),name:t.name||'',unit:unitName(t.unitId),rent:Number(t.rent||0)}));AndroidBridge.setRegisteredMpesaNumbers(JSON.stringify(active));AndroidBridge.setUnknownPaymentNotifications(data.settings.notifyUnknownPayments===true);AndroidBridge.setPaymentNotificationPrivacy(data.settings.paymentNotificationDetails!==false)}}catch(e){}}
function updateSmsPermissionStatus(){const el=document.getElementById('smsPermissionStatus');if(!el)return;const ok=window.AndroidBridge&&AndroidBridge.hasSmsPermission&&AndroidBridge.hasSmsPermission();el.textContent=ok?'Enabled':'Permission required';el.className='statusBadge '+(ok?'':'attention')}
function resumeNativePayments(){try{importNativeTransactions(true)}catch(e){}}
function openPaymentReviewFromNative(){importNativeTransactions(true);showScreen('payments');setPaymentTab('pending')}
function saveSettings(){data.settings.landlordName=document.getElementById('landlordName').value.trim();data.settings.landlordPhone=document.getElementById('landlordPhone').value.trim();data.settings.remindersEnabled=document.getElementById('remindersEnabled').checked;data.settings.reminderSound=document.getElementById('reminderSound').checked;data.settings.reminderVibration=document.getElementById('reminderVibration').checked;data.settings.reminderTime=document.getElementById('reminderTime').value||'08:00';data.settings.notifyUnknownPayments=document.getElementById('notifyUnknownPayments').checked;data.settings.paymentNotificationDetails=document.getElementById('paymentNotificationDetails').checked;save();scheduleAllRentReminders();if(window.AndroidBridge&&AndroidBridge.setPaymentNotificationPrivacy)AndroidBridge.setPaymentNotificationPrivacy(data.settings.paymentNotificationDetails);alert('Settings saved.')}

function clearData(){if(!confirm('Permanently delete all properties, units, tenants, payments, detected transactions and expenses?'))return;data={properties:[],units:[],tenants:[],payments:[],expenses:[],paymentTransactions:[],paymentIntents:[],paymentAudit:[],paymentAllocations:[],settings:{landlordName:'',landlordPhone:'',pin:'',securityInitialized:false,subscriberEmail:'',notifyUnknownPayments:false,paymentNotificationDetails:true}};save();showScreen('dashboard')}
function restoreData(e){let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let x=JSON.parse(r.result);if(!x.properties||!x.units||!x.tenants||!x.payments)throw 0;x.expenses=x.expenses||[];x.paymentTransactions=x.paymentTransactions||[];x.paymentIntents=x.paymentIntents||[];x.paymentAudit=x.paymentAudit||[];x.paymentAllocations=x.paymentAllocations||[];x.settings=Object.assign({landlordName:'',landlordPhone:'',pin:'',securityInitialized:false,subscriberEmail:'',notifyUnknownPayments:false,paymentNotificationDetails:true},x.settings||{});x.tenants.forEach(t=>{t.paymentMethod=t.paymentMethod||'M-PESA';t.mpesaNumber=t.mpesaNumber||'';t.bankName=t.bankName||'';t.bankAccountNumber=t.bankAccountNumber||''});if(confirm('Replace current data with this backup?')){data=x;save();alert('Backup restored successfully.')}}catch(err){alert('Invalid SIYOMA backup file.')}};r.readAsText(f)}
document.getElementById('today').textContent=new Date().toLocaleDateString('en-KE',{day:'numeric',month:'short',year:'numeric'});document.getElementById('pDate').value=todayISO();document.getElementById('pPeriod').value=todayISO().slice(0,7);document.getElementById('eDate').value=todayISO();document.getElementById('tDue').value=todayISO();document.getElementById('tMoveIn').value=todayISO();renderAll();showScreen('dashboard');setTimeout(async()=>{const active=await checkSubscription(true);if(active){scheduleAllRentReminders();await enforceAppSecurity();}await resumePendingSubscriptionVerification();},300);
