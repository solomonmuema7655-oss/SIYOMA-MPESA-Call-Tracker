package com.siyoma.tenanttracker;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.NotificationCompat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SmsTransactionReceiver extends BroadcastReceiver {
    private static final String PREFS="siyoma_sms_transactions";
    private static final String KEY="pending";
    private static final String CHANNEL="siyoma_payment_reviews";

    @Override public void onReceive(Context context, Intent intent) {
        if (!"android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) return;
        if (Build.VERSION.SDK_INT >= 23 && context.checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) return;
        try {
            Object[] pdus=(Object[])intent.getExtras().get("pdus");
            if(pdus==null)return;
            StringBuilder body=new StringBuilder(); String sender="";
            String format=intent.getStringExtra("format");
            for(Object pdu:pdus){
                android.telephony.SmsMessage sms=Build.VERSION.SDK_INT>=23
                    ? android.telephony.SmsMessage.createFromPdu((byte[])pdu,format)
                    : android.telephony.SmsMessage.createFromPdu((byte[])pdu);
                if(sms!=null){ if(sender.isEmpty())sender=sms.getOriginatingAddress(); body.append(sms.getMessageBody()).append(' '); }
            }
            String raw=body.toString().trim();
            Parsed p=parse(raw);
            if(p==null)return;
            JSONObject tx=new JSONObject();
            tx.put("id", "sms_"+System.currentTimeMillis()+"_"+Math.abs(raw.hashCode()));
            tx.put("source","mpesa_sms"); tx.put("mpesaCode",p.code); tx.put("payerPhone",p.phone); tx.put("payerName",p.name);
            tx.put("amount",p.amount); tx.put("dateTime",p.dateTime); tx.put("rawMessage",raw); tx.put("sender",sender); tx.put("transactionType",p.transactionType); tx.put("sourceWarning",p.sourceWarning); tx.put("originalStatus","received confirmation parsed");
            tx.put("status","pending_allocation"); tx.put("detectedAt",System.currentTimeMillis());
            store(context,tx);
            JSONObject matched=registeredTenant(context,p.phone);
            boolean unknown=p.phone.isEmpty() || matched==null;
            boolean notifyUnknown=context.getSharedPreferences("siyoma_payment_privacy",Context.MODE_PRIVATE).getBoolean("notifyUnknown",false);
            if(!unknown || notifyUnknown) notifyReview(context,p,matched);
        } catch(Exception ignored) {}
    }

    private static void store(Context c, JSONObject tx) throws Exception {
        SharedPreferences sp=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        JSONArray a=new JSONArray(sp.getString(KEY,"[]"));
        String code=tx.optString("mpesaCode");
        for(int i=0;i<a.length();i++) if(code.length()>0 && code.equalsIgnoreCase(a.getJSONObject(i).optString("mpesaCode"))) return;
        a.put(tx); sp.edit().putString(KEY,a.toString()).apply();
    }

    private static JSONObject registeredTenant(Context c,String phone){
        String raw=c.getSharedPreferences("siyoma_payment_privacy",Context.MODE_PRIVATE).getString("registeredMpesaNumbers","");
        String normalized=normalizePhone(phone);
        try {
            if(raw.trim().startsWith("[")){
                JSONArray a=new JSONArray(raw);
                for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(normalized.equals(normalizePhone(o.optString("phone"))))return o;}
            } else {
                for(String x:raw.split(",")) if(normalized.equals(normalizePhone(x))) return new JSONObject().put("phone",x);
            }
        } catch(Exception ignored) {}
        return null;
    }
    private static String normalizePhone(String v){
        String s=v==null?"":v.replaceAll("\\D","");
        if(s.startsWith("254"))return "0"+s.substring(3); if(s.startsWith("7"))return "0"+s; return s;
    }

    private static void notifyReview(Context c, Parsed p, JSONObject matched){
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Payment reviews",NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Notifications for detected M-PESA payments requiring review");
            ch.setSound(Settings.System.DEFAULT_NOTIFICATION_URI,new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION).build());
            nm.createNotificationChannel(ch);
        }
        Intent open=new Intent(c,MainActivity.class).setAction("com.siyoma.tenanttracker.REVIEW_PAYMENTS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi=PendingIntent.getActivity(c, (int)(System.currentTimeMillis()%100000), open, PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String title="SIYOMA Payment Review";
        boolean showDetails=c.getSharedPreferences("siyoma_payment_privacy",Context.MODE_PRIVATE).getBoolean("showDetails",true);
        String matchedName=matched==null?"":matched.optString("name","");
        String matchedRent=matched==null?"":matched.optString("rent","");
        String msg=showDetails
            ? ((matchedName.isEmpty()?(p.name.isEmpty()?"A payer":p.name):matchedName)+" sent KSh "+String.format(Locale.US,"%,.2f",p.amount)+". Possible match"+(matchedRent.isEmpty()?"":" to rent of KSh "+matchedRent)+" — tap to review.")
            : "New SIYOMA payment detected. Tap to review.";
        NotificationCompat.Builder b=new NotificationCompat.Builder(c,CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(msg).setStyle(new NotificationCompat.BigTextStyle().bigText(msg)).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi);
        nm.notify((int)(System.currentTimeMillis()%100000),b.build());
    }

    static class Parsed {
        String code="",phone="",name="",dateTime="",transactionType="RECEIVED",sourceWarning="";
        double amount;
    }

    static Parsed parse(String s){
        if(s==null)return null;
        String u=s.toUpperCase(Locale.ROOT);

        // SIYOMA only treats an INCOMING M-PESA confirmation as a candidate payment.
        // Outgoing "sent to", "paid to", withdrawals, airtime and failed messages are not rent receipts.
        if(!(u.contains("M-PESA")||u.contains("MPESA")||u.contains("CONFIRMED")))return null;
        if(u.contains("FAILED") || u.contains("REVERSED") || u.contains("REVERSAL"))return null;
        if(!(u.contains("YOU HAVE RECEIVED") || u.contains("RECEIVED KSH") || u.contains("RECEIVED KES")))return null;

        Matcher cm=Pattern.compile("\\b([A-Z0-9]{8,12})\\s*\\.?\\s*CONFIRMED\\b",Pattern.CASE_INSENSITIVE).matcher(s);
        if(!cm.find()) cm=Pattern.compile("\\b([A-Z0-9]{8,12})\\b").matcher(s);
        if(!cm.find())return null;

        Matcher am=Pattern.compile("received\\s+Ksh\\.?\\s*([0-9,]+(?:\\.[0-9]{1,2})?)",Pattern.CASE_INSENSITIVE).matcher(s);
        if(!am.find()) am=Pattern.compile("received\\s+KES\\.?\\s*([0-9,]+(?:\\.[0-9]{1,2})?)",Pattern.CASE_INSENSITIVE).matcher(s);
        if(!am.find())return null;

        Parsed p=new Parsed();
        p.code=cm.group(1).toUpperCase(Locale.ROOT);
        p.amount=Double.parseDouble(am.group(1).replace(",",""));

        // Current/common Safaricom format: "...received Ksh X from NAME [phone] on DATE..."
        Matcher from=Pattern.compile("from\\s+(.+?)(?:\\s+(?:on|at)\\s+|$)",Pattern.CASE_INSENSITIVE).matcher(s);
        if(from.find())p.name=from.group(1).trim();

        // Extract a phone independently because the payer name may contain spaces.
        Matcher pm=Pattern.compile("(\\+?2547\\d{8}|0?7\\d{8})").matcher(s);
        if(pm.find())p.phone=pm.group(1);

        // Remove the phone from the payer display name when it was included in the SMS.
        if(!p.name.isEmpty()&&!p.phone.isEmpty()){
            p.name=p.name.replace(p.phone,"").replaceAll("\\s{2,}"," ").trim();
        }

        Matcher dt=Pattern.compile("on\\s+(\\d{1,2}/\\d{1,2}/\\d{2,4})\\s+at\\s+(\\d{1,2}:\\d{2}(?::\\d{2})?\\s*(?:AM|PM)?)",Pattern.CASE_INSENSITIVE).matcher(s);
        if(dt.find())p.dateTime=dt.group(1)+" "+dt.group(2);
        if(p.dateTime.isEmpty())p.dateTime=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US).format(new Date());

        // SMS sender verification is evidence only. Never use it as accounting approval.
        String sender=u.contains("M-PESA")?"M-PESA":u.contains("SAFARICOM")?"SAFARICOM":"UNKNOWN";
        if(!sender.equals("M-PESA")&&!sender.equals("SAFARICOM"))p.sourceWarning="SMS sender could not be verified as M-PESA/Safaricom";
        return p;
    }

}
