package com.siyoma.tenanttracker;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.provider.Settings;
import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.print.PrintManager;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {
    private static final int FILE_CHOOSER=1001;
    private static final int CREATE_FILE=2001;
    private ValueCallback<Uri[]> fileCallback;
    private byte[] pendingBytes;
    private String pendingMime;
    private static final String REMINDER_PREFS = "siyoma_reminders";
    private static final String CHANNEL_ID = "siyoma_rent_reminders";

    private class AndroidBridge {
        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                try {
                    PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
                    pm.print("SIYOMA Rent Receipt", webView.createPrintDocumentAdapter("SIYOMA_Rent_Receipt"), null);
                } catch(Exception e) {
                    webView.evaluateJavascript("alert('Printing is not available on this device. You can use the Android share/save option instead.')", null);
                }
            });
        }

        @JavascriptInterface
        public void openExternalUrl(String url) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(i);
            } catch(Exception ignored) {}
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 5001);
        }

        @JavascriptInterface
        public void requestSmsPermission() {
            if (Build.VERSION.SDK_INT < 23) {
                notifyPermissionState("sms", true);
                return;
            }
            getSharedPreferences("siyoma_payment_privacy", Context.MODE_PRIVATE).edit().putBoolean("smsPermissionRequested", true).apply();
            if (checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED) {
                notifyPermissionState("sms", true);
                requestNotificationPermission();
                return;
            }
            requestPermissions(new String[]{Manifest.permission.RECEIVE_SMS}, 5002);
        }

        @JavascriptInterface
        public boolean hasSmsPermission() {
            return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public boolean hasNotificationPermission() {
            return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public boolean canOpenSmsSettings() {
            return Build.VERSION.SDK_INT >= 23;
        }

        @JavascriptInterface
        public boolean shouldOpenSmsSettings() {
            if (Build.VERSION.SDK_INT < 23 || hasSmsPermission()) return false;
            boolean requested = getSharedPreferences("siyoma_payment_privacy", Context.MODE_PRIVATE).getBoolean("smsPermissionRequested", false);
            return requested && !shouldShowRequestPermissionRationale(Manifest.permission.RECEIVE_SMS);
        }

        @JavascriptInterface
        public void openAppSettings() {
            try {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception ignored) {}
        }

        private void notifyPermissionState(String type, boolean granted) {
            runOnUiThread(() -> {
                if (webView != null) {
                    webView.evaluateJavascript("if(window.onNativePermissionResult){window.onNativePermissionResult('" + type + "'," + granted + ");}", null);
                }
            });
        }

        @JavascriptInterface
        public void setRegisteredMpesaNumbers(String csv) {
            getSharedPreferences("siyoma_payment_privacy", Context.MODE_PRIVATE).edit().putString("registeredMpesaNumbers", csv==null?"":csv).apply();
        }

        @JavascriptInterface
        public void setUnknownPaymentNotifications(boolean enabled) {
            getSharedPreferences("siyoma_payment_privacy", Context.MODE_PRIVATE).edit().putBoolean("notifyUnknown", enabled).apply();
        }

        @JavascriptInterface
        public void setPaymentNotificationPrivacy(boolean showDetails) {
            getSharedPreferences("siyoma_payment_privacy", Context.MODE_PRIVATE).edit().putBoolean("showDetails", showDetails).apply();
        }

        @JavascriptInterface
        public String getPendingPaymentTransactions() {
            try {
                android.content.SharedPreferences sp=getSharedPreferences("siyoma_sms_transactions",Context.MODE_PRIVATE);
                return sp.getString("pending","[]");
            } catch(Exception e) { return "[]"; }
        }

        @JavascriptInterface
        public void clearPendingPaymentTransaction(String id) {
            try {
                android.content.SharedPreferences sp=getSharedPreferences("siyoma_sms_transactions",Context.MODE_PRIVATE);
                JSONArray a=new JSONArray(sp.getString("pending","[]")); JSONArray out=new JSONArray();
                for(int i=0;i<a.length();i++){ JSONObject o=a.getJSONObject(i); if(!id.equals(o.optString("id"))) out.put(o); }
                sp.edit().putString("pending",out.toString()).apply();
            } catch(Exception ignored) {}
        }

        @JavascriptInterface
        public void clearRentReminders() {
            runOnUiThread(() -> ReminderScheduler.clear(MainActivity.this));
        }

        @JavascriptInterface
        public void scheduleRentReminder(String tenantId, String tenantName, String unit, String dueDate, String reminderDate, String time, String title, String message, boolean sound, boolean vibration) {
            runOnUiThread(() -> ReminderScheduler.schedule(MainActivity.this, tenantId, tenantName, unit, dueDate, reminderDate, time, title, message, sound, vibration));
        }

        @JavascriptInterface
        public void saveTextFile(String filename, String mime, String base64) {
            try {
                pendingBytes=Base64.decode(base64, Base64.DEFAULT);
                pendingMime=mime;
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_TITLE, filename);
                startActivityForResult(i, CREATE_FILE);
            } catch(Exception e) {
                webView.evaluateJavascript("alert('Unable to open the save dialog.')", null);
            }
        }
    }

    private WebView webView;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView=new WebView(this);
        WebViewAssetLoader loader=new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();

        webView.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){
                Uri u=r.getUrl(); String host=u.getHost();
                if(host!=null && (host.equals("wa.me")||host.endsWith("whatsapp.com")||host.equals("api.whatsapp.com"))){
                    try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}
                    return true;
                }
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(fileCallback!=null)fileCallback.onReceiveValue(null);
                fileCallback=cb;
                try{Intent i=params.createIntent();startActivityForResult(i,FILE_CHOOSER);return true;}
                catch(Exception e){fileCallback=null;return false;}
            }
        });

        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(),"AndroidBridge");
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        setContentView(webView);
        ReminderScheduler.createChannel(this);
        final boolean review=getIntent()!=null && "com.siyoma.tenanttracker.REVIEW_PAYMENTS".equals(getIntent().getAction());
        if(review) webView.postDelayed(() -> webView.evaluateJavascript("if(window.openPaymentReviewFromNative){window.openPaymentReviewFromNative();}", null), 1200);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent);
        if(intent!=null && "com.siyoma.tenanttracker.REVIEW_PAYMENTS".equals(intent.getAction()) && webView!=null) webView.postDelayed(() -> webView.evaluateJavascript("if(window.openPaymentReviewFromNative){window.openPaymentReviewFromNative();}", null), 400);
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.postDelayed(() -> webView.evaluateJavascript(
                "if(window.resumePendingSubscriptionVerification){window.resumePendingSubscriptionVerification();}if(window.resumeNativePayments){window.resumeNativePayments();}if(window.updateSmsPermissionStatus){window.updateSmsPermissionStatus();}", null), 800);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 5002) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                notifyPermissionStateFromActivity("sms", true);
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 5001);
                } else {
                    notifyPermissionStateFromActivity("notifications", true);
                }
            } else {
                notifyPermissionStateFromActivity("sms", false);
            }
        } else if (requestCode == 5001) {
            boolean granted = Build.VERSION.SDK_INT < 33 || (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED);
            notifyPermissionStateFromActivity("notifications", granted);
        }
    }

    private void notifyPermissionStateFromActivity(String type, boolean granted) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript("if(window.onNativePermissionResult){window.onNativePermissionResult('" + type + "'," + granted + ");}", null);
        });
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_CHOOSER && fileCallback!=null){
            Uri[] r=null;
            if(resultCode==RESULT_OK&&data!=null){
                Uri u=data.getData(); if(u!=null)r=new Uri[]{u};
            }
            fileCallback.onReceiveValue(r);fileCallback=null;
        } else if(requestCode==CREATE_FILE){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingBytes!=null){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out!=null)out.write(pendingBytes);
                    webView.evaluateJavascript("alert('File saved successfully.')",null);
                }catch(Exception e){
                    webView.evaluateJavascript("alert('Could not save the file.')",null);
                }
            }
            pendingBytes=null;pendingMime=null;
        }
    }

    public static class ReminderScheduler {
        private static final int BASE_CODE = 700000;
        private static int code(String tenantId, String reminderDate, String time) {
            return BASE_CODE + Math.abs((tenantId + "|" + reminderDate + "|" + time).hashCode() % 100000);
        }
        static void createChannel(Context c) {
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Rent reminders", NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("Sound and vibration reminders for tenant rent due dates");
                ch.enableVibration(true);
                ch.setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI, new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION).build());
                ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
            }
        }
        static void clear(Context c) {
            android.content.SharedPreferences sp=c.getSharedPreferences(REMINDER_PREFS,Context.MODE_PRIVATE);
            String json=sp.getString("items","[]");
            try {
                JSONArray a=new JSONArray(json);
                AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
                for(int i=0;i<a.length();i++) {
                    JSONObject o=a.getJSONObject(i); String tid=o.optString("tenantId"), rd=o.optString("reminderDate"), time=o.optString("time");
                    Intent in=new Intent(c,RentReminderReceiver.class); in.setAction("com.siyoma.tenanttracker.RENT_REMINDER");
                    PendingIntent pi=PendingIntent.getBroadcast(c,code(tid,rd,time),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); am.cancel(pi);
                }
            } catch(Exception ignored) {}
            sp.edit().clear().apply();
        }
        static void schedule(Context c,String tenantId,String tenantName,String unit,String dueDate,String reminderDate,String time,String title,String message,boolean sound,boolean vibration) {
            try {
                createChannel(c);
                String[] parts=time.split(":"); Calendar cal=Calendar.getInstance(); cal.setTime(java.sql.Date.valueOf(reminderDate)); cal.set(Calendar.HOUR_OF_DAY,Integer.parseInt(parts[0])); cal.set(Calendar.MINUTE,Integer.parseInt(parts[1])); cal.set(Calendar.SECOND,0); cal.set(Calendar.MILLISECOND,0);
                long when=cal.getTimeInMillis(); if(when<=System.currentTimeMillis()) return;
                Intent in=new Intent(c,RentReminderReceiver.class); in.setAction("com.siyoma.tenanttracker.RENT_REMINDER");
                in.putExtra("title",title); in.putExtra("message",message); in.putExtra("sound",sound); in.putExtra("vibration",vibration); in.putExtra("tenantId",tenantId);
                PendingIntent pi=PendingIntent.getBroadcast(c,code(tenantId,reminderDate,time),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
                android.content.SharedPreferences sp=c.getSharedPreferences(REMINDER_PREFS,Context.MODE_PRIVATE); JSONArray a=new JSONArray(sp.getString("items","[]"));
                JSONObject o=new JSONObject(); o.put("tenantId",tenantId);o.put("tenantName",tenantName);o.put("unit",unit);o.put("dueDate",dueDate);o.put("reminderDate",reminderDate);o.put("time",time);o.put("title",title);o.put("message",message);o.put("sound",sound);o.put("vibration",vibration); a.put(o); sp.edit().putString("items",a.toString()).apply();
            } catch(Exception ignored) {}
        }
        static void rescheduleAll(Context c) {
            String json=c.getSharedPreferences(REMINDER_PREFS,Context.MODE_PRIVATE).getString("items","[]");
            try { JSONArray a=new JSONArray(json); c.getSharedPreferences(REMINDER_PREFS,Context.MODE_PRIVATE).edit().clear().apply(); for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);schedule(c,o.optString("tenantId"),o.optString("tenantName"),o.optString("unit"),o.optString("dueDate"),o.optString("reminderDate"),o.optString("time"),o.optString("title"),o.optString("message"),o.optBoolean("sound",true),o.optBoolean("vibration",true));}} catch(Exception ignored) {}
        }
    }

}
