const fs = require('fs');
const vm = require('vm');
const src = fs.readFileSync('app/src/main/assets/app.js','utf8');
const start = src.indexOf('/* ========================= SIYOMA V3.2 PAYMENT ENGINE ========================= */');
const end = src.indexOf('function viewTenant', start);
if (start < 0 || end < 0) throw new Error('Payment engine block not found');
const engine = src.slice(start, end) + `\nthis.__api={normalizePhone,normalizeName,tenantMatchForTransaction,reconcileTransaction,allocationTotal,remainingTransactionAmount,transactionFingerprint};`;
const context = {
  data:{tenants:[],payments:[],paymentIntents:[],paymentAudit:[],paymentAllocations:[],paymentTransactions:[]},
  todayISO:()=> '2026-11-27',
  pid:()=> 'test-'+Math.random().toString(36).slice(2),
  save:()=>{},
  money:n=>String(n),
  renderAll:()=>{},
  setText:()=>{},
  AndroidBridge:null,
  alert:()=>{},
  confirm:()=>true,
  window:{AndroidBridge:null},
  document:{getElementById:()=>null},
  console
};
vm.createContext(context); vm.runInContext(engine, context);
const {normalizePhone,tenantMatchForTransaction,reconcileTransaction,allocationTotal,remainingTransactionAmount,transactionFingerprint}=context.__api;
const t={id:'t1',name:'John Kamau',status:'active',mpesaNumber:'0712345678',rent:15000,due:'2026-11-01'};
context.data.tenants=[t];
let tx={id:'x1',payerPhone:'254712345678',payerName:'John Kamau',amount:15000,mpesaCode:'ABC123',dateTime:'2026-11-27 10:00',allocations:[]};
let r=reconcileTransaction(tx);
if(r.tenantId!=='t1'||r.suggestedAmount!==15000||(r.confidence!=='strong'&&r.confidence!=='very_high'))throw new Error('Exact rent match failed');
context.data.payments=[{id:'p1',tenantId:'t1',amount:15000,period:'2026-11',date:'2026-11-10'}];
r=reconcileTransaction({...tx,id:'x2',allocations:[]});
if(r.suggestedAmount!==0||r.confidence!=='ambiguous')throw new Error('Already-paid rent protection failed');
context.data.payments=[];
r=reconcileTransaction({...tx,id:'x3',amount:5000,allocations:[]});
if(r.suggestedAmount!==5000||(r.confidence!=='strong'&&r.confidence!=='very_high'))throw new Error('Partial payment matching failed');
r=reconcileTransaction({...tx,id:'x4',amount:20000,allocations:[]});
if(r.suggestedAmount!==15000||r.confidence!=='moderate')throw new Error('Overpayment matching failed');
const split={allocations:[{amount:15000},{amount:3000},{amount:2000}],amount:20000};
if(allocationTotal(split)!==20000||remainingTransactionAmount(split)!==0)throw new Error('Split allocation arithmetic failed');
if(normalizePhone('+254 712 345 678')!=='0712345678')throw new Error('Phone normalization failed');
if(transactionFingerprint(tx)!==transactionFingerprint({...tx,payerPhone:'0712345678'}))throw new Error('Fingerprint normalization failed');
console.log('SIYOMA payment engine smoke tests: PASS');
